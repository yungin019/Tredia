// src/types/auth.ts
export type { PlanName } from "../config/planLimits";
import type { PlanName } from "../config/planLimits";

export type PlanLite = {
  id: number;
  name: string;
  description: string | null;
  priceMonthly: number | null;
  currency: string | null;
};

export type WalletLite = {
  id: number;
  balance: number;
  currency: string;
};

export type AuthedUser = {
  id: number;
  email: string;
  displayName: string | null;
  planName: PlanName;
  plan: PlanLite | null;
  wallet: WalletLite | null;
};
