// src/types/express.d.ts
import type { AuthedUser } from "./auth";

declare global {
  namespace Express {
    interface Request {
      user?: AuthedUser;
      isElite?: boolean;
    }
  }
}

export {};
