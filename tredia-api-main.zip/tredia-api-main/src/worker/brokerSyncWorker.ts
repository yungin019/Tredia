// src/worker/brokerSyncWorker.ts
import prisma from "../prisma";
import { syncAllUsersWithBrokers } from "../services/brokerSyncService";

async function run() {
  try {
    console.log("[BrokerSyncWorker] Starting sync...");
    await syncAllUsersWithBrokers();
    console.log("[BrokerSyncWorker] Sync completed.");
  } catch (err) {
    console.error("[BrokerSyncWorker] Error during sync:", err);
  } finally {
    await prisma.$disconnect();
    process.exit(0);
  }
}

run();
