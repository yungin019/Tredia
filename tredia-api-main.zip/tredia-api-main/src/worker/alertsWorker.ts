// src/worker/alertsWorker.ts

import { generateDailyDigestAlert, generateTestJumpAlert } from "../services/alertsService";

/**
 * Run one alerts scan tick.
 * You can expand this function later with:
 *  - news scanning
 *  - volatility / jump detection
 *  - sector rotation analysis
 */
export async function runAlertsTick() {
  try {
    // Simple placeholder alerts:
    await generateDailyDigestAlert();
    await generateTestJumpAlert();

    console.log("[AlertsWorker] Alerts tick completed.");
  } catch (err) {
    console.error("[AlertsWorker] Error during alerts tick:", err);
  }
}

/**
 * Start a simple interval-based worker.
 * In production you might use a real cron scheduler instead.
 */
export function startAlertsWorker() {
  const intervalMs = 60 * 60 * 1000; // every 1 hour

  console.log(
    `[AlertsWorker] Starting alerts worker, interval ${intervalMs / 1000 / 60} minutes`
  );

  // Run immediately on start
  runAlertsTick();

  // Then periodically
  setInterval(runAlertsTick, intervalMs);
}
