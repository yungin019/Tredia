export function generateSyntheticAiDashboardData() {
  return {
    polygon: { summary: 'Synthetic US stocks data', data: [{ symbol: 'AAPL', price: 180.12, change: 1.2 }] },
    finnhub: { summary: 'Synthetic Finnhub data', data: [{ symbol: 'TSLA', price: 250.33, change: -0.8 }] },
    crypto: { summary: 'Synthetic Crypto data', data: [{ symbol: 'BTC', price: 42000, change: 2.1 }] },
  };
}
