// src/lib/cache.ts
type CacheEntry<T> = { value: T; expiresAt: number };

const mem = new Map<string, CacheEntry<any>>();

export async function cacheGet<T>(key: string): Promise<T | null> {
  const hit = mem.get(key);
  if (!hit) return null;

  if (Date.now() > hit.expiresAt) {
    mem.delete(key);
    return null;
  }

  return hit.value as T;
}

export async function cacheSet<T>(
  key: string,
  value: T,
  ttlSeconds = 60
): Promise<void> {
  mem.set(key, { value, expiresAt: Date.now() + ttlSeconds * 1000 });
}

export async function cacheDel(key: string): Promise<void> {
  mem.delete(key);
}
