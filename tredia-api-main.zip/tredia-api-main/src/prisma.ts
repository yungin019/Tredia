// src/prisma.ts
import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as unknown as {
  prisma?: PrismaClient;
};

const client =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ["error", "warn"],
  });

// cache in dev
if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = client;
}

// DEFAULT export (for imports like "import prisma from '../prisma'")
export default client;

// NAMED export (for imports like "import { prisma } from '../prisma'")
export const prisma = client;
