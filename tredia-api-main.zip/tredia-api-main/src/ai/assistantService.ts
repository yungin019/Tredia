// src/ai/assistantService.ts

import prisma from "../lib/prisma";
import { OpenAIClient } from "./openaiClient";
import {
  PlanName,
  getPlanNameFromDb,
} from "../config/planLimits";
import { getTodayUsage } from "../services/aiLimiterService";

export type AiRole = "user" | "assistant" | "system";

export interface AiMessage {
  role: AiRole;
  content: string;
}

export interface AiChatMeta {
  model?: string;
  latencyMs?: number;
  tokens?: number | null;
}

export interface AiChatResult {
  reply: string;
  meta: AiChatMeta;
  planName: PlanName;
  dailyLimit: number | null;      // null = unlimited
  remainingToday: number | null;  // null = unlimited
}

/**
 * Error thrown when a user hits their daily AI limit.
 * Includes plan + limit info so routes can send it to the app.
 */
export class AiMessageLimitError extends Error {
  statusCode: number;
  planName: PlanName;
  dailyLimit: number | null;
  remainingToday: number | null;

  constructor(
    message: string,
    planName: PlanName,
    dailyLimit: number | null,
    remainingToday: number | null
  ) {
    super(message);
    this.name = "AiMessageLimitError";
    this.statusCode = 403;
    this.planName = planName;
    this.dailyLimit = dailyLimit;
    this.remainingToday = remainingToday;
  }
}

// Build a single prompt string from chat messages
function buildPromptFromMessages(messages: AiMessage[]): string {
  const header =
    "You are Tredia AI, a market information and education assistant. " +
    "You NEVER give direct financial advice or explicit buy/sell/hold instructions. " +
    "You only provide educational explanations, context, and risk awareness. " +
    "Encourage the user to do their own research. Keep answers clear, structured and concise.\n\n";

  const conversation = messages
    .map((m) => {
      const prefix =
        m.role === "user"
          ? "User:"
          : m.role === "assistant"
          ? "Assistant:"
          : "System:";
      return `${prefix} ${m.content}`;
    })
    .join("\n");

  return header + conversation;
}

/**
 * Core: chat with Tredia AI under daily limits, fully DB-driven.
 */
export async function chatWithAssistant(
  userId: number,
  messages: AiMessage[]
): Promise<AiChatResult> {
  // 1) Load user + plan
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: { plan: true },
  });

  if (!user) {
    throw new Error("User not found");
  }

  const planName: PlanName = getPlanNameFromDb(user.plan);

  // 2) Get today's AI usage snapshot
  const usageSnapshot = await getTodayUsage(userId, planName);
  const { dailyLimit, remaining, usageId, used } = usageSnapshot;

  const isUnlimited = dailyLimit === null;

  // 3) Enforce limit (if not unlimited)
  if (!isUnlimited && dailyLimit !== null && remaining !== null && remaining <= 0) {
    throw new AiMessageLimitError(
      `Daily AI chat limit reached for plan ${planName}`,
      planName,
      dailyLimit,
      0
    );
  }

  // 4) Build prompt for OpenAI
  const prompt = buildPromptFromMessages(messages);

  // 5) Call OpenAI
  const result = await OpenAIClient.chat(prompt);
  const reply = result.text || "No reply available.";

  // 6) Increment usage count in DB
  const newCount = used + 1;

  await prisma.aiUsage.update({
    where: { id: usageId },
    data: {
      count: newCount,
    },
  });

  // 7) Compute new remainingToday
  let remainingToday: number | null = null;
  if (!isUnlimited && typeof dailyLimit === "number") {
    remainingToday = Math.max(dailyLimit - newCount, 0);
  }

  // 8) Return to route (mobile consumes this)
  return {
    reply,
    meta: {
      model: result.meta?.model,
      latencyMs: result.meta?.latencyMs,
      tokens: result.tokens ?? null,
    },
    planName,
    dailyLimit,
    remainingToday,
  };
}
