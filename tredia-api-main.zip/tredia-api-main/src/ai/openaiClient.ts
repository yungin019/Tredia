import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

export const OpenAIClient = {
  async chat(prompt: string) {
    const start = Date.now();

    const res = await openai.chat.completions.create({
      model: "gpt-4.1",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.2,
      max_tokens: 400,
    });

    const text = res.choices[0].message.content || "";
    const tokens = res.usage?.total_tokens ?? 0;

    return {
      text,
      tokens,
      meta: {
        model: "gpt-4.1",
        latencyMs: Date.now() - start,
        tokens,
      },
    };
  },
};
