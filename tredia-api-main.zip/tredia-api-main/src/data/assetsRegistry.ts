/**
 * TREDIA ASSET REGISTRY (Phase 1)
 *
 * Global tickers + aliases used for:
 * - news sentiment mapping
 * - related tickers
 * - impacted assets detection
 * - fallback quant logic
 *
 * Phase 2 will add:
 * - broker mapping
 * - instrument IDs
 * - price feed mapping
 */

export interface AssetRegistryItem {
  symbol: string;
  name: string;
  market: "stock" | "crypto" | "forex" | "etf" | "commodity" | "index";
  aliases: string[];
}

/**
 * Minimal but real-world large-cap universe + ETF + crypto + macro commodities.
 * Expand gradually during alpha.
 */
export const ASSET_REGISTRY: AssetRegistryItem[] = [
  // -----------------------------
  // US MEGA CAP
  // -----------------------------
  {
    symbol: "AAPL",
    name: "Apple Inc.",
    market: "stock",
    aliases: ["apple", "iphone", "macbook"],
  },
  {
    symbol: "MSFT",
    name: "Microsoft",
    market: "stock",
    aliases: ["microsoft", "windows", "azure"],
  },
  {
    symbol: "META",
    name: "Meta Platforms",
    market: "stock",
    aliases: ["facebook", "whatsapp", "instagram", "oculus"],
  },
  {
    symbol: "GOOG",
    name: "Alphabet",
    market: "stock",
    aliases: ["google", "alphabet", "search"],
  },
  {
    symbol: "AMZN",
    name: "Amazon",
    market: "stock",
    aliases: ["amazon", "aws"],
  },
  {
    symbol: "TSLA",
    name: "Tesla",
    market: "stock",
    aliases: ["tesla", "elon", "musk"],
  },
  {
    symbol: "NVDA",
    name: "NVIDIA",
    market: "stock",
    aliases: ["nvidia", "gpu", "ai chips"],
  },

  // -----------------------------
  // INDICES
  // -----------------------------
  {
    symbol: "SPY",
    name: "S&P 500 ETF",
    market: "index",
    aliases: ["s&p", "sp500", "snp", "spy"],
  },
  {
    symbol: "NDX",
    name: "Nasdaq 100",
    market: "index",
    aliases: ["nasdaq", "tech index"],
  },
  {
    symbol: "DJI",
    name: "Dow Jones",
    market: "index",
    aliases: ["dow", "dow jones", "djia"],
  },

  // -----------------------------
  // CRYPTO
  // -----------------------------
  {
    symbol: "BTC",
    name: "Bitcoin",
    market: "crypto",
    aliases: ["bitcoin", "crypto"],
  },
  {
    symbol: "ETH",
    name: "Ethereum",
    market: "crypto",
    aliases: ["ethereum", "eth", "eth2"],
  },
  {
    symbol: "SOL",
    name: "Solana",
    market: "crypto",
    aliases: ["solana", "sol"],
  },

  // -----------------------------
  // COMMODITIES
  // -----------------------------
  {
    symbol: "XAUUSD",
    name: "Gold",
    market: "commodity",
    aliases: ["gold", "bullion", "xau"],
  },
  {
    symbol: "WTI",
    name: "Oil WTI",
    market: "commodity",
    aliases: ["oil", "crude", "wti"],
  },
  {
    symbol: "NG",
    name: "Natural Gas",
    market: "commodity",
    aliases: ["gas", "natgas", "lng"],
  },

  // -----------------------------
  // ETFs & sectors (Phase 1)
  // -----------------------------
  {
    symbol: "XLK",
    name: "Technology Select ETF",
    market: "etf",
    aliases: ["technology etf", "tech etf"],
  },
  {
    symbol: "XLE",
    name: "Energy Select ETF",
    market: "etf",
    aliases: ["energy etf", "oil etf"],
  },
  {
    symbol: "XLU",
    name: "Utilities Select ETF",
    market: "etf",
    aliases: ["utilities etf", "power etf"],
  },
];

/**
 * Reverse index for fast lookup by alias
 */
const ALIAS_MAP = new Map<string, string>();

ASSET_REGISTRY.forEach((asset) => {
  asset.aliases.forEach((alias) => {
    ALIAS_MAP.set(alias.toLowerCase(), asset.symbol);
  });
});

/**
 * Find asset by exact ticker OR alias (lowercase)
 */
export function findAssetSymbol(text: string): string | null {
  const t = text.trim().toLowerCase();

  // exact symbol match
  const direct = ASSET_REGISTRY.find(
    (a) => a.symbol.toLowerCase() === t
  );
  if (direct) return direct.symbol;

  // alias match
  if (ALIAS_MAP.has(t)) return ALIAS_MAP.get(t) || null;

  return null;
}

/**
 * Search inside a long text (headline+summary)
 */
export function detectAssetTickers(input: string): string[] {
  if (!input) return [];

  const out = new Set<string>();
  const tokens = input
    .split(/[^a-zA-Z0-9]+/g)
    .filter((t) => t.length > 0);

  for (const tok of tokens) {
    const sym = findAssetSymbol(tok);
    if (sym) out.add(sym);
  }

  return Array.from(out);
}
