// src/controllers/planController.ts

import type { Request, Response } from "express";
import { prisma } from "../db";

/**
 * Dev auth fallback: until real auth middleware sets req.userId
 */
function getUserId(req: Request): number {
  return (req as any).userId || 1;
}

/**
 * GET /api/plans
 * Public – lists all plans and pricing
 */
export async function listPlans(_req: Request, res: Response) {
  try {
    const plans = await prisma.plan.findMany({
      orderBy: { priceMonthly: "asc" },
      select: {
        id: true,
        name: true,
        description: true,
        priceMonthly: true,
        currency: true,
      },
    });

    return res.json({ plans });
  } catch (err) {
    console.error("[planController] listPlans error:", err);
    return res.json({ plans: [] });
  }
}

/**
 * GET /api/user/plan
 * Returns the current user plan + (basic) limits.
 * Mobile expects this endpoint to exist and not crash.
 */
export async function getCurrentUserPlan(req: Request, res: Response) {
  try {
    const userId = getUserId(req);

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        planId: true,
        isFounder: true,
        founderPriceMonthly: true,
        plan: {
          select: {
            id: true,
            name: true,
            description: true,
            priceMonthly: true,
            currency: true,
          },
        },
      },
    });

    const planName = user?.plan?.name || "Free";

    // simple default gating (tweak later)
    const limits =
      planName.toLowerCase().includes("elite")
        ? { aiPerDay: 500, paperTradesPerDay: 500 }
        : planName.toLowerCase().includes("pro")
        ? { aiPerDay: 150, paperTradesPerDay: 150 }
        : { aiPerDay: 30, paperTradesPerDay: 30 };

    return res.json({
      userId,
      plan: user?.plan ?? null,
      planId: user?.planId ?? null,
      isFounder: !!user?.isFounder,
      founderPriceMonthly: user?.founderPriceMonthly ?? null,
      limits,
      _version: "planController.v1",
    });
  } catch (err) {
    console.error("[planController] getCurrentUserPlan error:", err);
    return res.json({
      userId: 1,
      plan: null,
      planId: null,
      isFounder: false,
      founderPriceMonthly: null,
      limits: { aiPerDay: 30, paperTradesPerDay: 30 },
      _version: "planController.v1 (fallback)",
    });
  }
}

/**
 * POST /api/user/plan
 * Dev-only override. RevenueCat remains source of truth in prod.
 * Body: { planId?: number } OR { planName?: string }
 */
export async function updateCurrentUserPlan(req: Request, res: Response) {
  try {
    const userId = getUserId(req);

    const { planId, planName } = (req.body || {}) as {
      planId?: number;
      planName?: string;
    };

    let nextPlanId: number | null = null;

    if (typeof planId === "number") {
      nextPlanId = planId;
    } else if (typeof planName === "string" && planName.trim()) {
      const plan = await prisma.plan.findFirst({
        where: { name: planName.trim() },
        select: { id: true },
      });
      nextPlanId = plan?.id ?? null;
    }

    const updated = await prisma.user.update({
      where: { id: userId },
      data: { planId: nextPlanId },
      select: { id: true, planId: true },
    });

    return res.json({
      ok: true,
      userId: updated.id,
      planId: updated.planId,
      _version: "planController.v1",
    });
  } catch (err) {
    console.error("[planController] updateCurrentUserPlan error:", err);
    return res.status(500).json({
      ok: false,
      error: "Failed to update plan.",
      _version: "planController.v1",
    });
  }
}
