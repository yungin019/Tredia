// src/controllers/userController.ts
import type { Request, Response } from "express";
import { prisma } from "../db";

function getUserIdOr401(req: Request, res: Response): number | null {
  const userId = req.user?.id;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  return userId;
}

export const getMe = async (req: Request, res: Response) => {
  const userId = getUserIdOr401(req, res);
  if (!userId) return;

  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: { plan: true, wallet: true },
  });

  if (!user) return res.status(404).json({ error: "User not found" });

  return res.json({
    user: {
      id: user.id,
      email: user.email,
      displayName: user.displayName,
      plan: user.plan
        ? {
            id: user.plan.id,
            name: user.plan.name,
            description: user.plan.description ?? null,
            priceMonthly: user.plan.priceMonthly ?? null,
            currency: user.plan.currency ?? null,
          }
        : null,
      wallet: user.wallet
        ? { balance: user.wallet.balance, currency: user.wallet.currency }
        : null,
    },
  });
};

export const getUserPlan = async (req: Request, res: Response) => {
  const userId = getUserIdOr401(req, res);
  if (!userId) return;

  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: { plan: true },
  });

  if (!user) return res.status(404).json({ error: "User not found" });

  return res.json({
    plan: user.plan
      ? {
          id: user.plan.id,
          name: user.plan.name,
          description: user.plan.description ?? null,
          priceMonthly: user.plan.priceMonthly ?? null,
          currency: user.plan.currency ?? null,
        }
      : null,
  });
};
