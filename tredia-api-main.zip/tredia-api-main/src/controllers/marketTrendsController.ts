// src/controllers/marketTrendsController.ts
import { Request, Response } from "express";
import { getMarketTrends as getMarketTrendsFromService } from "../services/marketService";

/**
 * Normalize backend output so mobile filters are stable.
 * IMPORTANT: your upstream can label ETFs as "index" (SPY/QQQ/IWM).
 * We convert "index" -> "etf" at the edge (controller response).
 */
function normalizeOutClass(cls: any) {
  const c = String(cls ?? "").trim().toLowerCase();
  if (!c) return "other";
  if (c === "index") return "etf";
  if (c === "fund") return "etf";
  if (c === "equity") return "stock";
  if (c === "fx") return "forex";
  if (c === "metals") return "metal";
  return c;
}

function normalizeItem(raw: any) {
  if (!raw || typeof raw !== "object") {
    return {
      symbol: "UNKNOWN",
      name: "Unknown",
      price: null,
      changePct: 0,
      assetClass: "other",
      sparkline: [],
    };
  }

  const assetClass = normalizeOutClass(raw.assetClass);

  return {
    ...raw,
    assetClass,
  };
}

export async function getMarketTrends(_req: Request, res: Response) {
  try {
    const { movers, trending } = await getMarketTrendsFromService();

    const moversFixed = Array.isArray(movers) ? movers.map(normalizeItem) : [];
    const trendingFixed = Array.isArray(trending)
      ? trending.map(normalizeItem)
      : [];

    return res.status(200).json({
      movers: moversFixed,
      trending: trendingFixed,
      newsRadar: [],
      generatedAt: new Date().toISOString(),

      // ✅ Debug marker: if you don't see this in curl,
      // you're NOT hitting this controller/route in prod.
      _controllerVersion: "marketTrendsController v4 (index->etf edge normalize)",
    });
  } catch (err) {
    console.error("[marketTrendsController] error", err);

    return res.status(200).json({
      movers: [],
      trending: [],
      newsRadar: [],
      generatedAt: new Date().toISOString(),
      _controllerVersion: "marketTrendsController v4 (error fallback)",
    });
  }
}
