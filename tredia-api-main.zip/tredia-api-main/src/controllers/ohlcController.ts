// src/controllers/ohlcController.ts

import { Request, Response } from "express";
import { fetchOHLC } from "../services/ohlcService";

/**
 * Controller: GET /api/ohlc/:symbol
 * Optional query param: ?interval=15
 */
export async function getOHLC(req: Request, res: Response) {
  try {
    const symbol = req.params.symbol;
    const interval = (req.query.interval as string) || "15";

    if (!symbol) {
      return res.status(400).json({ error: "Symbol is required." });
    }

    const data = await fetchOHLC(symbol, interval);

    if ("error" in data) {
      return res.status(502).json({
        error: data.error,
        message: "OHLC provider returned no candles.",
        candles: [],
      });
    }

    return res.json({
      symbol,
      interval,
      candles: data.candles,
    });
  } catch (err) {
    console.error("❌ OHLC Controller Error:", err);
    return res.status(500).json({ error: "Failed to load OHLC data." });
  }
}
