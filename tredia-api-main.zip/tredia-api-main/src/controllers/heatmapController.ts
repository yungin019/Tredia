// src/controllers/heatmapController.ts

import { Request, Response } from "express";
import axios from "axios";

const POLYGON_API_KEY = process.env.POLYGON_API_KEY;

if (!POLYGON_API_KEY) {
  console.warn(
    "[heatmapController] POLYGON_API_KEY is missing in environment. " +
      "Heatmap route will return 500 until it is set."
  );
}

// Simple Polygon REST client
const polygon = axios.create({
  baseURL: "https://api.polygon.io",
  timeout: 8000,
});

export type HeatmapBias = "bullish" | "bearish" | "neutral";

export interface HeatmapItem {
  symbol: string;
  name: string;
  assetClass: "stock";
  sector?: string | null;
  changePct: number;
  volatility?: number | null;
  aiBias: HeatmapBias;
  aiConfidence: number; // 0–1
  sentimentScore?: number | null;
  jumpProbability?: number | null;
  heat: number; // 0–1
}

/**
 * Very simple heuristic to map change% -> heat + bias.
 * This is enough to drive the mobile UI until Super AI is plugged.
 */
function mapTickerToHeatmap(t: any): HeatmapItem | null {
  const symbol = String(t.ticker ?? "");
  if (!symbol) return null;

  const changePct =
    typeof t.todaysChangePerc === "number"
      ? t.todaysChangePerc
      : 0;

  let aiBias: HeatmapBias = "neutral";
  if (changePct > 0.8) aiBias = "bullish";
  else if (changePct < -0.8) aiBias = "bearish";

  // Convert |change| to a 0–1 heat score (cap at 8%)
  const absChange = Math.min(Math.abs(changePct), 8);
  const heat = Number((absChange / 8).toFixed(2));

  // Confidence: stronger moves => higher confidence
  const aiConfidence = Number(
    (0.4 + (heat * 0.6)).toFixed(2)
  );

  return {
    symbol,
    name: symbol,
    assetClass: "stock",
    sector: null,
    changePct,
    volatility: null,
    aiBias,
    aiConfidence,
    sentimentScore: null,
    jumpProbability: heat > 0.6 ? 0.6 : heat > 0.3 ? 0.3 : 0.1,
    heat,
  };
}

/**
 * @route   GET /api/markets/heatmap
 * @desc    Super AI market heatmap (live-ish snapshot)
 */
export async function getHeatmap(req: Request, res: Response) {
  try {
    if (!POLYGON_API_KEY) {
      return res
        .status(500)
        .json({ error: "POLYGON_API_KEY not configured" });
    }

    const limitRaw =
      typeof req.query.limit === "string"
        ? parseInt(req.query.limit, 10)
        : 40;
    const limit = Number.isFinite(limitRaw) ? limitRaw : 40;

    // Reuse the same Polygon snapshots as the trends controller
    const [gainersRes, losersRes] = await Promise.all([
      polygon.get("/v2/snapshot/locale/us/markets/stocks/gainers", {
        params: { apiKey: POLYGON_API_KEY },
      }),
      polygon.get("/v2/snapshot/locale/us/markets/stocks/losers", {
        params: { apiKey: POLYGON_API_KEY },
      }),
    ]);

    const gainers: any[] = Array.isArray(gainersRes.data?.tickers)
      ? gainersRes.data.tickers
      : [];
    const losers: any[] = Array.isArray(losersRes.data?.tickers)
      ? losersRes.data.tickers
      : [];

    const combined = [...gainers, ...losers];

    const mapped: HeatmapItem[] = combined
      .map(mapTickerToHeatmap)
      .filter((x): x is HeatmapItem => x !== null)
      .sort((a, b) => b.heat - a.heat)
      .slice(0, limit);

    return res.json({
      generatedAt: new Date().toISOString(),
      items: mapped,
    });
  } catch (err: any) {
    console.error("[getHeatmap] error", err?.message || err);
    return res.status(500).json({ error: "HEATMAP_FETCH_FAILED" });
  }
}
