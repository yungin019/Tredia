// src/controllers/dailyBriefController.ts
import { Request, Response } from "express";
import { getDailyBriefSnapshot } from "../services/aiDashboardService";

export async function getDailyBriefHandler(
  _req: Request,
  res: Response
) {
  try {
    const snapshot = await getDailyBriefSnapshot();

    return res.status(200).json({
      dailyBrief: snapshot.dailyBrief,
      generatedAt: snapshot.generatedAt,
      _controllerVersion: "dailyBriefController.v2",
    });
  } catch (err) {
    console.error("[dailyBriefController] error:", err);

    return res.status(200).json({
      dailyBrief: null,
      generatedAt: new Date().toISOString(),
      _controllerVersion: "dailyBriefController.v2 (fallback)",
    });
  }
}
