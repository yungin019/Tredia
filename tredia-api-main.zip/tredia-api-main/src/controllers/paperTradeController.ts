// src/controllers/paperTradeController.ts (BACKEND – FULL FILE)

import { Request, Response } from "express";
import axios from "axios";
import prisma from "../prisma";

const DEFAULT_STARTING_CASH = 10000;

// ==============================
// Helpers (inside controller)
// ==============================

async function getLivePrice(symbol: string): Promise<number> {
  const apiKey = process.env.FINNHUB_API_KEY;
  if (!apiKey) {
    throw new Error("FINNHUB_API_KEY is not configured");
  }

  const url = `https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(
    symbol
  )}&token=${apiKey}`;

  const { data } = await axios.get(url);

  if (!data || typeof data.c !== "number" || data.c <= 0) {
    throw new Error("Could not fetch live price for symbol");
  }

  return data.c;
}

async function ensurePaperPortfolio(userId: number) {
  let portfolio = await prisma.paperPortfolio.findUnique({
    where: { userId },
  });

  if (!portfolio) {
    portfolio = await prisma.paperPortfolio.create({
      data: {
        userId,
        startingCash: DEFAULT_STARTING_CASH,
        cash: DEFAULT_STARTING_CASH,
        baseCurrency: "USD",
      },
    });
  }

  return portfolio;
}

async function executePaperTrade(params: {
  userId: number;
  symbol: string;
  side: "BUY" | "SELL";
  quantity: number;
  assetType?: string;
}) {
  const { userId, symbol, side, quantity, assetType } = params;

  if (!symbol || !side || !quantity || quantity <= 0) {
    throw new Error("Invalid trade parameters");
  }

  const sideNorm = side.toUpperCase();
  if (sideNorm !== "BUY" && sideNorm !== "SELL") {
    throw new Error("Side must be BUY or SELL");
  }

  // 1) Ensure portfolio exists
  const portfolio = await ensurePaperPortfolio(userId);

  // 2) Live price
  const price = await getLivePrice(symbol);
  const tradeValue = quantity * price;

  // 3) Check / update cash
  let newCash = portfolio.cash;

  if (sideNorm === "BUY") {
    if (tradeValue > portfolio.cash) {
      throw new Error("Insufficient cash in paper account");
    }
    newCash = portfolio.cash - tradeValue;
  } else {
    newCash = portfolio.cash + tradeValue;
  }

  // 4) Create trade row
  const trade = await prisma.paperTrade.create({
    data: {
      userId,
      paperPortfolioId: portfolio.id,
      symbol,
      assetType: assetType ?? "stock",
      side: sideNorm,
      size: tradeValue,
      quantity,
      entryPrice: price,
      status: "OPEN",
    },
  });

  // 5) Update portfolio cash
  await prisma.paperPortfolio.update({
    where: { id: portfolio.id },
    data: { cash: newCash },
  });

  // 6) Reload full portfolio
  const updatedPortfolio = await prisma.paperPortfolio.findUnique({
    where: { userId },
    include: { trades: true },
  });

  return {
    price,
    trade,
    portfolio: updatedPortfolio,
  };
}

// ==============================
// CONTROLLERS
// ==============================

// GET /api/paper/portfolio
export async function getPaperPortfolio(req: Request, res: Response) {
  try {
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    let portfolio = await prisma.paperPortfolio.findUnique({
      where: { userId },
      include: { trades: true },
    });

    if (!portfolio) {
      portfolio = await prisma.paperPortfolio.create({
        data: {
          userId,
          startingCash: DEFAULT_STARTING_CASH,
          cash: DEFAULT_STARTING_CASH,
          baseCurrency: "USD",
        },
        include: { trades: true },
      });
    }

    return res.json({ portfolio });
  } catch (err) {
    console.error("getPaperPortfolio error:", err);
    return res
      .status(500)
      .json({ error: "Failed to load paper trading portfolio" });
  }
}

// POST /api/paper/trades
// Body: { symbol, side, quantity, assetType? }
export async function createPaperTrade(req: Request, res: Response) {
  try {
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const { symbol, side, quantity, assetType } = req.body;

    if (!symbol || !side || quantity == null) {
      return res
        .status(400)
        .json({ error: "symbol, side and quantity are required" });
    }

    const qtyNum = Number(quantity);
    if (!Number.isFinite(qtyNum) || qtyNum <= 0) {
      return res.status(400).json({ error: "quantity must be > 0" });
    }

    const result = await executePaperTrade({
      userId,
      symbol,
      side: side.toUpperCase() === "SELL" ? "SELL" : "BUY",
      quantity: qtyNum,
      assetType,
    });

    return res.status(201).json(result);
  } catch (err: any) {
    console.error("createPaperTrade error:", err);
    return res.status(400).json({
      error: err?.message || "Failed to execute paper trade",
    });
  }
}
