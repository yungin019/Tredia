// src/controllers/paperController.ts

import { Request, Response } from "express";
import { prisma } from "../db";

// --- Helper: ensure a basic portfolio always exists for the user ---
async function ensurePortfolio(userId: number) {
  let p = await prisma.paperPortfolio.findFirst({
    where: { userId },
  });

  if (!p) {
    p = await prisma.paperPortfolio.create({
      data: {
        userId,
        startingCash: 10000,
        cash: 10000,
        baseCurrency: "USD",
      },
    });
  }

  return p;
}

// -----------------------------------------------------------------
// GET /api/paper/portfolio
// Always returns a valid portfolio + trades array
// -----------------------------------------------------------------
export async function getPaperPortfolio(req: Request, res: Response) {
  try {
    // TODO: plug real auth middleware, this is just a dev fallback
    const userId = (req as any).userId || 1;

    const portfolio = await ensurePortfolio(userId);

    const trades = await prisma.paperTrade.findMany({
      where: { userId, paperPortfolioId: portfolio.id },
      orderBy: { createdAt: "desc" },
    });

    return res.json({
      portfolio,
      trades,
    });
  } catch (err) {
    console.error("[paper] getPortfolio error", err);
    return res.json({
      portfolio: null,
      trades: [],
    });
  }
}

// -----------------------------------------------------------------
// GET /api/paper/performance
// Always returns safe numbers, never 500
// -----------------------------------------------------------------
export async function getPerformanceSummary(req: Request, res: Response) {
  try {
    const userId = (req as any).userId || 1;

    const portfolio = await ensurePortfolio(userId);

    const trades = await prisma.paperTrade.findMany({
      where: { userId, paperPortfolioId: portfolio.id },
    });

    let realizedPnl = 0;
    let openTrades = 0;
    let closedTrades = 0;

    for (const t of trades as any[]) {
      if (t.status === "CLOSED") {
        if (typeof t.exitPrice === "number") {
          realizedPnl += (t.exitPrice - t.entryPrice) * t.quantity;
        }
        closedTrades++;
      } else {
        openTrades++;
      }
    }

    return res.json({
      portfolio: {
        id: portfolio.id,
        userId: portfolio.userId,
        startingCash: portfolio.startingCash,
        currentCash: portfolio.cash,
        baseCurrency: portfolio.baseCurrency,
      },
      performance: {
        totalTrades: trades.length,
        openTrades,
        closedTrades,
        realizedPnl,
        invested: 0,
      },
    });
  } catch (err) {
    console.error("[paper] performance error", err);

    return res.json({
      portfolio: {
        id: 0,
        userId: 0,
        startingCash: 10000,
        currentCash: 10000,
        baseCurrency: "USD",
      },
      performance: {
        totalTrades: 0,
        openTrades: 0,
        closedTrades: 0,
        realizedPnl: 0,
        invested: 0,
      },
    });
  }
}

// -----------------------------------------------------------------
// POST /api/paper/trade
// ✅ This is what mobile calls
// Creates a paper trade + updates cash (simple MVP logic)
// -----------------------------------------------------------------
export async function executePaperTrade(req: Request, res: Response) {
  try {
    const userId = (req as any).userId || 1;

    const symbol = String(req.body?.symbol || "").trim().toUpperCase();
    const sideRaw = String(req.body?.side || "").toLowerCase();
    const orderType = String(req.body?.orderType || "market").toLowerCase();

    const quantity = Number(req.body?.quantity);
    const limitPrice =
      req.body?.limitPrice != null ? Number(req.body?.limitPrice) : undefined;

    if (!symbol) {
      return res.status(400).json({ ok: false, error: "Missing symbol." });
    }
    if (sideRaw !== "buy" && sideRaw !== "sell") {
      return res.status(400).json({ ok: false, error: "Invalid side." });
    }
    if (!Number.isFinite(quantity) || quantity <= 0) {
      return res.status(400).json({ ok: false, error: "Invalid quantity." });
    }

    // MVP price handling:
    // - market: we don't have a live execution price yet -> use 1
    // - limit: if provided, use it
    const entryPrice =
      orderType === "limit" && Number.isFinite(limitPrice) && (limitPrice as number) > 0
        ? (limitPrice as number)
        : 1;

    const portfolio = await ensurePortfolio(userId);

    const cost = entryPrice * quantity;

    // Simple cash update rules:
    // - buy: must have enough cash, then subtract
    // - sell: allow (MVP), add cash (no position tracking yet)
    let newCash = portfolio.cash;

    if (sideRaw === "buy") {
      if (newCash < cost) {
        return res.status(400).json({
          ok: false,
          error: "Insufficient cash for this paper trade.",
          cash: newCash,
          required: cost,
        });
      }
      newCash = newCash - cost;
    } else {
      newCash = newCash + cost;
    }

    const updatedPortfolio = await prisma.paperPortfolio.update({
      where: { id: portfolio.id },
      data: { cash: newCash },
    });

    // Prisma schema requires: assetType, side, size, quantity, entryPrice, status
    const trade = await prisma.paperTrade.create({
      data: {
        userId,
        paperPortfolioId: portfolio.id,
        symbol,
        assetType: "stock", // MVP default (you can improve using markets/info later)
        side: sideRaw.toUpperCase(), // "BUY" / "SELL" style
        size: cost, // total notional
        quantity,
        entryPrice,
        exitPrice: null,
        status: "OPEN",
      },
    });

    return res.json({
      ok: true,
      portfolio: updatedPortfolio,
      trade,
    });
  } catch (err: any) {
    console.error("[paper] executePaperTrade error:", err);
    return res.status(500).json({
      ok: false,
      error: "Failed to execute paper trade.",
      message: err?.message || String(err),
    });
  }
}
