// src/controllers/superAiController.ts
import type { Request, Response } from "express";
import { getSuperAiResponse } from "../services/superAiService";

export async function getSuperAI(req: Request, res: Response) {
  try {
    const userId = (req as any).user?.id as number | undefined;

    if (!userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const body = (req.body ?? {}) as {
      prompt?: string;
      message?: string; // allow mobile payload
    };

    const prompt =
      typeof body.prompt === "string" && body.prompt.trim()
        ? body.prompt.trim()
        : typeof body.message === "string" && body.message.trim()
          ? body.message.trim()
          : "";

    if (!prompt) {
      return res.status(400).json({ error: "prompt is required" });
    }

    const reply = await getSuperAiResponse(userId, prompt);

    return res.json({ reply });
  } catch (err: any) {
    // If superAiService throws ELITE_ONLY, return 403 (clean)
    if (err?.code === "ELITE_ONLY" || err?.message === "ELITE_ONLY") {
      return res.status(403).json({ error: "Elite plan required" });
    }

    console.error("[superAiController] error:", err);
    return res.status(500).json({
      error: "Super AI is temporarily unavailable",
      message: err?.message ?? String(err),
    });
  }
}
