// src/controllers/brokerController.ts

import { Request, Response } from "express";
import {
  getAvailablePlatforms,
  getUserBrokerAccount as getUserBrokerAccountService,
  connectBroker as connectBrokerService,
  disconnectBroker as disconnectBrokerService,
  getTradeDeeplink as getTradeDeeplinkService,
} from "../services/brokerService";

// ---------------------------------------------------------------------
// PLATFORMS / ACCOUNT / CONNECT / DISCONNECT / DEEPLINK
// ---------------------------------------------------------------------

// GET /api/brokers/platforms
export const getPlatforms = async (_req: Request, res: Response) => {
  try {
    const platforms = await getAvailablePlatforms();
    return res.json({ platforms });
  } catch (err) {
    console.error("[BrokerController] getPlatforms error", err);
    return res.status(500).json({ error: "BROKER_PLATFORM_ERROR" });
  }
};

// GET /api/brokers/me
export const getUserBrokerAccount = async (req: Request, res: Response) => {
  try {
    const user = (req as any).user as { id?: number } | undefined;
    const userId = user?.id as number | undefined;
    if (!userId) {
      return res.status(401).json({ error: "UNAUTHENTICATED" });
    }

    const account = await getUserBrokerAccountService(userId);
    return res.json({ account });
  } catch (err) {
    console.error("[BrokerController] getUserBrokerAccount error", err);
    return res.status(500).json({ error: "BROKER_ACCOUNT_ERROR" });
  }
};

// POST /api/brokers/connect
// body: { brokerSlug: string }
export const connectBroker = async (req: Request, res: Response) => {
  try {
    const user = (req as any).user as { id?: number } | undefined;
    const userId = user?.id as number | undefined;
    if (!userId) {
      return res.status(401).json({ error: "UNAUTHENTICATED" });
    }

    const { brokerSlug } = req.body;
    if (!brokerSlug || typeof brokerSlug !== "string") {
      return res.status(400).json({ error: "BROKER_SLUG_REQUIRED" });
    }

    const account = await connectBrokerService(userId, brokerSlug);
    return res.json({ account });
  } catch (err: any) {
    console.error("[BrokerController] connectBroker error", err);
    if (err?.message === "BROKER_PLATFORM_NOT_FOUND") {
      return res.status(404).json({ error: "BROKER_PLATFORM_NOT_FOUND" });
    }
    return res.status(500).json({ error: "BROKER_CONNECT_ERROR" });
  }
};

// POST /api/brokers/disconnect
export const disconnectBroker = async (req: Request, res: Response) => {
  try {
    const user = (req as any).user as { id?: number } | undefined;
    const userId = user?.id as number | undefined;
    if (!userId) {
      return res.status(401).json({ error: "UNAUTHENTICATED" });
    }

    await disconnectBrokerService(userId);
    return res.json({ ok: true });
  } catch (err) {
    console.error("[BrokerController] disconnectBroker error", err);
    return res.status(500).json({ error: "BROKER_DISCONNECT_ERROR" });
  }
};

// GET /api/brokers/deeplink?symbol=TSLA
export const getTradeDeeplink = async (req: Request, res: Response) => {
  try {
    const user = (req as any).user as { id?: number } | undefined;
    const userId = user?.id;
    if (!userId) {
      return res.status(401).json({ error: "UNAUTHENTICATED" });
    }

    const symbol = (req.query.symbol as string | undefined)?.trim();
    if (!symbol) {
      return res.status(400).json({ error: "SYMBOL_REQUIRED" });
    }

    const url = await getTradeDeeplinkService(userId, symbol);
    if (!url) {
      return res.status(404).json({
        error: "NO_BROKER_OR_LINK",
        message:
          "No connected broker or no deep link available. Connect a broker first.",
      });
    }

    return res.json({ url });
  } catch (err) {
    console.error("[BrokerController] getTradeDeeplink error", err);
    return res.status(500).json({ error: "BROKER_DEEPLINK_ERROR" });
  }
};

// ---------------------------------------------------------------------
// LIVE PORTFOLIO (for PortfolioScreen "Live" tab)
// ---------------------------------------------------------------------

// GET /api/brokers/portfolio
export const getBrokerPortfolio = async (req: Request, res: Response) => {
  try {
    const user = (req as any).user as { id?: number } | undefined;
    const userId = user?.id as number | undefined;

    // If you require auth for live portfolio, enforce it here.
    if (!userId) {
      return res.status(401).json({ error: "UNAUTHENTICATED" });
    }

    // TODO: replace this placeholder with a real broker API call
    // and map the broker response to this structure.
    const demo = {
      provider: "demo-broker",
      connected: false, // set true when you actually detect a linked broker
      baseCurrency: "USD",
      cash: 0,
      startingCash: 0,
      positions: [] as {
        id: number;
        symbol: string;
        quantity: number;
        avgPrice: number;
        marketValue?: number;
        unrealizedPnl?: number;
      }[],
    };

    return res.json(demo);
  } catch (err) {
    console.error("[BrokerController] getBrokerPortfolio error", err);
    return res.status(500).json({ error: "BROKER_PORTFOLIO_ERROR" });
  }
};
