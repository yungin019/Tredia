// src/controllers/communityController.ts
import { Request, Response } from "express";
import {
  listCommunityPosts,
  getCommunityPostById,
  createCommunityPost,
  likePost,
  unlikePost,
  addCommentToPost,
  listLiveActivity,
} from "../services/communityService";

type AuthedUser = {
  id: number;
  email?: string;
  displayName?: string | null;
  // plan?: any; // available from express.d.ts augmentation, but not required here
};

type AuthedRequest = Request & {
  user?: AuthedUser;
};

function getUserIdOrThrow(req: AuthedRequest): number {
  if (!req.user || typeof req.user.id !== "number") {
    throw new Error("Missing authenticated user (req.user.id).");
  }
  return req.user.id;
}

// -----------------------------
// HANDLERS
// -----------------------------

export async function listCommunityPostsHandler(
  req: AuthedRequest,
  res: Response
) {
  try {
    const limitRaw = req.query.limit;
    const limit =
      typeof limitRaw === "string" ? parseInt(limitRaw, 10) : undefined;

    const viewerId = req.user?.id ?? null;

    const posts = await listCommunityPosts({
      limit,
      viewerId,
    });

    res.json({ posts });
  } catch (err) {
    console.error("[CommunityController] listCommunityPosts error:", err);
    res
      .status(500)
      .json({ error: "Failed to load community posts." });
  }
}

export async function getCommunityPostHandler(
  req: AuthedRequest,
  res: Response
) {
  try {
    const id = Number(req.params.id);
    if (!id || Number.isNaN(id)) {
      return res.status(400).json({ error: "Invalid post id." });
    }

    const post = await getCommunityPostById(id);
    if (!post) {
      return res.status(404).json({ error: "Post not found." });
    }

    res.json({ post });
  } catch (err) {
    console.error("[CommunityController] getCommunityPost error:", err);
    res
      .status(500)
      .json({ error: "Failed to load this post." });
  }
}

export async function createCommunityPostHandler(
  req: AuthedRequest,
  res: Response
) {
  try {
    let authorId: number;

    try {
      authorId = getUserIdOrThrow(req);
    } catch {
      // If you want to require auth strictly, remove this and just return 401.
      return res
        .status(401)
        .json({ error: "Authentication required to create posts." });
    }

    const { title, content, imageUrl } = req.body || {};

    if (!content || typeof content !== "string") {
      return res
        .status(400)
        .json({ error: "Field 'content' (string) is required." });
    }

    const post = await createCommunityPost({
      authorId,
      title: typeof title === "string" ? title : null,
      content,
      imageUrl: typeof imageUrl === "string" ? imageUrl : null,
    });

    res.status(201).json({ post });
  } catch (err) {
    console.error("[CommunityController] createCommunityPost error:", err);
    res
      .status(500)
      .json({ error: "Failed to create community post." });
  }
}

export async function likePostHandler(
  req: AuthedRequest,
  res: Response
) {
  try {
    let userId: number;

    try {
      userId = getUserIdOrThrow(req);
    } catch {
      return res
        .status(401)
        .json({ error: "Authentication required to like posts." });
    }

    const id = Number(req.params.id);
    if (!id || Number.isNaN(id)) {
      return res.status(400).json({ error: "Invalid post id." });
    }

    await likePost(id, userId);
    res.json({ ok: true });
  } catch (err) {
    console.error("[CommunityController] likePost error:", err);
    res
      .status(500)
      .json({ error: "Failed to like post." });
  }
}

export async function unlikePostHandler(
  req: AuthedRequest,
  res: Response
) {
  try {
    let userId: number;

    try {
      userId = getUserIdOrThrow(req);
    } catch {
      return res
        .status(401)
        .json({ error: "Authentication required to unlike posts." });
    }

    const id = Number(req.params.id);
    if (!id || Number.isNaN(id)) {
      return res.status(400).json({ error: "Invalid post id." });
    }

    await unlikePost(id, userId);
    res.json({ ok: true });
  } catch (err) {
    console.error("[CommunityController] unlikePost error:", err);
    res
      .status(500)
      .json({ error: "Failed to unlike post." });
  }
}

export async function addCommentHandler(
  req: AuthedRequest,
  res: Response
) {
  try {
    let userId: number;

    try {
      userId = getUserIdOrThrow(req);
    } catch {
      return res
        .status(401)
        .json({ error: "Authentication required to comment." });
    }

    const id = Number(req.params.id);
    if (!id || Number.isNaN(id)) {
      return res.status(400).json({ error: "Invalid post id." });
    }

    const { content } = req.body || {};
    if (!content || typeof content !== "string") {
      return res
        .status(400)
        .json({ error: "Field 'content' (string) is required." });
    }

    const comment = await addCommentToPost({
      postId: id,
      userId,
      content,
    });

    res.status(201).json({ comment });
  } catch (err) {
    console.error("[CommunityController] addComment error:", err);
    res
      .status(500)
      .json({ error: "Failed to add comment." });
  }
}

export async function listLiveActivityHandler(
  _req: AuthedRequest,
  res: Response
) {
  try {
    const items = await listLiveActivity({ limit: 50 });
    res.json({ items });
  } catch (err) {
    console.error("[CommunityController] listLiveActivity error:", err);
    res
      .status(500)
      .json({ error: "Failed to load live community activity." });
  }
}
