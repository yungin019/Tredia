// src/controllers/portfolioController.ts

import { Request, Response } from "express";
import prisma from "../lib/prisma";

export async function getPortfolioOverview(req: Request, res: Response) {
  try {
    const userId = req.user?.id;
    if (!userId) return res.status(401).json({ error: "Unauthorized" });

    // LIVE POSITIONS (broker synced)
    const liveAccounts = await prisma.userBrokerAccount.findMany({
      where: { userId },
      include: { positions: true },
    });

    // PAPER PORTFOLIO
    let paper = await prisma.paperPortfolio.findUnique({
      where: { userId },
      include: { trades: true },
    });

    if (!paper) {
      paper = await prisma.paperPortfolio.create({
        data: { userId, startingCash: 10000, cash: 10000 },
        include: { trades: true },
      });
    }

    return res.json({
      live: liveAccounts,
      paper,
    });
  } catch (err) {
    console.error("Portfolio overview error:", err);
    return res.status(500).json({ error: "Failed to load portfolio" });
  }
}
