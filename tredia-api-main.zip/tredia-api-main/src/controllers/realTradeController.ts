// src/controllers/realTradeController.ts
import { Request, Response } from "express";
import prisma from "../lib/prisma";

/**
 * GET /api/real-trades
 * Returns the user's real (live) trade history.
 */
export const getRealTrades = async (req: Request, res: Response) => {
  try {
    const anyReq = req as any;
    const userId = anyReq.user?.id;

    if (!userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const trades = await prisma.tradeHistory.findMany({
      where: { userId },
      orderBy: { timestamp: "desc" },
    });

    return res.json({ trades });
  } catch (error) {
    console.error("[realTradeController] getRealTrades error:", error);
    return res.status(500).json({ error: "Failed to fetch real trades" });
  }
};

/**
 * POST /api/real-trades
 * Body:
 * {
 *   "symbol": "AAPL",
 *   "side": "BUY" | "SELL",
 *   "qty": 1.5,
 *   "price": 185.4
 * }
 */
export const createRealTrade = async (req: Request, res: Response) => {
  try {
    const anyReq = req as any;
    const userId = anyReq.user?.id;

    if (!userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const { symbol, side, qty, price } = req.body || {};

    if (!symbol || !side || typeof qty !== "number" || typeof price !== "number") {
      return res.status(400).json({
        error: "symbol, side, qty and price are required",
      });
    }

    const trade = await prisma.tradeHistory.create({
      data: {
        userId,
        symbol,
        side,
        qty,
        price,
      },
    });

    return res.status(201).json({ trade });
  } catch (error) {
    console.error("[realTradeController] createRealTrade error:", error);
    return res.status(500).json({ error: "Failed to create real trade" });
  }
};

/**
 * DELETE /api/real-trades/:id
 */
export const deleteRealTrade = async (req: Request, res: Response) => {
  try {
    const anyReq = req as any;
    const userId = anyReq.user?.id;
    const id = Number(req.params.id);

    if (!userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    if (Number.isNaN(id)) {
      return res.status(400).json({ error: "Invalid trade id" });
    }

    const existing = await prisma.tradeHistory.findFirst({
      where: { id, userId },
    });

    if (!existing) {
      return res.status(404).json({ error: "Trade not found" });
    }

    await prisma.tradeHistory.delete({ where: { id } });

    return res.json({ success: true });
  } catch (error) {
    console.error("[realTradeController] deleteRealTrade error:", error);
    return res.status(500).json({ error: "Failed to delete real trade" });
  }
};
