// src/controllers/userPreferencesController.ts
import type { Request, Response } from "express";
import { prisma } from "../db";

function getUserIdOr401(req: Request, res: Response): number | null {
  const userId = req.user?.id;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  return userId;
}

export const getUserPreferences = async (req: Request, res: Response) => {
  const userId = getUserIdOr401(req, res);
  if (!userId) return;

  const prefs = await prisma.userPreferences.findUnique({
    where: { userId },
  });

  return res.json({
    preferences:
      prefs ??
      ({
        riskTolerance: "medium",
        horizon: "swing",
        markets: ["stocks", "crypto"],
        bannedSymbols: [],
        preferredSectors: [],
        maxPositions: 10,
        rebalanceFrequencyDays: 30,
      } as const),
  });
};

export const updateUserPreferences = async (req: Request, res: Response) => {
  const userId = getUserIdOr401(req, res);
  if (!userId) return;

  const data = req.body ?? {};

  const updated = await prisma.userPreferences.upsert({
    where: { userId },
    create: { userId, ...data },
    update: { ...data },
  });

  return res.json({ preferences: updated });
};
