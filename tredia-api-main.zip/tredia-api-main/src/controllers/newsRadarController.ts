// src/controllers/newsRadarController.ts
import { Request, Response } from "express";
import { getNewsRadarSnapshot } from "../services/aiDashboardService";

export async function getNewsRadarHandler(
  _req: Request,
  res: Response
) {
  try {
    const snapshot = await getNewsRadarSnapshot();

    return res.status(200).json({
      items: snapshot.newsRadar,
      newsRadar: snapshot.newsRadar, // backward compatible
      generatedAt: snapshot.generatedAt,
      _controllerVersion: "newsRadarController.v2",
    });
  } catch (err) {
    console.error("[newsRadarController] error:", err);

    return res.status(200).json({
      items: [],
      newsRadar: [],
      generatedAt: new Date().toISOString(),
      _controllerVersion: "newsRadarController.v2 (fallback)",
    });
  }
}
