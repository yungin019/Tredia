import { Request, Response } from "express";
import { finnhubClient } from "../config/finnhub";
import { twelvedataClient, hasTwelveData } from "../config/twelvedata";

const METAL_ALIASES: Record<string, string> = {
  XAUUSD: "XAU/USD",
  XAGUSD: "XAG/USD",
};

function looksLikeFxPair(sym: string) {
  return /^[A-Z]{6}$/.test(sym);
}

function toSlashPair(sym: string) {
  const base = sym.slice(0, 3);
  const quote = sym.slice(3, 6);
  return `${base}/${quote}`;
}

function normalizeRequestedSymbol(raw: string) {
  return raw.trim().toUpperCase();
}

// --- Finnhub symbol mapping (kept for crypto/stocks) ---
function looksLikeCryptoPair(sym: string) {
  return /^[A-Z0-9]{5,12}(USDT|USD)$/.test(sym);
}

function toBinance(sym: string) {
  return `BINANCE:${sym}`;
}

function resolveFinnhubSymbol(input: string) {
  const s = input.trim().toUpperCase();
  if (!s) return null;

  if (s.includes(":")) return s;

  if (looksLikeCryptoPair(s)) return toBinance(s);

  // Default: stocks/ETFs generally OK as-is
  return s;
}

function isMissingFinnhubQuote(q: any) {
  // Finnhub /quote shape: c, d, dp, h, l, o, pc
  const c = typeof q?.c === "number" ? q.c : null;
  const pc = typeof q?.pc === "number" ? q.pc : null;

  const cBad = c == null || !Number.isFinite(c) || c <= 0;
  const pcBad = pc == null || !Number.isFinite(pc) || pc <= 0;

  return cBad && pcBad;
}

// --- TwelveData symbol mapping (FX + metals) ---
function isOandaSymbol(s: string) {
  return s.startsWith("OANDA:");
}

function oandaToSlashPair(s: string) {
  // OANDA:EUR_USD -> EUR/USD
  // OANDA:XAU_USD -> XAU/USD
  const parts = s.split(":");
  if (parts.length !== 2) return null;
  const pair = parts[1];
  if (!pair.includes("_")) return null;

  const [base, quote] = pair.split("_");
  if (!base || !quote) return null;
  return `${base.toUpperCase()}/${quote.toUpperCase()}`;
}

function resolveTwelveDataSymbol(requested: string) {
  const s = requested.trim().toUpperCase();
  if (!s) return null;

  // If it already looks like a slash pair (EUR/USD, XAU/USD) keep it
  if (s.includes("/")) return s;

  // If OANDA:XXX_YYY -> XXX/YYY
  if (isOandaSymbol(s)) return oandaToSlashPair(s);

  // Metals aliases
  if (METAL_ALIASES[s]) return METAL_ALIASES[s];

  // FX pair like EURUSD -> EUR/USD
  if (looksLikeFxPair(s)) return toSlashPair(s);

  // For anything else we return null (we only use TwelveData for FX/metals here)
  return null;
}

function isFxOrMetalRequested(requested: string) {
  const s = requested.trim().toUpperCase();

  if (METAL_ALIASES[s]) return true;
  if (looksLikeFxPair(s)) return true;
  if (s.startsWith("OANDA:")) return true;
  if (s.includes("XAU") || s.includes("XAG")) return true;

  return false;
}

async function fetchFromFinnhub(resolved: string) {
  const resp = await finnhubClient.get("/quote", { params: { symbol: resolved } });
  return resp.data;
}

async function fetchFromTwelveData(resolved: string) {
  // TwelveData quote endpoint:
  // GET https://api.twelvedata.com/quote?symbol=XAU/USD
  const resp = await twelvedataClient.get("/quote", { params: { symbol: resolved } });
  return resp.data;
}

function parseTwelveDataQuote(data: any) {
  // On success, TwelveData returns fields like:
  // close: "2075.12", percent_change: "-0.42"
  // On error: { status:"error", code:..., message:"..." }
  if (!data || typeof data !== "object") return null;

  if (data.status === "error") {
    return { error: true, message: data.message || "TwelveData error", raw: data };
  }

  const closeRaw = data.close ?? data.price ?? data.last ?? null;
  const pctRaw = data.percent_change ?? data.change_percent ?? null;

  const price = closeRaw != null ? Number(closeRaw) : null;
  const changePct = pctRaw != null ? Number(pctRaw) : 0;

  if (price == null || !Number.isFinite(price) || price <= 0) {
    return { error: true, message: "No valid price from TwelveData", raw: data };
  }

  return { error: false, price, changePct: Number.isFinite(changePct) ? changePct : 0, raw: data };
}

export async function getMarketInfo(req: Request, res: Response) {
  const raw = req.params.symbol;

  const requested =
    typeof raw === "string" && raw.trim().length > 0
      ? normalizeRequestedSymbol(raw)
      : null;

  if (!requested) {
    return res.status(400).json({ error: "Missing symbol" });
  }

  const wantsFxOrMetal = isFxOrMetalRequested(requested);

  // Prefer TwelveData for FX/metals if available (avoids Finnhub 403 noise)
  if (wantsFxOrMetal && hasTwelveData()) {
    const tdSymbol = resolveTwelveDataSymbol(requested);

    if (!tdSymbol) {
      return res.status(404).json({
        error: "Symbol format not supported for FX/metals",
        requested,
      });
    }

    try {
      const data = await fetchFromTwelveData(tdSymbol);
      const parsed = parseTwelveDataQuote(data);

      if (!parsed || parsed.error) {
        return res.status(404).json({
          error: "Symbol unsupported by provider or no quote available",
          requested,
          resolved: tdSymbol,
          provider: "twelvedata",
        });
      }

      return res.json({
        symbol: requested,
        resolvedSymbol: tdSymbol,
        name: requested,
        price: parsed.price,
        changePct: parsed.changePct,
        provider: "twelvedata",
      });
    } catch (err: any) {
      const status = err?.response?.status;
      const data = err?.response?.data;

      console.error("[marketInfo] TwelveData error:", status, data || err?.message || err);

      return res.status(500).json({
        error: "Failed to fetch market info (twelvedata)",
      });
    }
  }

  // Otherwise: use Finnhub (stocks/crypto)
  const finnhubSymbol = resolveFinnhubSymbol(requested);
  if (!finnhubSymbol) {
    return res.status(400).json({ error: "Missing symbol" });
  }

  try {
    const quote = await fetchFromFinnhub(finnhubSymbol);

    if (isMissingFinnhubQuote(quote)) {
      // If FX/metals and TwelveData exists, try fallback even if earlier branch didn't run
      if (wantsFxOrMetal && hasTwelveData()) {
        const tdSymbol = resolveTwelveDataSymbol(requested);
        if (tdSymbol) {
          try {
            const tdData = await fetchFromTwelveData(tdSymbol);
            const parsed = parseTwelveDataQuote(tdData);

            if (parsed && !parsed.error) {
              return res.json({
                symbol: requested,
                resolvedSymbol: tdSymbol,
                name: requested,
                price: parsed.price,
                changePct: parsed.changePct,
                provider: "twelvedata",
              });
            }
          } catch {
            // ignore fallback errors, we'll return 404 below
          }
        }
      }

      return res.status(404).json({
        error: "Symbol unsupported by provider or no quote available",
        requested,
        resolved: finnhubSymbol,
        provider: "finnhub",
      });
    }

    const price = typeof quote?.c === "number" ? quote.c : null;
    const changePct = typeof quote?.dp === "number" ? quote.dp : 0;

    return res.json({
      symbol: requested,
      resolvedSymbol: finnhubSymbol,
      name: requested,
      price,
      changePct,
      provider: "finnhub",
    });
  } catch (err: any) {
    const status = err?.response?.status;
    const data = err?.response?.data;

    // Finnhub lock (401/403) -> try TwelveData fallback for FX/metals
    if ((status === 401 || status === 403) && wantsFxOrMetal && hasTwelveData()) {
      const tdSymbol = resolveTwelveDataSymbol(requested);
      if (tdSymbol) {
        try {
          const tdData = await fetchFromTwelveData(tdSymbol);
          const parsed = parseTwelveDataQuote(tdData);

          if (parsed && !parsed.error) {
            return res.json({
              symbol: requested,
              resolvedSymbol: tdSymbol,
              name: requested,
              price: parsed.price,
              changePct: parsed.changePct,
              provider: "twelvedata",
            });
          }
        } catch {
          // fall through
        }
      }

      return res.status(404).json({
        error: "FX/metals not available from current providers",
        requested,
        resolved: finnhubSymbol,
      });
    }

    console.error("[marketInfo] Finnhub error:", status, data || err?.message || err);

    return res.status(500).json({
      error: "Failed to fetch market info (finnhub)",
    });
  }
}
