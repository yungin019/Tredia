import type { Request, Response } from "express";
import {
  getAiDashboardSnapshot,
  getDailyBriefSnapshot,
  getNewsRadarSnapshot,
} from "../services/aiDashboardService";
import { chatWithAssistantForUser, AiMessageLimitError } from "../services/assistantService";

export async function getAiDashboard(req: Request, res: Response) {
  try {
    const snapshot = await getAiDashboardSnapshot();

    const moversLimit = typeof req.query.moversLimit === "string" ? parseInt(req.query.moversLimit, 10) : null;
    const trendingLimit = typeof req.query.trendingLimit === "string" ? parseInt(req.query.trendingLimit, 10) : null;
    const newsLimit = typeof req.query.newsLimit === "string" ? parseInt(req.query.newsLimit, 10) : null;

    return res.json({
      ...snapshot,
      movers: moversLimit ? (snapshot.movers || []).slice(0, Math.max(0, moversLimit)) : snapshot.movers || [],
      trending: trendingLimit ? (snapshot.trending || []).slice(0, Math.max(0, trendingLimit)) : snapshot.trending || [],
      newsRadar: newsLimit ? (snapshot.newsRadar || []).slice(0, Math.max(0, newsLimit)) : snapshot.newsRadar || [],
    });
  } catch (err: any) {
    console.error("[aiController] getAiDashboard error:", err);
    return res.status(500).json({
      error: "Failed to build AI dashboard snapshot.",
      message: err?.message || String(err),
    });
  }
}

export async function getDailyBrief(_req: Request, res: Response) {
  try {
    const brief = await getDailyBriefSnapshot();
    return res.json(brief);
  } catch (err: any) {
    console.error("[aiController] getDailyBrief error:", err);
    return res.status(500).json({
      error: "Failed to build daily brief.",
      message: err?.message || String(err),
    });
  }
}

export async function getNewsRadar(_req: Request, res: Response) {
  try {
    const news = await getNewsRadarSnapshot();
    return res.json(news);
  } catch (err: any) {
    console.error("[aiController] getNewsRadar error:", err);
    return res.status(500).json({
      error: "Failed to build news radar.",
      message: err?.message || String(err),
    });
  }
}

export async function chatWithAssistant(req: Request, res: Response) {
  try {
    const userId = (req as any).userId;
    const { messages } = req.body;

    const result = await chatWithAssistantForUser(userId, messages);
    return res.json(result);
  } catch (err: any) {
    if (err instanceof AiMessageLimitError) {
      return res.status(429).json({
        error: "Message limit reached.",
        message: err.message,
      });
    }
    console.error("[aiController] chat error:", err);
    return res.status(500).json({
      error: "Failed to chat with assistant.",
      message: err?.message || String(err),
    });
  }
}

export function aiHealth(_req: Request, res: Response) {
  return res.json({
    status: "ok",
    service: "ai",
    time: new Date().toISOString(),
  });
}
