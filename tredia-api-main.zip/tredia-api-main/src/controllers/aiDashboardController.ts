
import type { Request, Response } from "express";
import { getAiDashboardSnapshot, getDailyBriefSnapshot, getNewsRadarSnapshot } from "../services/aiDashboardService";

export async function getAiDashboard(_req: Request, res: Response) {
  try {
    const data = await getAiDashboardSnapshot();
    res.json({
      movers: Array.isArray(data?.movers) ? data.movers : [],
      trending: Array.isArray(data?.trending) ? data.trending : [],
      newsRadar: Array.isArray(data?.newsRadar) ? data.newsRadar : [],
      generatedAt: data?.generatedAt || new Date().toISOString(),
    });
  } catch {
    res.json({ movers: [], trending: [], newsRadar: [], generatedAt: new Date().toISOString() });
  }
}

export async function getDailyBriefHandler(_req: Request, res: Response) {
  try {
    const brief = await getDailyBriefSnapshot();
    res.json(brief);
  } catch {
    res.json({});
  }
}

export async function getNewsRadarHandler(_req: Request, res: Response) {
  try {
    const news = await getNewsRadarSnapshot();
    res.json(news);
  } catch {
    res.json({});
  }
}
