// src/controllers/tradeController.ts
import type { Request, Response } from "express";
import { prisma } from "../db";

function getUserIdOr401(req: Request, res: Response): number | null {
  const userId = req.user?.id;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  return userId;
}

// POST /api/trade-intent
export const createTradeIntent = async (req: Request, res: Response) => {
  const userId = getUserIdOr401(req, res);
  if (!userId) return;

  const { symbol, side, quantity, price, assetType } = req.body as {
    symbol?: string;
    side?: "BUY" | "SELL";
    quantity?: number;
    price?: number;
    assetType?: string;
  };

  if (!symbol || !side || !quantity || !price) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  const trade = await prisma.tradeHistory.create({
    data: {
      userId,
      symbol,
      side,
      qty: quantity,
      price,
      timestamp: new Date(),
    },
  });

  return res.json({
    intentId: trade.id,
    status: "PENDING_CONFIRMATION",
    trade: {
      symbol,
      side,
      quantity,
      price,
      assetType: assetType ?? "stock",
    },
  });
};

// POST /api/trade-confirm
export const confirmTrade = async (req: Request, res: Response) => {
  const userId = getUserIdOr401(req, res);
  if (!userId) return;

  const { intentId } = req.body as { intentId?: number };
  if (!intentId) return res.status(400).json({ error: "Missing intentId" });

  const trade = await prisma.tradeHistory.findFirst({
    where: { id: intentId, userId },
  });

  if (!trade) return res.status(404).json({ error: "Intent not found" });

  return res.json({ status: "CONFIRMED", trade });
};
