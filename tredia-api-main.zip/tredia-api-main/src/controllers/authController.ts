// src/controllers/authController.ts
import type { Request, Response } from "express";
import prisma from "../lib/prisma";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import type { PlanName } from "../types/auth";

const JWT_SECRET = process.env.JWT_SECRET || "dev_secret_key";

function normalizePlanName(dbName?: string | null): PlanName {
  const n = String(dbName || "").toUpperCase();
  if (n === "PRO") return "PRO";
  if (n === "ELITE") return "ELITE";
  return "FREE";
}

function generateToken(userId: number, email: string, planName: PlanName) {
  return jwt.sign({ userId, email, planName }, JWT_SECRET, { expiresIn: "7d" });
}

/* ============================================================
   REGISTER WITH EMAIL + PASSWORD
   ============================================================ */
export const registerEmail = async (req: Request, res: Response) => {
  try {
    const { email, password, displayName } = req.body as {
      email?: string;
      password?: string;
      displayName?: string;
    };

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password required" });
    }

    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) {
      return res.status(400).json({ error: "Email already in use" });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    // IMPORTANT: your seed uses "FREE" (uppercase)
    const freePlan = await prisma.plan.findUnique({ where: { name: "FREE" } });

    const user = await prisma.user.create({
      data: {
        email,
        passwordHash,
        displayName: displayName || null,
        planId: freePlan?.id ?? null,
      },
      include: { plan: true },
    });

    const planName = normalizePlanName(user.plan?.name);
    const token = generateToken(user.id, user.email, planName);

    return res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        displayName: user.displayName,
        planName,
      },
    });
  } catch (err) {
    console.error("EMAIL REGISTER ERROR", err);
    return res.status(500).json({ error: "Server error" });
  }
};

/* ============================================================
   LOGIN WITH EMAIL + PASSWORD
   ============================================================ */
export const loginEmail = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body as { email?: string; password?: string };

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password required" });
    }

    const user = await prisma.user.findUnique({
      where: { email },
      include: { plan: true },
    });

    if (!user || !user.passwordHash) {
      return res.status(400).json({ error: "Invalid credentials" });
    }

    const isValid = await bcrypt.compare(password, user.passwordHash);
    if (!isValid) {
      return res.status(400).json({ error: "Invalid credentials" });
    }

    const planName = normalizePlanName(user.plan?.name);
    const token = generateToken(user.id, user.email, planName);

    return res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        displayName: user.displayName,
        planName,
      },
    });
  } catch (err) {
    console.error("EMAIL LOGIN ERROR", err);
    return res.status(500).json({ error: "Server error" });
  }
};

/* ============================================================
   GOOGLE LOGIN (DEV MODE)
   ============================================================ */
export const googleLogin = async (req: Request, res: Response) => {
  try {
    const { idToken } = req.body as { idToken?: string };

    if (!idToken) {
      return res.status(400).json({ error: "Missing idToken" });
    }

    const email = `${String(idToken).slice(0, 12)}@google-temp.dev`;
    const freePlan = await prisma.plan.findUnique({ where: { name: "FREE" } });

    let user = await prisma.user.findUnique({
      where: { email },
      include: { plan: true },
    });

    if (!user) {
      user = await prisma.user.create({
        data: {
          email,
          passwordHash: "",
          planId: freePlan?.id ?? null,
        },
        include: { plan: true },
      });
    }

    const planName = normalizePlanName(user.plan?.name);
    const token = generateToken(user.id, user.email, planName);

    return res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        displayName: user.displayName,
        planName,
      },
    });
  } catch (err) {
    console.error("GOOGLE LOGIN ERROR", err);
    return res.status(500).json({ error: "Server error" });
  }
};

/* ============================================================
   APPLE LOGIN (DEV MODE)
   ============================================================ */
export const appleLogin = async (req: Request, res: Response) => {
  try {
    const { identityToken } = req.body as { identityToken?: string };

    if (!identityToken) {
      return res.status(400).json({ error: "Missing identityToken" });
    }

    const email = `${String(identityToken).slice(0, 12)}@apple-temp.dev`;
    const freePlan = await prisma.plan.findUnique({ where: { name: "FREE" } });

    let user = await prisma.user.findUnique({
      where: { email },
      include: { plan: true },
    });

    if (!user) {
      user = await prisma.user.create({
        data: {
          email,
          passwordHash: "",
          planId: freePlan?.id ?? null,
        },
        include: { plan: true },
      });
    }

    const planName = normalizePlanName(user.plan?.name);
    const token = generateToken(user.id, user.email, planName);

    return res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        displayName: user.displayName,
        planName,
      },
    });
  } catch (err) {
    console.error("APPLE LOGIN ERROR", err);
    return res.status(500).json({ error: "Server error" });
  }
};
