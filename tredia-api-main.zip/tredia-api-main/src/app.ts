/**
 * CLEAN placeholder file.
 *
 * Historically this project used app.ts as main entry,
 * but now the real entrypoint and route mounting only
 * happens in src/index.ts.
 *
 * This file stays only to prevent import errors.
 */

export {};
