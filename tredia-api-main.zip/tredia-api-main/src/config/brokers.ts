// src/config/brokers.ts
export const SUPPORTED_BROKERS = [
  {
    id: "binance",
    name: "Binance",
    type: "crypto",
    canTrade: true,
  },
  {
    id: "etoro",
    name: "eToro",
    type: "multi",
    canTrade: false, // deep-link only, no official API
  },
  {
    id: "ibkr",
    name: "Interactive Brokers",
    type: "stocks",
    canTrade: true,
  },
  {
    id: "trading212",
    name: "Trading 212",
    type: "stocks",
    canTrade: false, // deep-link only
  },
];
