// src/config/planLimits.ts

export type PlanName = "FREE" | "PRO" | "ELITE";

export const PLAN_PRICES: Record<PlanName, number> = {
  FREE: 0,
  PRO: 99, // SEK / month
  ELITE: 179, // SEK / month (normal Elite price)
};

/**
 * Daily AI message limits per plan.
 * null = unlimited (still logged in DB, but not blocked).
 */
export const PLAN_AI_LIMITS: Record<PlanName, { daily: number | null }> = {
  FREE: { daily: 10 },
  PRO: { daily: 100 },
  ELITE: { daily: null },
};

/**
 * Normalize a DB plan row into a PlanName ("FREE" | "PRO" | "ELITE").
 * Anything unknown falls back to FREE.
 */
export function getPlanNameFromDb(
  plan?: { name?: string | null } | null
): PlanName {
  const raw = plan?.name?.toUpperCase();

  if (raw === "PRO") return "PRO";
  if (raw === "ELITE") return "ELITE";
  return "FREE";
}

/**
 * Get the daily AI limit for a given plan.
 * Returns a number or null (for unlimited).
 */
export function getDailyAiLimit(planName: PlanName): number | null {
  return PLAN_AI_LIMITS[planName].daily;
}
