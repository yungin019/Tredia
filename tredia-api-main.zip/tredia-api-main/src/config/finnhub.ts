// src/config/finnhub.ts
import axios from "axios";

export const FINNHUB_API_KEY = process.env.FINNHUB_API_KEY || "";

export const finnhubClient = axios.create({
  baseURL: "https://finnhub.io/api/v1",
  timeout: 15000,
  params: {
    token: FINNHUB_API_KEY,
  },
});
