import axios from "axios";

const key = process.env.TWELVEDATA_API_KEY;

export const twelvedataClient = axios.create({
  baseURL: "https://api.twelvedata.com",
  timeout: 15000,
  params: key ? { apikey: key } : {},
});

export function hasTwelveData() {
  return !!key;
}
