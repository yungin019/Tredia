// src/middleware/requireAuth.ts
import type { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import prisma from "../lib/prisma";
import type { AuthedUser, PlanName } from "../types/auth";

type JwtPayload = {
  userId: number;
  email?: string;
  planName?: string; // legacy token field
};

const JWT_SECRET = process.env.JWT_SECRET || "dev-secret";

function normalizePlanName(raw: unknown): PlanName {
  const p = String(raw ?? "").trim().toUpperCase();
  if (p === "ELITE") return "ELITE";
  if (p === "PRO") return "PRO";
  return "FREE";
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;

  if (!header || !header.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or invalid Authorization header." });
  }

  const token = header.slice("Bearer ".length);

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as JwtPayload;

    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      include: { plan: true, wallet: true },
    });

    if (!user) {
      return res.status(401).json({ error: "User not found." });
    }

    const planName = normalizePlanName(user.plan?.name ?? decoded.planName);

    const authedUser: AuthedUser = {
      id: user.id,
      email: user.email,
      displayName: user.displayName ?? null,
      planName,
      plan: user.plan
        ? {
            id: user.plan.id,
            name: user.plan.name,
            description: user.plan.description ?? null,
            priceMonthly: user.plan.priceMonthly ?? null,
            currency: user.plan.currency ?? null,
          }
        : null,
      wallet: user.wallet
        ? {
            id: user.wallet.id,
            balance: user.wallet.balance,
            currency: user.wallet.currency,
          }
        : null,
    };

    req.user = authedUser;
    req.isElite = authedUser.planName === "ELITE";

    return next();
  } catch (err) {
    console.error("[requireAuth] Invalid token", err);
    return res.status(401).json({ error: "Invalid token." });
  }
}
