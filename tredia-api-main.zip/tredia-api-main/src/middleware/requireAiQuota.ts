// src/middleware/requireAiQuota.ts
import { Request, Response, NextFunction } from "express";

/**
 * AI quota middleware.
 *
 * We used to enforce AI usage limits here via aiLimiterService.
 * Now all AI limits are enforced in the assistant layer itself
 * (where we log usage and check per-plan limits in the DB).
 *
 * This middleware is kept only so:
 *   - existing imports keep working
 *   - routes that use `requireAiQuota` don’t break
 * But it no longer blocks any request by itself.
 */
export async function requireAiQuota(
  _req: Request,
  _res: Response,
  next: NextFunction
): Promise<void> {
  // If you ever want to hard-block again at route level,
  // you can reintroduce checks here.
  next();
}

// default export for old imports: `import requireAiQuota from "..."`
export default requireAiQuota;
