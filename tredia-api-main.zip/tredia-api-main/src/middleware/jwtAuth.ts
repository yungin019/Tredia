// src/middleware/jwtAuth.ts
import type { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import prisma from "../lib/prisma";
import type { PlanName } from "../config/planLimits";
import type { AuthedUser } from "../types/auth";

type JwtPayload = {
  userId: number;
  email?: string;
  planName?: string;
};

function normalizePlanName(raw: unknown): PlanName {
  const p = String(raw ?? "").trim().toUpperCase();
  if (p === "ELITE") return "ELITE";
  if (p === "PRO") return "PRO";
  return "FREE";
}

export async function requireJwtAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;

  if (!authHeader?.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const token = authHeader.slice(7);

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "dev_secret_key") as JwtPayload;

    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      include: { plan: true, wallet: true },
    });

    if (!user) {
      return res.status(401).json({ error: "User not found" });
    }

    const planName: PlanName = normalizePlanName(user.plan?.name ?? decoded.planName);

    const authedUser: AuthedUser = {
      id: user.id,
      email: user.email,
      displayName: user.displayName ?? null,
      planName,
      plan: user.plan
        ? {
            id: user.plan.id,
            name: user.plan.name,
            description: user.plan.description ?? null,
            priceMonthly: user.plan.priceMonthly ?? null,
            currency: user.plan.currency ?? null,
          }
        : null,
      wallet: user.wallet
        ? {
            id: user.wallet.id,
            balance: user.wallet.balance,
            currency: user.wallet.currency,
          }
        : null,
    };

    req.user = authedUser;
    req.isElite = authedUser.planName === "ELITE";

    return next();
  } catch {
    return res.status(401).json({ error: "Invalid token" });
  }
}
