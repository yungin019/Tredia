import rateLimit from "express-rate-limit";
import type { Request } from "express";

export const aiDashboardLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => {
    // IPv6-safe fallback
    return req.ip || req.headers["x-forwarded-for"]?.toString() || "unknown";
  },
});
