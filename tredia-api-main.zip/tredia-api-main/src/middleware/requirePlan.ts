// src/middleware/requirePlan.ts
import { Request, Response, NextFunction } from "express";

export function requirePlan(
  req: Request,
  res: Response,
  next: NextFunction
) {
  const anyReq = req as any;
  const user = anyReq.user;

  if (!user) {
    return res.status(401).json({ error: "Not authenticated" });
  }

  // If later you want to hard-enforce active subscription, you can do:
  // if (!user.plan) {
  //   return res.status(403).json({ error: "No active plan found" });
  // }

  next();
}
