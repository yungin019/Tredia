// src/middleware/auth.ts
import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "dev-secret";

export interface AuthRequest extends Request {
  userId?: number;
}

/**
 * Strict auth: used for routes that MUST have a real token.
 */
export function requireAuth(
  req: AuthRequest,
  res: Response,
  next: NextFunction
) {
  const header = req.headers.authorization;

  if (!header || !header.startsWith("Bearer ")) {
    return res
      .status(401)
      .json({ error: "Missing or invalid Authorization header." });
  }

  const token = header.replace("Bearer ", "");

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: number };
    req.userId = decoded.userId;
    return next();
  } catch (err) {
    console.error("[auth] Invalid token", err);
    return res.status(401).json({ error: "Invalid token." });
  }
}

/**
 * DEV-FRIENDLY auth:
 * - If a valid Bearer token is present, we use it
 * - If NOT, we silently fall back to `userId = 1`
 *
 * This avoids 401 for endpoints we want usable
 * even when mobile login is not fully wired.
 */
export function optionalAuth(
  req: AuthRequest,
  res: Response,
  next: NextFunction
) {
  const header = req.headers.authorization;

  if (!header || !header.startsWith("Bearer ")) {
    // No token → dev fallback to demo user 1
    (req as any).userId = 1;
    return next();
  }

  const token = header.replace("Bearer ", "");

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: number };
    req.userId = decoded.userId;
    return next();
  } catch (err) {
    console.warn("[auth optional] Invalid token, using demo user 1");
    (req as any).userId = 1;
    return next();
  }
}
