// src/middleware/requireElite.ts
import type { Request, Response, NextFunction } from "express";
import type { PlanName } from "../config/planLimits";

function normalizePlanName(raw: unknown): PlanName {
  const p = String(raw ?? "").trim().toUpperCase();
  if (p === "ELITE") return "ELITE";
  if (p === "PRO") return "PRO";
  return "FREE";
}

export function requireElite(req: Request, res: Response, next: NextFunction) {
  const planRaw = (req as any).user?.plan?.name ?? (req as any).user?.planName ?? null;
  const planName = normalizePlanName(planRaw);

  if (planName !== "ELITE") {
    return res.status(403).json({ error: "Elite plan required", planName });
  }

  return next();
}
