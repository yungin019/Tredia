// src/middleware/aiPlanGuard.ts

import type { Request, Response, NextFunction } from "express";
import prisma from "../lib/prisma";
import {
  PLAN_AI_LIMITS,
  getPlanNameFromDb,
  type PlanName,
} from "../config/planLimits";

// Ensure we track "per calendar day"
function getTodayMidnight(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

export interface AiPlanInfo {
  planName: PlanName;
  aiDailyLimit: number | null;
  usedToday: number;
  remainingToday: number | null;
}

// augment Express.Request so TS is happy
declare module "express-serve-static-core" {
  interface Request {
    aiPlan?: AiPlanInfo;
  }
}

/**
 * aiPlanGuard
 *
 * - figures out the user's plan (FREE / PRO / ELITE)
 * - checks today's AI usage against PLAN_AI_LIMITS
 * - increments usage if allowed
 * - blocks with 429 + details if the daily limit is reached
 */
export async function aiPlanGuard(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    // ----- 1) Get user id (support both .user.id and .userId patterns) -----
    const authed = (req as any).user as
      | { id?: number; plan?: any | null }
      | undefined;

    const userId =
      authed?.id ?? ((req as any).userId as number | undefined);

    // If no authenticated user: treat as FREE & no DB tracking
    if (!userId) {
      const planName: PlanName = "FREE";
      const cfg = PLAN_AI_LIMITS[planName];
      req.aiPlan = {
        planName,
        aiDailyLimit: cfg.daily ?? null,
        usedToday: 0,
        remainingToday: cfg.daily ?? null,
      };
      return next();
    }

    // ----- 2) Load user + plan from DB -----
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { plan: true },
    });

    const planName: PlanName = getPlanNameFromDb(user?.plan);
    const cfg = PLAN_AI_LIMITS[planName];
    const dailyLimit = cfg.daily ?? null;

    // Unlimited plan (e.g. ELITE with daily: null)
    if (dailyLimit === null) {
      // Optionally still track usage, but not required
      req.aiPlan = {
        planName,
        aiDailyLimit: null,
        usedToday: 0,
        remainingToday: null,
      };
      return next();
    }

    // ----- 3) Read today's usage -----
    const today = getTodayMidnight();

    const existing = await prisma.aiUsage.findFirst({
      where: {
        userId,
        date: today,
      },
    });

    const used = existing?.count ?? 0;

    if (used >= dailyLimit) {
      // Daily limit reached → block and tell the app to open paywall
      return res.status(429).json({
        error: "AI_DAILY_LIMIT_REACHED",
        planName,
        aiDailyLimit: dailyLimit,
        usedToday: used,
        remainingToday: 0,
        message:
          "You’ve reached your daily AI messages for this plan. Upgrade to PRO or ELITE to unlock more.",
      });
    }

    // ----- 4) Increment usage by 1 -----
    if (existing) {
      const updated = await prisma.aiUsage.update({
        where: { id: existing.id },
        data: { count: { increment: 1 } },
      });

      const remaining = Math.max(0, dailyLimit - updated.count);

      req.aiPlan = {
        planName,
        aiDailyLimit: dailyLimit,
        usedToday: updated.count,
        remainingToday: remaining,
      };
    } else {
      const created = await prisma.aiUsage.create({
        data: {
          userId,
          date: today,
          count: 1,
        },
      });

      const remaining = Math.max(0, dailyLimit - created.count);

      req.aiPlan = {
        planName,
        aiDailyLimit: dailyLimit,
        usedToday: created.count,
        remainingToday: remaining,
      };
    }

    return next();
  } catch (err) {
    console.error("[aiPlanGuard] error:", err);
    // If guard fails, better to fail CLOSED (no free infinite AI)
    return res.status(500).json({
      error: "AI_PLAN_GUARD_ERROR",
      message: "Could not verify your AI plan, please try again later.",
    });
  }
}
