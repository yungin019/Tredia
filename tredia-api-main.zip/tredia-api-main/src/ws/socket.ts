// src/ws/socket.ts
import type http from "http";
import { Server } from "socket.io";

export function initSocket(server: http.Server) {
  const io = new Server(server, {
    cors: { origin: "*" }
  });

  io.on("connection", (socket) => {
    console.log("WS connected:", socket.id);

    const interval = setInterval(() => {
      socket.emit("ai:update", { ts: new Date().toISOString() });
    }, 5000);

    socket.on("disconnect", () => {
      clearInterval(interval);
      console.log("WS disconnected:", socket.id);
    });
  });
}
