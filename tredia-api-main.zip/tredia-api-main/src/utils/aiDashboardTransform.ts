// src/utils/aiDashboardTransform.ts

/**
 * Minimal canonical types for the AI dashboard payload.
 * This is now decoupled from aiDashboardService to avoid circular
 * imports or broken type exports.
 */

export interface AiDashboardSignal {
  label: string;
  detail: string;
}

export interface AiDashboardRaw {
  news?: any[];
  markets?: {
    indexes?: any[];
    crypto?: any[];
    [key: string]: any;
  };
  updatedAt?: string;
  signals?: AiDashboardSignal[];
  [key: string]: any;
}

/**
 * Ensure the dashboard payload has a safe, consistent shape
 * so the mobile app never crashes on missing fields.
 */
export function ensureDashboardShape(raw: any): AiDashboardRaw {
  const news = Array.isArray(raw?.news) ? raw.news : [];

  const markets =
    raw && typeof raw.markets === "object"
      ? {
          indexes: Array.isArray(raw.markets.indexes)
            ? raw.markets.indexes
            : [],
          crypto: Array.isArray(raw.markets.crypto)
            ? raw.markets.crypto
            : [],
          ...raw.markets,
        }
      : {
          indexes: [],
          crypto: [],
        };

  const signals: AiDashboardSignal[] = Array.isArray(raw?.signals)
    ? raw.signals
        .filter(
          (s: any) => s && typeof s.label === "string"
        )
        .map((s: any) => ({
          label: String(s.label),
          detail: typeof s.detail === "string" ? s.detail : "",
        }))
    : [];

  const updatedAt =
    typeof raw?.updatedAt === "string"
      ? raw.updatedAt
      : new Date().toISOString();

  return {
    news,
    markets,
    updatedAt,
    signals,
  };
}
