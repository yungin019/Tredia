// src/routes/superAi.ts
import { Router } from "express";
import { requireJwtAuth } from "../middleware/jwtAuth";
import { requireElite } from "../middleware/requireElite";
import { getSuperAI } from "../controllers/superAiController";

const router = Router();

// Mobile expects: POST /api/super-ai/chat { message: "..." }
router.post("/chat", requireJwtAuth, requireElite, (req: any, res: any) => {
  // Map {message} -> {prompt} for controller
  const { message, prompt, symbols } = req.body ?? {};
  req.body = { prompt: prompt ?? message, symbols };
  return getSuperAI(req, res);
});

// Back-compat
router.post("/", requireJwtAuth, requireElite, getSuperAI);

export default router;
