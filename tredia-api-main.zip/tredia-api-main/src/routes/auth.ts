// src/routes/auth.ts
import express from "express";
import {
  registerEmail,
  loginEmail,
  appleLogin,
  googleLogin,
} from "../controllers/authController";

const router = express.Router();

// Email + password
router.post("/register", registerEmail);
router.post("/login", loginEmail);

// Social logins (DEV mode: Google / Apple)
router.post("/apple", appleLogin);
router.post("/google", googleLogin);

export default router;
