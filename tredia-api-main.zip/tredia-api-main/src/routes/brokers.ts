// src/routes/brokers.ts

import { Router } from "express";
import {
  getPlatforms,
  getUserBrokerAccount,
  connectBroker,
  disconnectBroker,
  getTradeDeeplink,
  getBrokerPortfolio,
} from "../controllers/brokerController";
import { requireAuth } from "../middleware/requireAuth";

const router = Router();

// Health check
// GET /api/brokers/health
router.get("/health", (_req, res) => {
  res.json({ ok: true });
});

// Broker platforms
// GET /api/brokers/platforms
router.get("/platforms", getPlatforms);

// Current user's broker account (auth required)
// GET /api/brokers/me
router.get("/me", requireAuth, getUserBrokerAccount);

// Connect broker (auth required)
// POST /api/brokers/connect
router.post("/connect", requireAuth, connectBroker);

// Disconnect broker (auth required)
// POST /api/brokers/disconnect
router.post("/disconnect", requireAuth, disconnectBroker);

// Trade deeplink for a symbol
// GET /api/brokers/deeplink?symbol=TSLA
router.get("/deeplink", requireAuth, getTradeDeeplink);

// LIVE PORTFOLIO (auth required)
// GET /api/brokers/portfolio
router.get("/portfolio", requireAuth, getBrokerPortfolio);

export default router;
