// src/routes/subscription.ts

import { Router } from "express";
import prisma from "../lib/prisma";
import { requireAuth } from "../middleware/requireAuth";
import {
  getPlanNameFromDb,
  PLAN_AI_LIMITS,
  PLAN_PRICES,
  PlanName,
} from "../config/planLimits";
import { getTodayUsage } from "../services/aiLimiterService";

const router = Router();

/**
 * GET /api/subscription/status
 * Returns plan + AI usage info (DB-driven).
 */
router.get("/status", requireAuth, async (req, res) => {
  const anyReq: any = req;
  const authUser = anyReq.user;

  if (!authUser) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const dbUser = await prisma.user.findUnique({
    where: { id: authUser.id },
    include: { plan: true },
  });

  if (!dbUser) {
    return res.status(404).json({ error: "User not found" });
  }

  const planName: PlanName = getPlanNameFromDb(dbUser.plan);
  const aiLimits = PLAN_AI_LIMITS[planName];
  const usage = await getTodayUsage(dbUser.id, planName);

  let listPriceMonthly: number | null = null;
  let founderPriceMonthly: number | null = null;
  let effectivePriceMonthly: number | null = null;

  if (planName === "FREE") {
    listPriceMonthly = PLAN_PRICES.FREE;
    effectivePriceMonthly = PLAN_PRICES.FREE;
  } else if (planName === "PRO") {
    listPriceMonthly = PLAN_PRICES.PRO;
    effectivePriceMonthly = PLAN_PRICES.PRO;
  } else if (planName === "ELITE") {
    listPriceMonthly = PLAN_PRICES.ELITE;

    if (dbUser.isFounder && dbUser.founderPriceMonthly != null) {
      founderPriceMonthly = dbUser.founderPriceMonthly;
      effectivePriceMonthly = dbUser.founderPriceMonthly;
    } else {
      effectivePriceMonthly = PLAN_PRICES.ELITE;
    }
  }

  return res.json({
    userId: dbUser.id,
    tier: planName,
    planId: dbUser.planId,
    isFounder: !!dbUser.isFounder,
    listPriceMonthly,
    founderPriceMonthly,
    effectivePriceMonthly,
    referralBonusCredits: dbUser.referralBonusCredits ?? 0,
    introDiscountEligible: !!dbUser.introDiscountEligible,
    ai: {
      dailyLimit: aiLimits.daily,
      usedToday: usage.used,
      remainingToday: usage.remaining,
    },
  });
});

export default router;
