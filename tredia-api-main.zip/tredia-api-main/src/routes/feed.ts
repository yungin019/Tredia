// src/routes/feed.ts
import { Router, Request, Response } from "express";
import axios from "axios";

const router = Router();

// Types should roughly match what the mobile app expects
type NewsItem = {
  id: string;
  title: string;
  summary: string;
  source: string;
  publishedAt: string;
  url: string;
  imageUrl?: string | null;
  sentimentScore?: number | null;
  tickers?: string[];
};

type MarketItem = {
  symbol: string;
  name: string;
  type: "CRYPTO" | "STOCK" | "FOREX";
  price: number;
  change: number;
  changePercent: number;
};

type AiHighlight = {
  id: string;
  title: string;
  summary: string;
  riskLevel: "LOW" | "MEDIUM" | "HIGH";
  timeHorizon: "SHORT" | "MID" | "LONG";
};

// Small helper to avoid repeating code
async function fetchMarketSnapshot(): Promise<MarketItem[]> {
  const finnhubKey = process.env.FINNHUB_API_KEY;
  if (!finnhubKey) {
    console.warn("[/feed] FINNHUB_API_KEY missing in .env");
    // Return a safe fallback so the app still works
    return [
      {
        symbol: "AAPL",
        name: "Apple Inc.",
        type: "STOCK",
        price: 190,
        change: 2.3,
        changePercent: 1.23,
      },
      {
        symbol: "TSLA",
        name: "Tesla Inc.",
        type: "STOCK",
        price: 210,
        change: -3.5,
        changePercent: -1.64,
      },
      {
        symbol: "BTC-USD",
        name: "Bitcoin",
        type: "CRYPTO",
        price: 64000,
        change: 800,
        changePercent: 1.27,
      },
      {
        symbol: "ETH-USD",
        name: "Ethereum",
        type: "CRYPTO",
        price: 3400,
        change: -45,
        changePercent: -1.30,
      },
    ];
  }

  // Watchlist for now – you can extend this later
  const symbols = [
    { symbol: "AAPL", name: "Apple Inc.", type: "STOCK" as const },
    { symbol: "TSLA", name: "Tesla Inc.", type: "STOCK" as const },
    { symbol: "MSFT", name: "Microsoft", type: "STOCK" as const },
    { symbol: "NVDA", name: "NVIDIA", type: "STOCK" as const },
    { symbol: "BINANCE:BTCUSDT", name: "Bitcoin", type: "CRYPTO" as const },
    { symbol: "BINANCE:ETHUSDT", name: "Ethereum", type: "CRYPTO" as const },
  ];

  const baseUrl = "https://finnhub.io/api/v1/quote";

  const results: MarketItem[] = [];

  for (const asset of symbols) {
    try {
      const resp = await axios.get(baseUrl, {
        params: {
          symbol: asset.symbol,
          token: finnhubKey,
        },
      });

      const data = resp.data as {
        c: number; // current price
        pc: number; // previous close
      };

      const price = data.c ?? 0;
      const prev = data.pc ?? 0;
      const change = prev ? price - prev : 0;
      const changePercent = prev ? (change / prev) * 100 : 0;

      results.push({
        symbol: asset.symbol,
        name: asset.name,
        type: asset.type,
        price,
        change,
        changePercent,
      });
    } catch (err) {
      console.warn("[/feed/markets] Finnhub error for", asset.symbol, err);
    }
  }

  // If API completely fails, still return a minimal safe fallback
  if (results.length === 0) {
    return [
      {
        symbol: "AAPL",
        name: "Apple Inc.",
        type: "STOCK",
        price: 190,
        change: 2.3,
        changePercent: 1.23,
      },
      {
        symbol: "BTC-USD",
        name: "Bitcoin",
        type: "CRYPTO",
        price: 64000,
        change: 800,
        changePercent: 1.27,
      },
    ];
  }

  return results;
}

/**
 * GET /feed/news
 * Returns curated business/crypto news
 */
router.get("/news", async (req: Request, res: Response) => {
  const newsApiKey = process.env.NEWS_API_KEY;

  try {
    if (!newsApiKey) {
      console.warn("[/feed/news] NEWS_API_KEY missing in .env – using fallback");
      const fallback: NewsItem[] = [
        {
          id: "fallback-1",
          title: "Markets stay volatile while investors await key inflation data",
          summary:
            "Global markets traded sideways today as investors waited for fresh inflation numbers and central bank guidance.",
          source: "Tredia Insights",
          publishedAt: new Date().toISOString(),
          url: "https://example.com/fallback",
          imageUrl: null,
          sentimentScore: 0.0,
          tickers: ["SPY", "BTC-USD"],
        },
      ];
      return res.json({ articles: fallback });
    }

    // Example with NewsAPI
    const resp = await axios.get("https://newsapi.org/v2/top-headlines", {
      params: {
        category: "business",
        language: "en",
        pageSize: 20,
        apiKey: newsApiKey,
      },
    });

    const data = resp.data as {
      articles: {
        title: string;
        description: string | null;
        url: string;
        urlToImage?: string | null;
        source: { name: string | null };
        publishedAt: string;
      }[];
    };

    const mapped: NewsItem[] = (data.articles || []).map((a, idx) => ({
      id: a.url || `news-${idx}`,
      title: a.title,
      summary: a.description ?? "",
      source: a.source?.name || "Unknown",
      publishedAt: a.publishedAt,
      url: a.url,
      imageUrl: a.urlToImage ?? null,
      sentimentScore: null,
      tickers: [],
    }));

    res.json({ articles: mapped });
  } catch (err) {
    console.error("[/feed/news] error", err);
    res.status(500).json({
      error: "Failed to load news",
    });
  }
});

/**
 * GET /feed/markets
 * Returns a snapshot of selected stocks & crypto
 */
router.get("/markets", async (_req: Request, res: Response) => {
  try {
    const items = await fetchMarketSnapshot();
    res.json({ items });
  } catch (err) {
    console.error("[/feed/markets] error", err);
    res.status(500).json({
      error: "Failed to load markets",
    });
  }
});

/**
 * GET /feed/summary
 * Returns a simple AI-style highlight based on the biggest mover
 * (for now purely algorithmic, not calling OpenAI – safe + fast)
 */
router.get("/summary", async (_req: Request, res: Response) => {
  try {
    const items = await fetchMarketSnapshot();

    if (!items.length) {
      const fallback: AiHighlight = {
        id: "no-data",
        title: "No clear signal yet",
        summary:
          "We couldn't fetch enough market data right now. Check back in a few minutes, or refresh your feed.",
        riskLevel: "LOW",
        timeHorizon: "SHORT",
      };
      return res.json({ highlight: fallback });
    }

    const sorted = [...items].sort(
      (a, b) => Math.abs(b.changePercent) - Math.abs(a.changePercent)
    );
    const top = sorted[0];

    const direction = top.changePercent >= 0 ? "up" : "down";
    const riskLevel: AiHighlight["riskLevel"] =
      Math.abs(top.changePercent) > 5
        ? "HIGH"
        : Math.abs(top.changePercent) > 2
        ? "MEDIUM"
        : "LOW";

    const highlight: AiHighlight = {
      id: top.symbol,
      title: `${top.symbol} is moving ${direction}`,
      summary: `Today, ${top.name} (${top.symbol}) is moving ${direction} about ${top.changePercent.toFixed(
        2
      )}%. This doesn't mean you should rush in or panic, but it tells you where attention is right now.\n\nUse this as a signal to let the AI assistant explain:\n- Why this asset might be moving\n- What the main risks are\n- How a calm, beginner-friendly plan could look.`,
      riskLevel,
      timeHorizon: "SHORT",
    };

    res.json({ highlight });
  } catch (err) {
    console.error("[/feed/summary] error", err);
    res.status(500).json({
      error: "Failed to build AI highlight",
    });
  }
});

export default router;
