// src/routes/realTrades.ts

import express from "express";
import { requireAuth } from "../middleware/requireAuth";
import {
  getRealTrades,
  createRealTrade,
  deleteRealTrade,
} from "../controllers/realTradeController";

const router = express.Router();

// GET all real trades for the logged-in user
router.get("/", requireAuth, getRealTrades);

// POST a new real trade (manual log)
router.post("/", requireAuth, createRealTrade);

// DELETE a real trade (optional, safe)
router.delete("/:id", requireAuth, deleteRealTrade);

export default router;
