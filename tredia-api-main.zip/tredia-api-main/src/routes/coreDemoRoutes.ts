// src/routes/coreDemoRoutes.ts
import { Router } from "express";

const router = Router();

// small helper
function nowIso() {
  return new Date().toISOString();
}

/* =========================================================
 * HOME: AI DAILY BRIEF
 * GET /api/demo/ai/daily-brief
 * =======================================================*/
router.get("/ai/daily-brief", (_req, res) => {
  res.json({
    summary:
      "Global markets are mixed today. US tech leads upside, while crypto consolidates after a strong week. Risk sentiment is stable but volatility remains elevated.",
    generatedAt: nowIso(),
  });
});

/* =========================================================
 * HOME: MARKET MOVERS
 * GET /api/demo/markets/movers
 * =======================================================*/
router.get("/markets/movers", (_req, res) => {
  res.json([
    {
      symbol: "NVDA",
      name: "Nvidia Corp",
      changePct: 3.24,
      sparkline: [100, 102, 101, 104, 107, 110, 112],
    },
    {
      symbol: "BTC",
      name: "Bitcoin",
      changePct: 5.4,
      sparkline: [42000, 43000, 42500, 44500, 46000, 45500, 47000],
    },
    {
      symbol: "AAPL",
      name: "Apple Inc",
      changePct: -1.22,
      sparkline: [190, 189, 188, 187, 186, 188, 187],
    },
  ]);
});

/* =========================================================
 * HOME: TRENDING
 * GET /api/demo/markets/trending
 * =======================================================*/
router.get("/markets/trending", (_req, res) => {
  res.json([
    {
      symbol: "ETH",
      name: "Ethereum",
      changePct: 2.52,
      sparkline: [2200, 2250, 2230, 2300, 2350, 2400, 2380],
    },
    {
      symbol: "META",
      name: "Meta Platforms",
      changePct: 1.9,
      sparkline: [320, 322, 321, 325, 327, 329, 330],
    },
  ]);
});

/* =========================================================
 * ALERTS: SUPER AI DASHBOARD
 * GET /api/demo/ai-dashboard/overview
 * =======================================================*/
router.get("/ai-dashboard/overview", (_req, res) => {
  res.json({
    generatedAt: nowIso(),
    summary:
      "Super AI sees concentrated heat in AI semiconductors and large-cap crypto. Downside risk remains elevated in crowded growth names.",
    heatmap: [
      {
        symbol: "NVDA",
        name: "Nvidia Corp",
        assetClass: "stock",
        sector: "Semiconductors",
        changePct: 3.2,
        volatility: 0.75,
        aiBias: "bullish",
        aiConfidence: 0.86,
        sentimentScore: 0.7,
        jumpProbability: 0.55,
        heat: 0.88,
      },
      {
        symbol: "BTC",
        name: "Bitcoin",
        assetClass: "crypto",
        sector: "Crypto",
        changePct: 5.4,
        volatility: 0.9,
        aiBias: "bullish",
        aiConfidence: 0.81,
        sentimentScore: 0.65,
        jumpProbability: 0.6,
        heat: 0.9,
      },
    ],
    spotlight: [
      {
        symbol: "NVDA",
        name: "Nvidia Corp",
        assetClass: "stock",
        sector: "Semiconductors",
        direction: "long",
        heat: 0.88,
        changePct: 3.2,
        aiBias: "bullish",
        aiConfidence: 0.86,
        jumpProbability: 0.55,
        timeHorizon: "Next 3–10 days",
        thesis:
          "AI sees strong momentum in high-end chips, driven by data center demand.",
        riskNote:
          "High expectations are priced in; any guidance miss could cause a pullback.",
        suggestedEntry: 110,
        suggestedStop: 103,
        suggestedTarget: 120,
        aiComment:
          "A trend-following setup with strong momentum. Manage risk carefully.",
      },
    ],
  });
});

/* =========================================================
 * AI CHAT (AssistantScreen)
 * POST /api/demo/ai/chat
 * =======================================================*/
router.post("/ai/chat", (req, res) => {
  const message = req.body?.message || "";

  const reply =
    message.length > 0
      ? `Tredia AI reply to: "${message}".\n\nIn demo mode I use static logic. Real AI will connect to full Super AI pipeline.`
      : "Ask about markets, risk or trading setups.";

  res.json({
    reply,
    meta: {
      model: "demo-ai",
      latencyMs: 140,
      tokens: reply.length,
    },
  });
});

/* =========================================================
 * PORTFOLIO DEMO (PortfolioScreen)
 * GET /api/demo/paper/portfolio
 * =======================================================*/
router.get("/paper/portfolio", (_req, res) => {
  res.json({
    totalEquity: "€ 44 780",
    dailyChange: "+8.9%",
    positions: [
      { symbol: "BTC", name: "Bitcoin", value: "€ 34 000", change: "+18%" },
      { symbol: "ETH", name: "Ethereum", value: "€ 8 800", change: "+9%" },
      { symbol: "NVDA", name: "Nvidia", value: "€ 1 980", change: "-3.7%" },
    ],
  });
});

export default router;
