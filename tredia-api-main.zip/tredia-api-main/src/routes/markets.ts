// src/routes/markets.ts
import { Router, Request, Response } from "express";
import { getMarketInfo } from "../controllers/marketInfoController";
import { getMarketTrends } from "../services/marketService";
import { getNewsRadarSnapshot } from "../services/aiDashboardService";

const router = Router();

type AssetClass = "stock" | "crypto" | "forex" | "metal" | "etf" | "other";

function normalizeOutClass(cls: any): AssetClass {
  const c = String(cls || "").toLowerCase();

  // important: legacy "index" must map to "etf"
  if (c === "index") return "etf";

  if (c === "stock" || c === "equity") return "stock";
  if (c === "crypto" || c === "coin") return "crypto";
  if (c === "forex" || c === "fx") return "forex";
  if (c === "metal" || c === "metals" || c === "gold") return "metal";
  if (c === "etf" || c === "fund") return "etf";

  return "other";
}

/**
 * If an item comes back with missing assetClass, we infer it from symbol patterns.
 * This prevents "None" in your API response and keeps filters stable on mobile.
 */
function inferClassFromSymbol(symbol: any, fallback: AssetClass = "other"): AssetClass {
  const s = String(symbol || "").toUpperCase();
  if (!s) return fallback;

  // Polygon crypto often looks like "X:BTCUSD"
  if (s.startsWith("X:")) return "crypto";

  // Finnhub OANDA forex/metals baskets
  if (s.startsWith("OANDA:")) {
    if (s.includes("XAU") || s.includes("XAG")) return "metal";
    return "forex";
  }

  // Common ETF tickers you already use
  const ETF_SET = new Set(["SPY", "QQQ", "IWM", "DIA", "VTI", "VOO"]);
  if (ETF_SET.has(s)) return "etf";

  // If it looks like a normal equity ticker
  if (/^[A-Z.\-]{1,10}$/.test(s)) return "stock";

  return fallback;
}

function normalizeAsset(item: any) {
  const assetClass =
    item?.assetClass != null && String(item.assetClass).trim().length > 0
      ? normalizeOutClass(item.assetClass)
      : inferClassFromSymbol(item?.symbol, "other");

  return {
    ...item,
    assetClass,
  };
}

/**
 * GET /api/markets/trends
 * Unified market snapshot used by HomeScreen + MarketExplorer.
 * Always responds 200 with safe fallback.
 *
 * ✅ Uses marketService.getMarketTrends() (your new robust logic)
 * ✅ Fixes taxonomy: index -> etf
 * ✅ Guarantees assetClass is never missing
 * ✅ Keeps newsRadar (from aiDashboardService)
 */
router.get("/trends", async (_req: Request, res: Response) => {
  try {
    const [{ movers, trending }, news] = await Promise.all([
      getMarketTrends(),
      getNewsRadarSnapshot(),
    ]);

    const moversFixed = (movers || []).map(normalizeAsset);
    const trendingFixed = (trending || []).map(normalizeAsset);

    // Some clients expect both "items" + "newsRadar" (we keep both)
    const newsRadar = Array.isArray((news as any)?.items)
      ? (news as any).items
      : Array.isArray((news as any)?.newsRadar)
        ? (news as any).newsRadar
        : [];

    return res.status(200).json({
      movers: moversFixed,
      trending: trendingFixed,
      newsRadar,
      items: newsRadar,
      generatedAt: new Date().toISOString(),
      _controllerVersion:
        "routes/markets.ts -> marketService.getMarketTrends + aiDashboardService.getNewsRadarSnapshot (normalize index->etf, infer missing classes)",
    });
  } catch (err) {
    console.error("[markets/trends] error:", err);

    return res.status(200).json({
      movers: [],
      trending: [],
      newsRadar: [],
      items: [],
      generatedAt: new Date().toISOString(),
      _controllerVersion:
        "routes/markets.ts fallback (error)",
    });
  }
});

/**
 * GET /api/markets/info/:symbol
 */
router.get("/info/:symbol", getMarketInfo as any);

/**
 * GET /api/markets/ohlc/:symbol
 * Uses movers/trending series if available, otherwise safe fallback.
 */
router.get("/ohlc/:symbol", async (req: Request, res: Response) => {
  const raw = req.params.symbol;
  const symbol =
    typeof raw === "string" && raw.trim().length > 0
      ? raw.trim().toUpperCase()
      : null;

  if (!symbol) return res.status(200).json({ candles: [] });

  try {
    const { movers, trending } = await getMarketTrends();

    const all = [...(trending || []), ...(movers || [])];

    const asset = all.find(
      (a: any) =>
        typeof a?.symbol === "string" &&
        a.symbol.toUpperCase() === symbol
    );

    const baseSeries: number[] =
      Array.isArray(asset?.sparkline) && asset.sparkline.length > 0
        ? asset.sparkline
        : [100, 101, 102, 103, 104, 105];

    const now = Date.now();
    const stepMs = 60 * 60 * 1000;

    const candles = baseSeries.map((close, index) => {
      const prev = index === 0 ? close : baseSeries[index - 1];
      const open = prev;
      const high = Math.max(open, close) * 1.003;
      const low = Math.min(open, close) * 0.997;

      return {
        time: new Date(now - (baseSeries.length - 1 - index) * stepMs).toISOString(),
        open,
        high,
        low,
        close,
        volume: null,
      };
    });

    return res.status(200).json({ candles });
  } catch (err) {
    console.error("[markets/ohlc] error:", err);
    return res.status(200).json({ candles: [] });
  }
});

/**
 * Legacy aliases (keep)
 */
router.get("/global", (_req: Request, res: Response) =>
  res.redirect("/api/markets/trends")
);

router.get("/crypto", (_req: Request, res: Response) =>
  res.redirect("/api/markets/trends")
);

export default router;
