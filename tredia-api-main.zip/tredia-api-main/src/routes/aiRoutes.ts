import { Router } from "express";
import {
  getAiDashboard,
  getDailyBriefHandler,
  getNewsRadarHandler,
} from "../controllers/aiDashboardController";
import { aiDashboardLimiter } from "../middleware/rateLimit";

const router = Router();

router.get("/dashboard", aiDashboardLimiter, getAiDashboard);
router.get("/daily-brief", aiDashboardLimiter, getDailyBriefHandler);
router.get("/news-radar", aiDashboardLimiter, getNewsRadarHandler);

export default router;
