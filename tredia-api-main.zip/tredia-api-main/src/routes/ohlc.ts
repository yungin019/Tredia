// src/routes/ohlc.ts

import { Router } from "express";
import { getOHLC } from "../controllers/ohlcController";
import { requireAuth } from "../middleware/requireAuth";

const router = Router();

/**
 * GET /api/ohlc/:symbol
 * Optional: ?interval=5 | 15 | 30 | 60 | daily
 *
 * Example:
 *   /api/ohlc/AAPL?interval=15
 */
router.get("/:symbol", requireAuth, getOHLC);

export default router;
