// src/routes/marketInfo.ts
import { Router } from "express";
import { getMarketInfo } from "../controllers/marketInfoController";

const router = Router();

/**
 * Mounted under /api/markets
 * - /api/markets/info/:symbol
 * - /api/markets/info/        (symbol optional)
 */
router.get("/info/:symbol?", getMarketInfo);

export default router;
