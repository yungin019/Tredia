import { Router } from "express";
import { requireAuth } from "../middleware/requireAuth";
import { aiDashboardLimiter } from "../middleware/rateLimit";
import {
  aiHealth,
  getAiDashboard,
  getDailyBrief,
  getNewsRadar,
  chatWithAssistant,
} from "../controllers/aiController";

const router = Router();

router.get("/health", aiHealth);

// PUBLIC dashboard + snapshots
router.get("/dashboard", aiDashboardLimiter, getAiDashboard);
router.get("/daily-brief", aiDashboardLimiter, getDailyBrief);
router.get("/news-radar", aiDashboardLimiter, getNewsRadar);

// AUTH assistant chat
router.post("/assistant/chat", requireAuth, chatWithAssistant);

export default router;
