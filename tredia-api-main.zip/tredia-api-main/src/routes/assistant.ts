// src/routes/assistant.ts
import { Router } from "express";
import { requireJwtAuth } from "../middleware/jwtAuth";
import { chatWithAssistantForUser } from "../services/assistantService";

type AiMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

const router = Router();

async function handleAssistantChat(req: any, res: any) {
  try {
    const userId = req.user?.id;
    if (!userId) return res.status(401).json({ error: "Unauthorized" });

    const body = (req.body ?? {}) as { message?: string; messages?: AiMessage[] };

    const messages: AiMessage[] =
      Array.isArray(body.messages) && body.messages.length > 0
        ? body.messages
        : typeof body.message === "string" && body.message.trim()
          ? [{ role: "user", content: body.message.trim() }]
          : [];

    if (!messages.length) {
      return res.status(400).json({ error: "Missing message/messages" });
    }

    // assistantService returns an object (result), not just a string
    const result = await chatWithAssistantForUser(userId, messages as any);

    // Keep response stable for mobile
    return res.json({
      reply: result.reply,
      meta: result.meta,
    });
  } catch (e) {
    console.error("[assistant] error:", e);
    return res.status(500).json({ error: "Server error" });
  }
}

router.post("/chat", requireJwtAuth, handleAssistantChat);
router.post("/", requireJwtAuth, handleAssistantChat); // back-compat

export default router;
