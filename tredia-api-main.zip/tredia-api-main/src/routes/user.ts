import { Router } from "express";
import { requireJwtAuth } from "../middleware/jwtAuth";
import { getMe, getUserPlan } from "../controllers/userController";
import {
  getUserPreferences,
  updateUserPreferences,
} from "../controllers/userPreferencesController";

const router = Router();

router.get("/me", requireJwtAuth, getMe);
router.get("/plan", requireJwtAuth, getUserPlan);
router.get("/preferences", requireJwtAuth, getUserPreferences);
router.put("/preferences", requireJwtAuth, updateUserPreferences);

export default router;
