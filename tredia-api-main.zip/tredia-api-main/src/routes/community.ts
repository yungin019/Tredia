// src/routes/community.ts
import { Router } from "express";
import {
  listCommunityPostsHandler,
  getCommunityPostHandler,
  createCommunityPostHandler,
  likePostHandler,
  unlikePostHandler,
  addCommentHandler,
  listLiveActivityHandler,
} from "../controllers/communityController";

const router = Router();

// Community feed
router.get("/posts", listCommunityPostsHandler);
router.get("/posts/:id", getCommunityPostHandler);
router.post("/posts", createCommunityPostHandler);

// Likes
router.post("/posts/:id/like", likePostHandler);
router.post("/posts/:id/unlike", unlikePostHandler);

// Comments
router.post("/posts/:id/comments", addCommentHandler);

// Live activity (RealTrade-based)
router.get("/live", listLiveActivityHandler);

export default router;
