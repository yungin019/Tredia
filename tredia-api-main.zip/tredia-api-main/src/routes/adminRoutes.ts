import { Router } from "express";

const router = Router();

router.get("/metrics", (_req, res) => {
  res.json({
    users: 124,
    apiCallsToday: 8432,
    cacheHits: 91,
  });
});

export default router;
