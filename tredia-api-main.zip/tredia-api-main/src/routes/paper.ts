// src/routes/paper.ts
import { Router } from "express";
import {
  getPaperPortfolio,
  getPerformanceSummary,
  executePaperTrade,
} from "../controllers/paperController";

const router = Router();

router.get("/portfolio", getPaperPortfolio);
router.get("/performance", getPerformanceSummary);

// ✅ this is what mobile calls
router.post("/trade", executePaperTrade);

export default router;
