// src/routes/wallet.ts
import { Router, Request, Response } from "express";
import prisma from "../lib/prisma";

const router = Router();

async function ensureWallet(userId: number) {
  const existing = await prisma.wallet.findUnique({
    where: { userId },
  });

  if (existing) return existing;

  return prisma.wallet.create({
    data: {
      userId,
      balance: 0,
    },
  });
}

/**
 * GET /wallet/:userId
 */
router.get("/:userId", async (req: Request, res: Response) => {
  const userId = Number(req.params.userId);
  if (Number.isNaN(userId)) {
    return res.status(400).json({ error: "Invalid user id" });
  }

  try {
    const wallet = await ensureWallet(userId);

    return res.json({
      userId: wallet.userId,
      balanceUsd: wallet.balance,
      currency: "USD",
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error("[GET /wallet/:userId] Error:", error);
    return res.status(500).json({ error: "Failed to fetch wallet" });
  }
});

/**
 * POST /wallet/:userId/deposit
 */
router.post("/:userId/deposit", async (req: Request, res: Response) => {
  const userId = Number(req.params.userId);
  const { amount } = req.body as { amount?: number };

  if (Number.isNaN(userId)) {
    return res.status(400).json({ error: "Invalid user id" });
  }

  if (!amount || typeof amount !== "number" || amount <= 0) {
    return res.status(400).json({ error: "amount must be a positive number" });
  }

  try {
    await ensureWallet(userId);

    const wallet = await prisma.wallet.update({
      where: { userId },
      data: {
        balance: {
          increment: amount,
        },
      },
    });

    return res.json({
      userId: wallet.userId,
      balanceUsd: wallet.balance,
      currency: "USD",
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error("[POST /wallet/:userId/deposit] Error:", error);
    return res.status(500).json({ error: "Failed to deposit to wallet" });
  }
});

/**
 * POST /wallet/:userId/withdraw
 */
router.post("/:userId/withdraw", async (req: Request, res: Response) => {
  const userId = Number(req.params.userId);
  const { amount } = req.body as { amount?: number };

  if (Number.isNaN(userId)) {
    return res.status(400).json({ error: "Invalid user id" });
  }

  if (!amount || typeof amount !== "number" || amount <= 0) {
    return res.status(400).json({ error: "amount must be a positive number" });
  }

  try {
    const wallet = await ensureWallet(userId);

    if (wallet.balance < amount) {
      return res.status(400).json({ error: "Insufficient funds" });
    }

    const updated = await prisma.wallet.update({
      where: { userId },
      data: {
        balance: {
          decrement: amount,
        },
      },
    });

    return res.json({
      userId: updated.userId,
      balanceUsd: updated.balance,
      currency: "USD",
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error("[POST /wallet/:userId/withdraw] Error:", error);
    return res.status(500).json({ error: "Failed to withdraw from wallet" });
  }
});

export default router;
