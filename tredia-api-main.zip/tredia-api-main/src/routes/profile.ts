// src/routes/profile.ts
import { Router, Request, Response } from "express";
import prisma from "../lib/prisma";

const router = Router();

/**
 * GET /profile/:userId
 */
router.get("/:userId", async (req: Request, res: Response) => {
  const userId = Number(req.params.userId);

  if (Number.isNaN(userId)) {
    return res.status(400).json({ error: "Invalid user id" });
  }

  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        plan: true,
        wallet: true,
      },
    });

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    // Avoid hard dependency on fields not in schema (phone, displayName)
    const displayName = (user as any).displayName ?? null;
    const phone = (user as any).phone ?? null;

    return res.json({
      id: user.id,
      email: user.email,
      displayName,
      phone, // will be null unless you actually add it to schema
      plan: (user as any).plan
        ? {
            id: (user as any).plan.id,
            name: (user as any).plan.name,
            price: (user as any).plan.priceMonthly,
            currency: (user as any).plan.currency ?? "USD",
          }
        : null,
      balanceUsd: user.wallet?.balance ?? 0,
      currency: "USD",
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    });
  } catch (error) {
    console.error("[GET /profile/:userId] Error:", error);
    return res.status(500).json({ error: "Failed to fetch profile" });
  }
});

/**
 * PUT /profile/:userId
 * Only updates fields that are guaranteed to exist.
 * (We do NOT try to write `phone` unless you explicitly add it to the Prisma model.)
 */
router.put("/:userId", async (req: Request, res: Response) => {
  const userId = Number(req.params.userId);

  if (Number.isNaN(userId)) {
    return res.status(400).json({ error: "Invalid user id" });
  }

  const { displayName } = req.body as { displayName?: string };

  try {
    const data: Record<string, any> = {};
    if (displayName !== undefined) data.displayName = displayName;

    const user = await prisma.user.update({
      where: { id: userId },
      data,
      include: { plan: true, wallet: true },
    });

    const safeDisplayName = (user as any).displayName ?? null;
    const phone = (user as any).phone ?? null;

    return res.json({
      id: user.id,
      email: user.email,
      displayName: safeDisplayName,
      phone,
      plan: (user as any).plan
        ? {
            id: (user as any).plan.id,
            name: (user as any).plan.name,
            price: (user as any).plan.priceMonthly,
            currency: (user as any).plan.currency ?? "USD",
          }
        : null,
      balanceUsd: user.wallet?.balance ?? 0,
      currency: "USD",
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    });
  } catch (error) {
    console.error("[PUT /profile/:userId] Error:", error);
    return res.status(500).json({ error: "Failed to update profile" });
  }
});

export default router;
