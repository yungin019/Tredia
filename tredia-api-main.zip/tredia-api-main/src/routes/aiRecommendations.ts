// tredia-api/src/routes/aiRecommendations.ts

import express, { Request, Response } from "express";
import prisma from "../lib/prisma";

const router = express.Router();

type Direction = "long" | "short" | "watch";
type TimeHorizon = "intraday" | "swing" | "position";

interface AiRecommendation {
  symbol: string;
  name?: string | null;
  assetClass: "stock" | "crypto" | "forex" | "metal" | "etf" | "other";
  direction: Direction;
  confidence: number; // 0–1
  timeHorizon: TimeHorizon;
  entryZone?: string | null;
  stopLossHint?: string | null;
  targetHint?: string | null;
  aiComment: string;
}

// ------------------------
// PLAN LIMITS (PER CALL)
// ------------------------
const PLAN_RECO_LIMITS: Record<"FREE" | "PRO" | "ELITE", number> = {
  FREE: 1,
  PRO: 3,
  ELITE: 3, // per call — "unlimited" can be handled by front-end frequency
};

function normalizePlanName(name: string | null | undefined): "FREE" | "PRO" | "ELITE" {
  const n = (name || "FREE").toUpperCase();
  if (n === "PRO" || n === "ELITE") return n;
  return "FREE";
}

// Helpers
function biasToDirection(bias: string | null | undefined): Direction {
  const b = (bias || "").toLowerCase();
  if (b === "bullish") return "long";
  if (b === "bearish") return "short";
  return "watch";
}

function pickTimeHorizon(
  assetClass: string,
  volatility?: number | null
): TimeHorizon {
  if (assetClass === "crypto") return "intraday";
  if (volatility !== null && volatility !== undefined && volatility > 0.04)
    return "intraday";
  if (volatility !== null && volatility !== undefined && volatility > 0.02)
    return "swing";
  return "position";
}

function buildAiComment(
  symbol: string,
  name: string | null | undefined,
  direction: Direction,
  confidence: number
): string {
  const label = name || symbol;
  const pct = Math.round(confidence * 100);

  if (direction === "long") {
    return `Based on recent signals, ${label} currently shows a bullish tilt with about ${pct}% confidence. This is purely educational context, not a buy signal — always manage risk and do your own research.`;
  }
  if (direction === "short") {
    return `Recent signals on ${label} suggest downside pressure with roughly ${pct}% confidence. This is informational only, not a sell or short recommendation — market conditions can change quickly.`;
  }
  return `Signals on ${label} are mixed, so ${label} is best treated as a watchlist candidate for now. The confidence level is around ${pct}%, and this is market context only, not an action to take.`;
}

// Fallback assets in case AiSignal table is empty
const FALLBACK_ASSETS = [
  { symbol: "AAPL", name: "Apple Inc.", assetClass: "stock" as const },
  { symbol: "NVDA", name: "NVIDIA Corp.", assetClass: "stock" as const },
  { symbol: "BTCUSD", name: "Bitcoin", assetClass: "crypto" as const },
  { symbol: "ETHUSD", name: "Ethereum", assetClass: "crypto" as const },
  { symbol: "TSLA", name: "Tesla Inc.", assetClass: "stock" as const },
];

// ------------------------
// POST /api/ai/recommendations
// (mounted via app.use("/api/ai/recommendations", aiRecommendationsRoutes))
// ------------------------
router.post(
  "/",
  async (req: Request, res: Response): Promise<Response | void> => {
    try {
      const { userId } = req.body;

      if (!userId) {
        return res.status(400).json({ error: "userId is required" });
      }

      // 1) Find user + plan
      const user = await prisma.user.findUnique({
        where: { id: Number(userId) },
        include: { plan: true },
      });

      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const planName = normalizePlanName(user.plan?.name);
      const perCallLimit = PLAN_RECO_LIMITS[planName];

      // 2) Build recommendation universe from AiSignal or fallback
      const signals = await prisma.aiSignal.findMany({
        orderBy: { createdAt: "desc" },
        take: 20,
      });

      const baseUniverse =
        signals.length > 0
          ? signals
          : FALLBACK_ASSETS.map((a) => ({
              symbol: a.symbol,
              name: a.name,
              assetClass: a.assetClass,
              aiBias: "bullish",
              aiConfidence: 0.65,
              changePct: 0,
              volatility: 0.02,
            }));

      const picked: AiRecommendation[] = [];
      const seen = new Set<string>();

      for (const s of baseUniverse) {
        if (picked.length >= perCallLimit) break;
        if (!s.symbol || seen.has(s.symbol)) continue;

        seen.add(s.symbol);

        const assetClass =
          (s as any).assetClass ||
          ("stock" as "stock" | "crypto" | "forex" | "metal" | "etf" | "other");

        const direction = biasToDirection((s as any).aiBias);
        const rawConfidence =
          (s as any).aiConfidence !== undefined &&
          (s as any).aiConfidence !== null
            ? Number((s as any).aiConfidence)
            : 0.6;
        const confidence = Math.max(0.5, Math.min(0.95, rawConfidence));

        const horizon = pickTimeHorizon(assetClass, (s as any).volatility);

        picked.push({
          symbol: s.symbol,
          name: (s as any).name ?? null,
          assetClass,
          direction,
          confidence,
          timeHorizon: horizon,
          entryZone: null,
          stopLossHint: null,
          targetHint: null,
          aiComment: buildAiComment(
            s.symbol,
            (s as any).name,
            direction,
            confidence
          ),
        });
      }

      if (picked.length === 0) {
        return res
          .status(500)
          .json({ error: "Unable to generate recommendations" });
      }

      // 3) Return payload
      return res.json({
        recommendations: picked,
        meta: {
          plan: planName,
          count: picked.length,
          perCallLimit,
        },
      });
    } catch (err) {
      console.error("AI Recommendations error:", err);
      return res.status(500).json({
        error: "AI recommendations failed",
      });
    }
  }
);

export default router;
