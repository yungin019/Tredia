import { Router } from "express";
import { requireJwtAuth } from "../middleware/jwtAuth";
import { createTradeIntent, confirmTrade } from "../controllers/tradeController";

const router = Router();

router.post("/trade-intent", requireJwtAuth, createTradeIntent);
router.post("/trade-confirm", requireJwtAuth, confirmTrade);

export default router;
