// src/routes/aiDashboardRoutes.ts

import { Router, Request, Response } from "express";

const router = Router();

/**
 * GET /api/ai/dashboard
 *
 * Shape is aligned with AiDashboardPayload used in mobile:
 *  - generatedAt: string
 *  - heatmap: [...]
 *  - spotlight: [...]
 *  - summary: string | { title, text }
 *  - newsSentiment: [...]
 */
router.get("/dashboard", async (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();

    // Simple mock heatmap (can be replaced with real provider later)
    const heatmap = [
      {
        symbol: "AAPL",
        name: "Apple Inc.",
        assetClass: "stock",
        sector: "Technology",
        changePct: 1.24,
        volatility: 0.32,
        aiBias: "bullish",
        aiConfidence: 0.82,
        sentimentScore: 0.6,
        jumpProbability: 0.45,
        heat: 0.78,
      },
      {
        symbol: "TSLA",
        name: "Tesla Inc.",
        assetClass: "stock",
        sector: "Consumer Discretionary",
        changePct: -2.15,
        volatility: 0.65,
        aiBias: "bearish",
        aiConfidence: 0.76,
        sentimentScore: -0.4,
        jumpProbability: 0.55,
        heat: 0.83,
      },
      {
        symbol: "BTCUSD",
        name: "Bitcoin / USD",
        assetClass: "crypto",
        sector: null,
        changePct: 0.85,
        volatility: 0.7,
        aiBias: "bullish",
        aiConfidence: 0.79,
        sentimentScore: 0.3,
        jumpProbability: 0.5,
        heat: 0.74,
      },
      {
        symbol: "NVDA",
        name: "NVIDIA Corp.",
        assetClass: "stock",
        sector: "Technology",
        changePct: 1.95,
        volatility: 0.58,
        aiBias: "bullish",
        aiConfidence: 0.88,
        sentimentScore: 0.7,
        jumpProbability: 0.6,
        heat: 0.9,
      },
    ];

    const spotlight = [
      {
        symbol: "NVDA",
        name: "NVIDIA Corp.",
        assetClass: "stock",
        sector: "Technology",
        direction: "long",
        heat: 0.9,
        changePct: 1.95,
        aiBias: "bullish",
        aiConfidence: 0.88,
        jumpProbability: 0.6,
        timeHorizon: "1–3 days",
        thesis: {
          title: "AI chips still driving upside",
          text: "Momentum remains strong across AI/semis with supportive earnings and flows.",
        },
        riskNote: {
          title: "High expectations priced in",
          text: "Sharp pullbacks possible if guidance disappoints or macro risk spikes.",
        },
        suggestedEntry: 135.0,
        suggestedStop: 126.5,
        suggestedTarget: 145.0,
        aiComment:
          "If you are not over-exposed to semis already, a controlled NVDA position still makes sense with tight risk rules.",
      },
      {
        symbol: "TSLA",
        name: "Tesla Inc.",
        assetClass: "stock",
        sector: "Consumer Discretionary",
        direction: "short",
        heat: 0.83,
        changePct: -2.15,
        aiBias: "bearish",
        aiConfidence: 0.76,
        jumpProbability: 0.55,
        timeHorizon: "2–5 days",
        thesis:
          "Price remains under pressure after recent news flow; sellers still in control.",
        riskNote:
          "Shorting is risky and can squeeze violently; size must remain small.",
        suggestedEntry: 210.0,
        suggestedStop: 225.0,
        suggestedTarget: 190.0,
        aiComment: null,
      },
    ];

    const summary = {
      title: "Flows concentrate in AI, large-cap tech and BTC",
      text: "Risk appetite remains focused on AI-related equities and crypto, while some high beta names like TSLA show renewed downside pressure. Volatility is elevated but not yet extreme.",
    };

    const newsSentiment = [
      {
        id: "n1",
        title:
          "Big Tech leads market higher as investors double down on AI theme",
        summary:
          "AI-related megacaps extend their outperformance, driving index gains despite weakness in some cyclical sectors.",
        sentimentLabel: "bullish",
        sentimentScore: 0.6,
        impactScore: 75,
        impactedSymbols: ["NVDA", "AAPL", "MSFT", "QQQ"],
        horizon: "swing",
        confidence: 0.8,
        source: "Tredia AI",
        url: null,
        publishedAt: now,
        categories: ["equities", "AI"],
        aiComment:
          "As long as flows keep rotating into AI leaders, dips in quality names are likely to be bought aggressively.",
      },
      {
        id: "n2",
        title:
          "Auto & EV stocks under pressure after mixed delivery figures",
        summary:
          "TSLA and peers face renewed skepticism as delivery numbers and guidance fail to impress.",
        sentimentLabel: "bearish",
        sentimentScore: -0.5,
        impactScore: 68,
        impactedSymbols: ["TSLA", "NIO", "XPEV"],
        horizon: "intraday",
        confidence: 0.75,
        source: "Tredia AI",
        url: null,
        publishedAt: now,
        categories: ["equities", "autos"],
        aiComment:
          "If you are long TSLA or EV names, consider tightening stops or reducing size into weakness.",
      },
    ];

    return res.status(200).json({
      generatedAt: now,
      heatmap,
      spotlight,
      summary,
      newsSentiment,
    });
  } catch (err) {
    console.error("[AI DASHBOARD] error", err);
    return res.status(500).json({ error: "AI_DASHBOARD_FAILED" });
  }
});

export default router;
