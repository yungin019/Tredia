// src/routes/referral.ts

import { Router } from "express";
import { requireAuth } from "../middleware/requireAuth";
import {
  applyReferralCodeForUser,
  getOrCreateReferralCode,
  getReferralStatus,
} from "../services/referralService";

const router = Router();

/**
 * GET /api/referral/status
 * Returns referralCode, referralBonusCredits, introDiscountEligible
 */
router.get("/status", requireAuth, async (req, res) => {
  try {
    const anyReq = req as any;
    const userId = anyReq.user.id as number;

    const status = await getReferralStatus(userId);
    return res.json(status);
  } catch (err: any) {
    console.error("Referral status error:", err?.message || err);
    return res.status(500).json({ error: "Failed to load referral status" });
  }
});

/**
 * POST /api/referral/generate
 * Ensures the user has a referral code and returns it.
 * Only founders really “need” this, but we let backend decide that later.
 */
router.post("/generate", requireAuth, async (req, res) => {
  try {
    const anyReq = req as any;
    const userId = anyReq.user.id as number;

    const code = await getOrCreateReferralCode(userId);
    return res.json({ referralCode: code });
  } catch (err: any) {
    console.error("Referral generate error:", err?.message || err);
    return res.status(500).json({ error: "Failed to generate referral code" });
  }
});

/**
 * POST /api/referral/apply
 * Body: { code: string }
 * Friend uses a referral code → gives friend intro discount + bonus to referrer.
 */
router.post("/apply", requireAuth, async (req, res) => {
  try {
    const anyReq = req as any;
    const userId = anyReq.user.id as number;
    const { code } = req.body;

    if (!code || typeof code !== "string") {
      return res.status(400).json({ error: "Referral code is required" });
    }

    const result = await applyReferralCodeForUser(userId, code);

    return res.json({
      success: true,
      ...result,
    });
  } catch (err: any) {
    console.error("Referral apply error:", err?.message || err);
    return res.status(400).json({ error: err?.message || "Failed to apply referral code" });
  }
});

export default router;
