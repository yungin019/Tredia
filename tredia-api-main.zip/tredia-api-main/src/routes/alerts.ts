// src/routes/alerts.ts

import { Router } from "express";
import { requireAuth } from "../middleware/requireAuth";
import { getRecentAlerts } from "../services/alertsService";

const router = Router();

/**
 * GET /api/alerts
 * Returns a list of recent global market alerts.
 */
router.get("/", requireAuth, async (req, res) => {
  try {
    const alerts = await getRecentAlerts(50);
    return res.json({ alerts });
  } catch (err) {
    console.error("Get alerts error:", err);
    return res.status(500).json({ error: "Failed to load alerts" });
  }
});

export default router;
