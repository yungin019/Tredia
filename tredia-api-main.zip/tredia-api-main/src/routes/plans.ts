// tredia-api/src/routes/plans.ts

import { Router } from "express";
import {
  listPlans,
  getCurrentUserPlan,
  updateCurrentUserPlan,
} from "../controllers/planController";

const router = Router();

/**
 * GET /
 * Public – lists all plans and pricing (mounted under /api/plans)
 */
router.get("/", listPlans);

/**
 * GET /api/user/plan
 * Returns the current user plan + limits
 */
router.get("/user/plan", getCurrentUserPlan);

/**
 * POST /api/user/plan
 * Dev-side update of user plan; RevenueCat remains source of truth.
 */
router.post("/user/plan", updateCurrentUserPlan);

export default router;
