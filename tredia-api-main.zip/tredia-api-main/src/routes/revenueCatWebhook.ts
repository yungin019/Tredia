// src/routes/revenueCatWebhook.ts
import { Router } from "express";
import prisma from "../prisma";
import crypto from "crypto";

const router = Router();

// Optional shared secret you set in RevenueCat dashboard
const REVENUECAT_WEBHOOK_SECRET = process.env.REVENUECAT_WEBHOOK_SECRET || "";

const isProd = process.env.NODE_ENV === "production";

function safeHexFromHeader(headerVal: unknown): string | null {
  if (!headerVal) return null;
  const s = String(headerVal);
  // strip possible prefixes like "sha256=" or "v1=" and non-hex chars
  return s.replace(/^sha256=|^v1=/i, "").replace(/[^a-f0-9]/gi, "");
}

router.post("/", async (req, res) => {
  try {
    const signatureHeader = req.headers["x-revenuecat-signature"];
    const rawBody = (req as any).rawBody as string | undefined;

    // Fail-closed in production if secret missing
    if (isProd && !REVENUECAT_WEBHOOK_SECRET) {
      console.error("[RevenueCat] Missing REVENUECAT_WEBHOOK_SECRET in production");
      return res.status(500).json({ error: "WebhookNotConfigured" });
    }

    // In production ALWAYS verify the signature against the RAW request body
    if (isProd) {
      const sigHex = safeHexFromHeader(signatureHeader);
      if (!sigHex) {
        console.warn("[RevenueCat] Missing signature header");
        return res.status(401).json({ error: "MissingSignature" });
      }

      const hmac = crypto
        .createHmac("sha256", REVENUECAT_WEBHOOK_SECRET)
        .update(rawBody ?? JSON.stringify(req.body))
        .digest("hex");

      const sigBuf = Buffer.from(sigHex, "hex");
      const hmacBuf = Buffer.from(hmac, "hex");

      if (sigBuf.length !== hmacBuf.length || !crypto.timingSafeEqual(sigBuf, hmacBuf)) {
        console.warn("[RevenueCat] Invalid signature");
        return res.status(401).json({ error: "InvalidSignature" });
      }
    }

    const body = req.body as any;

    // RevenueCat sends events with app_user_id and entitlements
    const appUserIdRaw = body.app_user_id as string | undefined;
    const entitlements = body.entitlements || {};

    if (!appUserIdRaw) {
      console.warn("[RevenueCat] Missing app_user_id");
      return res.status(400).json({ error: "MissingUserId" });
    }

    // Ensure userId is a safe integer
    const userId = Number(appUserIdRaw);
    if (!Number.isInteger(userId) || userId <= 0) {
      console.warn("[RevenueCat] Invalid app_user_id", appUserIdRaw);
      // Don't crash; acknowledge the webhook
      return res.status(200).json({ ok: true });
    }

    // Decide plan based on entitlements
    const planName = entitlements.elite?.is_active
      ? "Elite"
      : entitlements.pro?.is_active
      ? "Pro"
      : "Free";

    // Ensure plan exists (upsert by name)
    const plan = await prisma.plan.upsert({
      where: { name: planName },
      update: {},
      create: { name: planName },
    });

    const existingUser = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!existingUser) {
      console.warn("[RevenueCat] User not found for id", userId);
      return res.status(200).json({ ok: true });
    }

    await prisma.user.update({
      where: { id: userId },
      data: { planId: plan ? plan.id : null },
    });

    return res.json({ ok: true });
  } catch (err) {
    console.error("[RevenueCat webhook] error:", err);
    return res.status(500).json({ error: "ServerError" });
  }
});

export default router;
