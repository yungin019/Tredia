// src/routes/portfolio.ts
import { Router } from "express";
import { requireJwtAuth } from "../middleware/jwtAuth";
import { getPortfolioOverview } from "../controllers/portfolioController";

const router = Router();

router.get("/", requireJwtAuth, getPortfolioOverview);

export default router;
