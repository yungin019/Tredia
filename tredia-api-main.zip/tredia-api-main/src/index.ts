// src/index.ts
import "dotenv/config";
import http from "http";
import express from "express";
import cors from "cors";
import morgan from "morgan";

import authRoutes from "./routes/auth";
import assistantRoutes from "./routes/assistant";
import superAiRoutes from "./routes/superAi";

import aiRoutes from "./routes/aiRoutes";
import adminRoutes from "./routes/adminRoutes";

import marketsRoutes from "./routes/markets";
import marketInfoRoutes from "./routes/marketInfo";
import ohlcRoutes from "./routes/ohlc";
import communityRoutes from "./routes/community";
import paperRoutes from "./routes/paper";
import portfolioRoutes from "./routes/portfolio";
import tradesRoutes from "./routes/trades";

import plansRoutes from "./routes/plans";
import profileRoutes from "./routes/profile";
import userRoutes from "./routes/user";

import walletRoutes from "./routes/wallet";
import subscriptionRoutes from "./routes/subscription";
import revenuecatRoutes from "./routes/revenueCatWebhook";

import alertsRoutes from "./routes/alerts";
import brokersRoutes from "./routes/brokers";
import realTradesRoutes from "./routes/realTrades";
import referralRoutes from "./routes/referral";

import { initSocket } from "./ws/socket";

const app = express();

// Middleware
app.use(cors());

// Capture raw body for RevenueCat signature verification if needed
app.use(
  express.json({
    limit: "2mb",
    verify: (req, _res, buf) => {
      try {
        (req as any).rawBody = buf.toString("utf8");
      } catch {
        (req as any).rawBody = undefined;
      }
    }
  })
);

app.use(morgan("dev"));

// Health
app.get("/health", (_req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// Auth
app.use("/api/auth", authRoutes);

// Assistant
app.use("/api/assistant", assistantRoutes);

// AI dashboard
app.use("/api/ai", aiRoutes);

// Admin
app.use("/admin", adminRoutes);

// Super AI
app.use("/api/super-ai", superAiRoutes);

// Markets / OHLC
app.use("/api/markets", marketsRoutes);
app.use("/api/markets", marketInfoRoutes);
app.use("/api/ohlc", ohlcRoutes);

// Community
app.use("/api/community", communityRoutes);

// Paper trading
app.use("/api/paper", paperRoutes);

// Trade endpoints (intent/confirm)
app.use("/api", tradesRoutes);

// Portfolio
app.use("/api/portfolio", portfolioRoutes);

// Plans / profile / user
app.use("/api/plans", plansRoutes);
app.use("/api/profile", profileRoutes);
app.use("/api/user", userRoutes);

// Wallet / subscription / revenuecat
app.use("/api/wallet", walletRoutes);
app.use("/api/subscription", subscriptionRoutes);
app.use("/api/revenuecat", revenuecatRoutes);

// Other
app.use("/api/alerts", alertsRoutes);
app.use("/api/brokers", brokersRoutes);
app.use("/api/real-trades", realTradesRoutes);
app.use("/api/referral", referralRoutes);

// 404 LAST
app.use((_req, res) => {
  res.status(404).json({ error: "Not found" });
});

const PORT = Number(process.env.PORT || 4000);

// IMPORTANT: Use http server so socket.io can attach
const server = http.createServer(app);

server.listen(PORT, () => {
  console.log(`🚀 Tredia API running on http://localhost:${PORT}`);
});

initSocket(server);
