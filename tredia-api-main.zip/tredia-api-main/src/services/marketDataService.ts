// src/services/marketDataService.ts
import axios from "axios";

const POLYGON_API_KEY = process.env.POLYGON_API_KEY;
const POLYGON_BASE_URL = "https://api.polygon.io";

export type LiveMarketAsset = {
  symbol: string;
  name?: string | null;
  assetClass?: string | null;
  price?: number | null;
  changePct?: number | null;
};

/**
 * Map raw Polygon crypto tickers like "X:BTCUSD" to a display symbol.
 */
function normalizeSymbol(ticker: string): string {
  if (ticker.startsWith("X:")) {
    return ticker.replace("X:", "");
  }
  return ticker;
}

/**
 * Small helper: fetch previous-day OHLC from Polygon for one ticker
 * and compute a % change using open → close.
 */
async function fetchPolygonPrevBar(
  ticker: string,
  assetClass: "stock" | "crypto"
): Promise<LiveMarketAsset | null> {
  if (!POLYGON_API_KEY) {
    return null;
  }

  try {
    const url = `${POLYGON_BASE_URL}/v2/aggs/ticker/${encodeURIComponent(
      ticker
    )}/prev`;

    const res = await axios.get(url, {
      params: {
        adjusted: true,
        apiKey: POLYGON_API_KEY,
      },
      timeout: 7000,
    });

    const results = (res.data as any)?.results;
    if (!Array.isArray(results) || results.length === 0) {
      return null;
    }

    const bar = results[0] as any;
    const close =
      typeof bar.c === "number" ? (bar.c as number) : null;
    const open =
      typeof bar.o === "number" ? (bar.o as number) : null;

    let changePct: number | null = null;
    if (close !== null && open !== null && open !== 0) {
      changePct = ((close - open) / open) * 100;
    }

    return {
      symbol: normalizeSymbol(ticker),
      name: normalizeSymbol(ticker),
      assetClass,
      price: close,
      changePct,
    };
  } catch (err) {
    console.error(
      "[marketDataService] Polygon prev error for",
      ticker,
      err
    );
    return null;
  }
}

/**
 * Fetch a small, curated snapshot of key tickers.
 * This is what powers movers / trending / AI dashboard.
 */
export async function fetchLiveSnapshot(): Promise<LiveMarketAsset[]> {
  // You can tweak this list anytime
  const tickers: { ticker: string; assetClass: "stock" | "crypto" }[] =
    [
      { ticker: "SPY", assetClass: "stock" },
      { ticker: "QQQ", assetClass: "stock" },
      { ticker: "AAPL", assetClass: "stock" },
      { ticker: "TSLA", assetClass: "stock" },
      { ticker: "MSFT", assetClass: "stock" },
      { ticker: "X:BTCUSD", assetClass: "crypto" },
      { ticker: "X:ETHUSD", assetClass: "crypto" },
    ];

  if (!POLYGON_API_KEY) {
    console.warn(
      "[marketDataService] POLYGON_API_KEY not set – returning empty live snapshot."
    );
    return [];
  }

  const results = await Promise.all(
    tickers.map((t) =>
      fetchPolygonPrevBar(t.ticker, t.assetClass)
    )
  );

  return results.filter(
    (x): x is LiveMarketAsset => x !== null
  );
}
