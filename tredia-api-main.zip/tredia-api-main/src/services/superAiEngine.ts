import { aiGenerate, UserTier } from "./aiService";

export type SuperAiTier = "free" | "pro" | "elite";

export interface SuperAiInput {
  symbol: string;
  tier: SuperAiTier;

  /**
   * The actual user question / message from the AI chat screen.
   */
  question?: string;

  /**
   * Backward-compat alias used by older code paths.
   * Prefer `question`.
   */
  prompt?: string;

  /**
   * Pre-fetched news headlines or snippets (optional).
   */
  rawNews?: string[];
}

export interface SuperAiOutput {
  symbol: string;
  tier: SuperAiTier;

  // Super AI response (structured)
  summary: string;
  probability: number; // 0..100
  confidence: number; // 0..1

  // Optional structured additions
  catalysts?: string[];
  risks?: string[];
  scenarios?: Array<{
    name: "base" | "bull" | "bear";
    probability: number; // 0..100
    description: string;
  }>;

  // For debugging/telemetry
  meta?: {
    model?: string;
    tokens?: number | null;
  };
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function tierToUserTier(tier: SuperAiTier): UserTier {
  if (tier === "elite") return "elite";
  if (tier === "pro") return "pro";
  return "free";
}

export async function runSuperAiEngine(input: SuperAiInput): Promise<SuperAiOutput> {
  const symbol = String(input.symbol || "").trim().toUpperCase();
  const tier = input.tier ?? "free";

  const qRaw =
    (typeof input.question === "string" ? input.question : "") ||
    (typeof input.prompt === "string" ? input.prompt : "");

  const question =
    qRaw.trim().length > 0
      ? qRaw.trim()
      : `Give me a Super AI analysis for ${symbol}: key drivers, risks, scenarios, and what to watch next.`;

  const rawNews = Array.isArray(input.rawNews) ? input.rawNews.slice(0, 10) : [];

  const tierDepth =
    tier === "elite"
      ? "ELITE (deep, scenario-based, probability + confirmations)"
      : tier === "pro"
      ? "PRO (practical, structured, mid-depth)"
      : "FREE (shorter, still structured)";

  const prompt = `
You are TREDIA SUPER AI — an elite market intelligence engine.

TIER DEPTH: ${tierDepth}

TASK:
Analyze the asset: ${symbol}

User question:
${question}

Optional news context (may be empty):
${rawNews.length ? rawNews.map((n, i) => `- (${i + 1}) ${n}`).join("\n") : "(none)"}

RULES:
- Be confident and mentor-like, not generic.
- No long legal disclaimer. No “consult a financial advisor”.
- Do NOT say “Buy/Sell now”. Use conditional guidance.
- Provide probabilities with uncertainty (no certainty / no guarantees).
- Output MUST be valid JSON only.

OUTPUT JSON SHAPE:
{
  "summary": "string",
  "probability": 0-100,
  "confidence": 0-1,
  "catalysts": ["..."],
  "risks": ["..."],
  "scenarios": [
    {"name":"base","probability":0-100,"description":"..."},
    {"name":"bull","probability":0-100,"description":"..."},
    {"name":"bear","probability":0-100,"description":"..."}
  ]
}
`;

  const response = await aiGenerate(prompt, tierToUserTier(tier));

  // Parse JSON safely
  try {
    const parsed = JSON.parse(response);

    const probability = clamp(Number(parsed.probability ?? 50), 0, 100);
    const confidence = clamp(Number(parsed.confidence ?? 0.6), 0, 1);

    return {
      symbol,
      tier,
      summary: String(parsed.summary ?? "").trim() || "No summary generated.",
      probability,
      confidence,
      catalysts: Array.isArray(parsed.catalysts) ? parsed.catalysts.map(String).slice(0, 10) : [],
      risks: Array.isArray(parsed.risks) ? parsed.risks.map(String).slice(0, 10) : [],
      scenarios: Array.isArray(parsed.scenarios)
        ? parsed.scenarios
            .map((s: any) => ({
              name: s?.name,
              probability: clamp(Number(s?.probability ?? 0), 0, 100),
              description: String(s?.description ?? ""),
            }))
            .filter((s: any) => s.name === "base" || s.name === "bull" || s.name === "bear")
            .slice(0, 3)
        : [],
      meta: {},
    };
  } catch {
    // Fallback if the model responds with non-JSON
    return {
      symbol,
      tier,
      summary: response?.trim() || "Super AI failed to respond in JSON format.",
      probability: 50,
      confidence: 0.5,
      catalysts: [],
      risks: [],
      scenarios: [],
      meta: {},
    };
  }
}
