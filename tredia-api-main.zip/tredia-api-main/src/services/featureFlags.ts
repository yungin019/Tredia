import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function getFeatureFlag(key: string) {
  const flag = await prisma.featureFlag.findUnique({ where: { key } });
  return flag?.enabled || false;
}

export async function setFeatureFlag(key: string, enabled: boolean) {
  await prisma.featureFlag.upsert({
    where: { key },
    update: { enabled },
    create: { key, enabled },
  });
}

export async function listFeatureFlags() {
  return prisma.featureFlag.findMany();
}
