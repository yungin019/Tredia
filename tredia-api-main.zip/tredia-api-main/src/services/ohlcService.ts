// src/services/ohlcService.ts
import axios from "axios";

const ALPHAVANTAGE_API_KEY = process.env.ALPHAVANTAGE_API_KEY;

if (!ALPHAVANTAGE_API_KEY) {
  console.error("❌ Missing ALPHAVANTAGE_API_KEY in environment variables.");
}

/**
 * Fetch live OHLC candles from AlphaVantage
 * @param symbol stock/crypto/etc
 * @param interval default "15" (15-minute candles)
 */
export async function fetchOHLC(
  symbol: string,
  interval: string = "15"
) {
  try {
    const url = `https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=${symbol}&interval=${interval}min&apikey=${ALPHAVANTAGE_API_KEY}`;

    const response = await axios.get(url);

    if (!response.data || !response.data[`Time Series (${interval}min)`]) {
      return {
        error: "No OHLC data returned for this symbol.",
        candles: [],
      };
    }

    const raw = response.data[`Time Series (${interval}min)`];

    const candles = Object.entries(raw).map(([timestamp, values]: any) => ({
      time: timestamp,
      open: parseFloat(values["1. open"]),
      high: parseFloat(values["2. high"]),
      low: parseFloat(values["3. low"]),
      close: parseFloat(values["4. close"]),
      volume: parseFloat(values["5. volume"]),
    }));

    // sort newest → oldest
    candles.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());

    return { interval, candles };
  } catch (err) {
    console.error("OHLC Fetch Error:", err);
    return {
      error: "Failed to fetch OHLC data.",
      candles: [],
    };
  }
}
