import prisma from "../lib/prisma";

type TradeParams = {
  userId: number;
  symbol: string;
  side: "BUY" | "SELL";
  price: number;
  quantity: number;
  assetType: string;
};

// --------------------------
// Portfolio
// --------------------------
export async function getPaperPortfolio(userId: number) {
  let portfolio = await prisma.paperPortfolio.findUnique({
    where: { userId },
  });

  // create starter portfolio if not
  if (!portfolio) {
    portfolio = await prisma.paperPortfolio.create({
      data: {
        userId,
        startingCash: 10000,
        cash: 10000,
      },
    });
  }

  const trades = await prisma.paperTrade.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
  });

  return {
    cash: portfolio.cash,
    startingCash: portfolio.startingCash,
    trades,
  };
}

// --------------------------
// Execute trade
// --------------------------
export async function executePaperTrade(params: TradeParams) {
  const { userId, symbol, side, price, quantity, assetType } = params;
  const cost = price * quantity;

  // load portfolio
  let portfolio = await prisma.paperPortfolio.findUnique({
    where: { userId },
  });

  if (!portfolio) {
    portfolio = await prisma.paperPortfolio.create({
      data: {
        userId,
        startingCash: 10000,
        cash: 10000,
      },
    });
  }

  // BUY
  if (side === "BUY") {
    if (portfolio.cash < cost) {
      throw new Error("Not enough cash");
    }

    await prisma.paperPortfolio.update({
      where: { userId },
      data: {
        cash: portfolio.cash - cost,
      },
    });
  }

  // SELL: add cash
  if (side === "SELL") {
    await prisma.paperPortfolio.update({
      where: { userId },
      data: {
        cash: portfolio.cash + cost,
      },
    });
  }

  // record trade
  const trade = await prisma.paperTrade.create({
    data: {
      userId,
      paperPortfolioId: portfolio.id,
      symbol,
      side,
      size: quantity * price,
      quantity,
      entryPrice: price,
      assetType,
      status: "CLOSED",
    },
  });

  return trade;
}

// --------------------------
// Performance
// --------------------------
export async function getPaperPerformance(userId: number) {
  const portfolio = await prisma.paperPortfolio.findUnique({
    where: { userId },
  });
  if (!portfolio) return { pnl: 0 };

  const pnl = portfolio.cash - portfolio.startingCash;
  return { pnl };
}
