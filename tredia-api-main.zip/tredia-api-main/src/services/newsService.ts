// src/services/newsService.ts

import { finnhubClient } from "../config/finnhub";
import { createHash } from "crypto";

type SentimentLabel = "bullish" | "bearish" | "neutral";

export interface NewsRadarItem {
  id: string;
  title: string;
  summary: string | null;
  source?: string | null;
  url?: string | null;
  publishedAt?: string | null;
  impactedSymbols: string[];
  sentimentLabel: SentimentLabel;
  sentimentScore: number; // -1..1
  impactScore: number; // 0..100
  horizon: "intraday" | "swing" | "position";
  confidence: number; // 0..1
  categories?: string[];
  aiComment?: string | null;
}

// Finnhub /news items look like: { headline, summary, source, url, datetime, category, ... }
function makeId(input: string) {
  return createHash("sha256").update(input).digest("hex");
}

/**
 * Minimal, safe News Radar source:
 * - Uses Finnhub general news
 * - Always returns [] on errors (never breaks build)
 */
export async function getNewsRadar(): Promise<NewsRadarItem[]> {
  try {
    const resp = await finnhubClient.get("/news", {
      params: { category: "general" },
    });

    const raw: any[] = Array.isArray(resp.data) ? resp.data : [];
    const top = raw.slice(0, 12);

    return top.map((n: any) => {
      const title = String(n?.headline || "Untitled");
      const summary = typeof n?.summary === "string" ? n.summary : null;
      const source = typeof n?.source === "string" ? n.source : null;
      const url = typeof n?.url === "string" ? n.url : null;

      const dt =
        typeof n?.datetime === "number" && Number.isFinite(n.datetime)
          ? new Date(n.datetime * 1000).toISOString()
          : null;

      const category =
        typeof n?.category === "string" && n.category.trim().length > 0
          ? n.category.trim()
          : null;

      const id = makeId(`${title}|${url || ""}|${dt || ""}`);

      return {
        id,
        title,
        summary,
        source,
        url,
        publishedAt: dt,
        impactedSymbols: [],
        sentimentLabel: "neutral",
        sentimentScore: 0,
        impactScore: 50,
        horizon: "swing",
        confidence: 0.6,
        categories: category ? [category] : [],
        aiComment: null,
      } satisfies NewsRadarItem;
    });
  } catch (err) {
    // important: do not crash dashboard if news provider fails / rate limits
    return [];
  }
}
