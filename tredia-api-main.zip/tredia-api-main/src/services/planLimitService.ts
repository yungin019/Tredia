// src/services/planLimitService.ts

import prisma from "../prisma";

export type PlanName = "FREE" | "PRO" | "ELITE" | "FOUNDER";

const DAILY_LIMITS: Record<PlanName, number> = {
  FREE: 10,
  PRO: 50,
  ELITE: 200,
  FOUNDER: 9999,
};

export const checkAndIncrementAiUsage = async (
  userId: number,
  plan: PlanName
): Promise<{
  limited: boolean;
  used: number;
  limit: number;
}> => {
  const limit = DAILY_LIMITS[plan] ?? DAILY_LIMITS.FREE;

  // Normalize to date only
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Find today's usage row
  let usage = await prisma.aiUsage.findUnique({
    where: {
      userId_date: {
        userId,
        date: today,
      },
    },
  });

  // Create if missing
  if (!usage) {
    usage = await prisma.aiUsage.create({
      data: {
        userId,
        date: today,
        count: 0,
      },
    });
  }

  // Limit reached?
  if (usage.count >= limit) {
    return {
      limited: true,
      used: usage.count,
      limit,
    };
  }

  // Increment count safely
  usage = await prisma.aiUsage.update({
    where: {
      userId_date: {
        userId,
        date: today,
      },
    },
    data: {
      count: { increment: 1 },
    },
  });

  return {
    limited: false,
    used: usage.count,
    limit,
  };
};
