// src/services/founderService.ts

import prisma from "../prisma";

/**
 * Mark a user as founder if:
 * - they are not already a founder
 * - there are less than 100 founders currently
 */
export async function markUserAsFounderIfEligible(userId: number) {
  const user: any = await prisma.user.findUnique({
    where: { id: userId },
  });

  if (!user) return;
  if (user.isFounder) return;

  const founderCount = await prisma.user.count({
    where: { isFounder: true },
  });

  if (founderCount >= 100) {
    return;
  }

  await prisma.user.update({
    where: { id: userId },
    data: {
      // these fields exist in schema.prisma
      isFounder: true,
      founderPriceMonthly: 150,
      founderSince: new Date(),
    } as any,
  });
}
