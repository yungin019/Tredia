// src/services/imageUploadService.ts
import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";

/**
 * Base64 image upload.
 *
 * DEV: saves locally under /uploads/community
 * LATER: you can swap this to S3 / R2 without touching routes/controllers.
 *
 * @param base64 e.g. "data:image/png;base64,AAAA..."
 * @returns public relative URL e.g. "/uploads/community/xyz.png"
 */
export async function uploadBase64Image(
  base64: string,
  folder: string = "community"
): Promise<string> {
  if (!base64 || typeof base64 !== "string") {
    throw new Error("No base64 image provided");
  }

  // Handle "data:image/png;base64,..." prefix if present
  const matches = base64.match(/^data:(image\/\w+);base64,(.+)$/);
  let mimeType = "image/png";
  let dataPart = base64;

  if (matches && matches.length === 3) {
    mimeType = matches[1];
    dataPart = matches[2];
  }

  const ext = mimeType.split("/")[1] || "png";
  const buffer = Buffer.from(dataPart, "base64");

  // Local folder: /uploads/<folder>
  const uploadsRoot = path.join(process.cwd(), "uploads");
  const targetDir = path.join(uploadsRoot, folder);

  await fs.promises.mkdir(targetDir, { recursive: true });

  const filename = `${randomUUID()}.${ext}`;
  const filePath = path.join(targetDir, filename);

  await fs.promises.writeFile(filePath, buffer);

  // Relative URL served by Express (see app.ts config)
  const publicUrl = `/uploads/${folder}/${filename}`;
  return publicUrl;
}
