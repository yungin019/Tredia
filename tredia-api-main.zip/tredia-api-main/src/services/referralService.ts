// src/services/referralService.ts

import prisma from "../prisma";

function generateRandomCode(userId: number): string {
  const rand = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `TREDIA${userId}${rand}`;
}

/**
 * Ensure the user has a referral code. If not, generate one.
 */
export async function getOrCreateReferralCode(userId: number): Promise<string> {
  const user: any = await prisma.user.findUnique({
    where: { id: userId },
  });

  if (!user) {
    throw new Error("User not found");
  }

  if (user.referralCode) {
    return user.referralCode;
  }

  const code = generateRandomCode(userId);

  const updated: any = await prisma.user.update({
    where: { id: userId },
    data: {
      referralCode: code,
    } as any,
  });

  return updated.referralCode;
}

/**
 * Get referral status for a user:
 * - referral code
 * - how many “50% off” credits they have
 * - whether they are eligible for intro discount as referred friend
 */
export async function getReferralStatus(userId: number) {
  const user: any = await prisma.user.findUnique({
    where: { id: userId },
  });

  if (!user) {
    throw new Error("User not found");
  }

  return {
    referralCode: user.referralCode ?? null,
    referralBonusCredits: user.referralBonusCredits ?? 0,
    introDiscountEligible: !!user.introDiscountEligible,
  };
}

/**
 * Apply a referral code for the current user (friend side).
 * - Friend gets introDiscountEligible = true (50% off first month)
 * - Referrer gets +1 referralBonusCredits (50% off one month)
 */
export async function applyReferralCodeForUser(
  currentUserId: number,
  code: string
) {
  const trimmed = code.trim();

  const referrer: any = await prisma.user.findFirst({
    where: { referralCode: trimmed } as any,
  });

  if (!referrer) {
    throw new Error("Invalid referral code");
  }

  if (referrer.id === currentUserId) {
    throw new Error("You cannot use your own referral code");
  }

  const referred: any = await prisma.user.findUnique({
    where: { id: currentUserId },
  });

  if (!referred) {
    throw new Error("User not found");
  }

  // create event for analytics
  await (prisma as any).referralEvent.create({
    data: {
      referrerId: referrer.id,
      referredUserId: referred.id,
    },
  });

  // referrer gets one bonus 50% month
  await prisma.user.update({
    where: { id: referrer.id },
    data: {
      referralBonusCredits: (referrer.referralBonusCredits ?? 0) + 1,
    } as any,
  });

  // friend gets intro discount flag
  const updatedFriend: any = await prisma.user.update({
    where: { id: referred.id },
    data: {
      introDiscountEligible: true,
    } as any,
  });

  return {
    referrerId: referrer.id,
    referrerEmail: referrer.email,
    friendId: updatedFriend.id,
    introDiscountEligible: updatedFriend.introDiscountEligible,
  };
}
