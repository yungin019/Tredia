// src/services/aiLimiterService.ts

import prisma from "../lib/prisma";
import { PlanName, getDailyAiLimit } from "../config/planLimits";

export interface AiUsageSnapshot {
  dailyLimit: number | null;   // null = unlimited
  used: number;                // messages used today
  remaining: number | null;    // null = unlimited
  usageId: number;             // AiUsage.id
}

/**
 * Get or create today's AiUsage row for a user, and compute usage snapshot.
 * One row per user per date (midnight).
 */
export async function getTodayUsage(
  userId: number,
  planName: PlanName
): Promise<AiUsageSnapshot> {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Find existing usage row for today
  let usage = await prisma.aiUsage.findFirst({
    where: {
      userId,
      date: today,
    },
  });

  // Create if missing
  if (!usage) {
    usage = await prisma.aiUsage.create({
      data: {
        userId,
        date: today,
        count: 0,
      },
    });
  }

  const used = usage.count ?? 0;
  const dailyLimit = getDailyAiLimit(planName); // number | null
  let remaining: number | null = null;

  if (dailyLimit === null) {
    // Unlimited plan
    remaining = null;
  } else {
    remaining = Math.max(dailyLimit - used, 0);
  }

  return {
    dailyLimit,
    used,
    remaining,
    usageId: usage.id,
  };
}
