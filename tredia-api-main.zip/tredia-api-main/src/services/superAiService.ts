// src/services/superAiService.ts
import prisma from "../lib/prisma";
import { OpenAI } from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

function isElitePlanName(planName: string | null | undefined) {
  return String(planName || "").toUpperCase() === "ELITE";
}

export async function getSuperAiResponse(userId: number, prompt: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: { plan: true },
  });

  if (!user) {
    throw new Error("User not found");
  }

  if (!isElitePlanName(user.plan?.name || null)) {
    // Keep as a thrown error so route can return 403
    const err = new Error("ELITE_ONLY");
    (err as any).code = "ELITE_ONLY";
    throw err;
  }

  const completion = await openai.chat.completions.create({
    model: process.env.SUPER_AI_MODEL || "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content:
          "You are Super AI for Tredia. Be concise, actionable, and risk-aware. No fluff.",
      },
      { role: "user", content: prompt },
    ],
    temperature: 0.4,
  });

  const text = completion.choices?.[0]?.message?.content ?? "";
  return text.trim();
}

/**
 * Compatibility export expected by routes in some branches.
 */
export async function chatWithSuperAiForUser(userId: number, message: string) {
  return getSuperAiResponse(userId, message);
}
