// src/services/aiNewsService.ts

import axios from "axios";

const FINNHUB_API_KEY = process.env.FINNHUB_API_KEY || "";

/**
 * Raw Finnhub news item type extended for sentiment engine.
 */
export interface FinnhubNewsItem {
  id?: number;
  category?: string;
  headline?: string;
  summary?: string;
  source?: string;
  url?: string;
  image?: string;
  datetime?: number; // Unix timestamp
  related?: string;  // comma-separated tickers
}

/**
 * Fetch latest market news from Finnhub.
 * This provides the official "raw" news list for News Radar.
 */
export async function fetchLatestMarketNews(limit: number = 30): Promise<FinnhubNewsItem[]> {
  if (!FINNHUB_API_KEY) {
    console.warn(
      "[aiNewsService] FINNHUB_API_KEY is missing – real news disabled. Add it to your .env."
    );
    return [];
  }

  try {
    const response = await axios.get("https://finnhub.io/api/v1/news", {
      params: {
        category: "general",
        token: FINNHUB_API_KEY,
      },
      timeout: 12000,
    });

    const list = Array.isArray(response.data) ? response.data : [];
    return list.slice(0, limit);
  } catch (err: any) {
    console.error("[aiNewsService] Error fetching Finnhub news:", err?.message || err);
    return [];
  }
}
