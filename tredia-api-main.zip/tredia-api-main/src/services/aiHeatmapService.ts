// src/services/aiHeatmapService.ts
import { getMarketTrends, type MarketAsset } from "./marketService";
import { analyzeNextJump } from "./jumpDetectorService";

export type HeatmapBias = "bullish" | "bearish" | "neutral";

export interface HeatmapItem {
  symbol: string;
  name: string;
  assetClass: "stock" | "crypto" | "forex" | "metal" | "etf" | "other";
  sector?: string | null;
  changePct: number;
  volatility?: number | null;
  aiBias: HeatmapBias;
  aiConfidence: number; // 0–1
  sentimentScore?: number; // -1..1 reserved
  jumpProbability?: number; // 0–1
  heat: number; // 0–1
}

const FALLBACK_ASSETS: MarketAsset[] = [
  { symbol: "BTCUSD", name: "Bitcoin", changePct: 2.4, assetClass: "crypto" },
  { symbol: "ETHUSD", name: "Ethereum", changePct: 1.8, assetClass: "crypto" },
  { symbol: "AAPL", name: "Apple", changePct: 0.9, assetClass: "stock" },
  { symbol: "TSLA", name: "Tesla", changePct: -1.2, assetClass: "stock" },
  { symbol: "NVDA", name: "NVIDIA", changePct: 1.1, assetClass: "stock" },
  { symbol: "SPY", name: "S&P 500 ETF", changePct: 0.4, assetClass: "etf" },
  { symbol: "QQQ", name: "NASDAQ 100 ETF", changePct: 0.7, assetClass: "etf" },
  { symbol: "XAUUSD", name: "Gold", changePct: 0.6, assetClass: "metal" },
];

function computeHeatScore(params: {
  changePct: number;
  volatility?: number | null;
  aiBias: HeatmapBias;
  aiConfidence: number;
  sentimentScore?: number;
  jumpProbability?: number;
}): number {
  const {
    changePct,
    volatility,
    aiBias,
    aiConfidence,
    sentimentScore,
    jumpProbability,
  } = params;

  const cappedMove = Math.max(-12, Math.min(12, changePct));
  const moveScore = (cappedMove + 12) / 24; // 0..1

  const volScore =
    volatility != null ? Math.max(0, Math.min(1, volatility)) : 0.6;

  const sent =
    sentimentScore != null
      ? (Math.max(-1, Math.min(1, sentimentScore)) + 1) / 2
      : 0.55;

  const jumpScore =
    jumpProbability != null ? Math.max(0, Math.min(1, jumpProbability)) : 0.4;

  const biasBoost =
    aiBias === "bullish" ? 0.1 : aiBias === "bearish" ? 0.05 : 0;

  let raw =
    0.4 * moveScore +
    0.25 * (aiConfidence || 0.5) +
    0.2 * jumpScore +
    0.1 * sent +
    0.05 * volScore +
    biasBoost;

  return Math.max(0, Math.min(1, raw));
}

function normalizeAssetClass(cls?: string | null): HeatmapItem["assetClass"] {
  if (!cls) return "other";
  const c = cls.toLowerCase();
  if (c === "stock" || c === "equity") return "stock";
  if (c === "crypto" || c === "coin") return "crypto";
  if (c === "forex" || c === "fx") return "forex";
  if (c === "metal" || c === "metals") return "metal";
  if (c === "etf" || c === "fund") return "etf";
  return "other";
}

export async function getMarketHeatmap(limit = 80): Promise<HeatmapItem[]> {
  let movers: MarketAsset[] = [];
  let trending: MarketAsset[] = [];

  try {
    const result = await getMarketTrends();
    movers = result.movers ?? [];
    trending = result.trending ?? [];
  } catch (err) {
    console.error("[aiHeatmapService] getMarketTrends error:", err);
  }

  const base =
    movers.length || trending.length ? [...movers, ...trending] : FALLBACK_ASSETS;

  const bySymbol = new Map<string, MarketAsset>();
  for (const item of base) {
    const symbol = item.symbol || "UNKNOWN";
    const existing = bySymbol.get(symbol);
    if (!existing) bySymbol.set(symbol, item);
    else {
      const absNew = Math.abs(item.changePct ?? 0);
      const absOld = Math.abs(existing.changePct ?? 0);
      if (absNew > absOld) bySymbol.set(symbol, item);
    }
  }

  let uniqueAssets = Array.from(bySymbol.values())
    .sort((a, b) => Math.abs(b.changePct ?? 0) - Math.abs(a.changePct ?? 0))
    .slice(0, limit);

  const results: HeatmapItem[] = [];

  for (const asset of uniqueAssets) {
    const symbol = asset.symbol || "UNKNOWN";
    const name = asset.name || symbol;
    const assetClass = normalizeAssetClass(asset.assetClass);

    const changePct = typeof asset.changePct === "number" ? asset.changePct : 0;

    let aiBias: HeatmapBias = "neutral";
    if (changePct > 0.35) aiBias = "bullish";
    if (changePct < -0.35) aiBias = "bearish";

    const absMove = Math.abs(changePct);
    const aiConfidence = Math.max(0.35, Math.min(1, 0.35 + absMove / 8));

    let jumpProbability = 0.4;
    try {
      const jump = await analyzeNextJump({ symbol });
      if (typeof jump.probability === "number") {
        jumpProbability = Math.max(0, Math.min(1, jump.probability));
      }
      if (jump.expectedDirection === "up") aiBias = "bullish";
      if (jump.expectedDirection === "down") aiBias = "bearish";
    } catch (err) {
      console.error("[aiHeatmapService] analyzeNextJump error for", symbol, err);
    }

    const heat = computeHeatScore({
      changePct,
      volatility: null,
      aiBias,
      aiConfidence,
      sentimentScore: undefined,
      jumpProbability,
    });

    results.push({
      symbol,
      name,
      assetClass,
      sector: null,
      changePct,
      volatility: null,
      aiBias,
      aiConfidence,
      sentimentScore: undefined,
      jumpProbability,
      heat,
    });
  }

  results.sort((a, b) => b.heat - a.heat);
  return results;
}
