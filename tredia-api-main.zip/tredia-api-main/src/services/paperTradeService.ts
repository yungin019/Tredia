// src/services/paperTradeService.ts

import prisma from "../lib/prisma";
import axios from "axios";

const API_BASE = process.env.MARKET_API_URL || "http://localhost:4000/api";

// ------------------------
// GET LIVE PRICE
// ------------------------
export async function getLivePrice(symbol: string): Promise<number | null> {
  try {
    const res = await axios.get(`${API_BASE}/markets/info/${symbol}`);
    return res.data?.price ?? null;
  } catch (err) {
    console.error("Live price error:", err);
    return null;
  }
}

// ------------------------
// EXECUTE TRADE
// ------------------------
export async function executePaperTrade({
  userId,
  symbol,
  side,
  size,
  price,
}: {
  userId: number;
  symbol: string;
  side: "BUY" | "SELL";
  size: number; // dollar amount
  price: number;
}) {
  // Auto-create portfolio if missing
  let portfolio = await prisma.paperPortfolio.findUnique({
    where: { userId },
  });

  if (!portfolio) {
    portfolio = await prisma.paperPortfolio.create({
      data: { userId, startingCash: 10000, cash: 10000 },
    });
  }

  const quantity = size / price;

  if (side === "BUY" && portfolio.cash < size) {
    throw new Error("Insufficient cash");
  }

  // Update cash
  await prisma.paperPortfolio.update({
    where: { userId },
    data: {
      cash:
        side === "BUY"
          ? portfolio.cash - size
          : portfolio.cash + size, // SELL returns cash
    },
  });

  // Create trade entry
  const trade = await prisma.paperTrade.create({
    data: {
      userId,
      paperPortfolioId: portfolio.id,
      symbol,
      assetType: "stock",
      side,
      size,
      quantity,
      entryPrice: price,
      status: "OPEN",
    },
  });

  return trade;
}
