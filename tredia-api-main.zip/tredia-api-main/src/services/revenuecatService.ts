// src/services/revenuecatService.ts

// 🔒 RevenueCat BACKEND Disabled Mode
// -----------------------------------
// This keeps the same types + exports so the rest of the backend
// continues to work, but NO real calls are made to RevenueCat.
// Everyone is effectively on the FREE plan until we re-enable.

import prisma from "../prisma";
// We keep this import in case you manually want to call it later,
// but in disabled mode it will never be used.
import { markUserAsFounderIfEligible } from "./founderService";

export type PlanName = "FREE" | "PRO" | "ELITE";

// Prices in SEK per month (can still be used by UI if needed)
export const PLAN_PRICES: Record<PlanName, number> = {
  FREE: 0,
  PRO: 99,
  ELITE: 179,
};

// In disabled mode, this NEVER calls RevenueCat.
// It just logs and returns "FREE".
async function getPlanNameFromRevenueCat(
  appUserId: string
): Promise<PlanName> {
  console.warn(
    `[RevenueCat Disabled] getPlanNameFromRevenueCat called for appUserId=${appUserId}, returning FREE.`
  );
  return "FREE";
}

/**
 * Ensure there is a Plan row in DB for the given plan name.
 * We keep this so your DB still has FREE / PRO / ELITE rows
 * and you can later switch back to live RevenueCat easily.
 */
async function ensurePlanExists(name: PlanName) {
  let plan = await prisma.plan.findFirst({
    where: { name },
  });

  if (!plan) {
    plan = await prisma.plan.create({
      data: {
        name,
        description: `${name} plan`,
        // use the prices above so your DB is consistent
        priceMonthly: PLAN_PRICES[name],
        currency: "SEK",
      },
    });
  }

  return plan;
}

/**
 * Sync the user's plan in our database.
 *
 * 🔒 In disabled mode:
 * - No HTTP request to RevenueCat
 * - Everyone becomes FREE
 * - Plan rows still exist in DB (FREE/PRO/ELITE) for later
 */
export async function syncUserPlanFromRevenueCat(
  userId: number,
  appUserId: string
): Promise<PlanName> {
  console.warn(
    `[RevenueCat Disabled] syncUserPlanFromRevenueCat for userId=${userId}, appUserId=${appUserId} → forcing FREE plan.`
  );

  // Force FREE, but keep the structure so future re-activation is easy
  const planName: PlanName = "FREE";

  // Make sure FREE (and optionally PRO/ELITE) plans exist in your DB
  await ensurePlanExists("FREE");
  await ensurePlanExists("PRO");
  await ensurePlanExists("ELITE");

  const plan = await ensurePlanExists(planName);

  await prisma.user.update({
    where: { id: userId },
    data: { planId: plan.id },
  });
// Founder logic (disabled in dev mode)
// TS complains because planName is always "FREE" in disabled mode.
// We keep the check for when RevenueCat is re-enabled.
if (planName === ("ELITE" as PlanName)) {
  await markUserAsFounderIfEligible(userId);
}

  // return the plan we set for the user
  return planName;
}
