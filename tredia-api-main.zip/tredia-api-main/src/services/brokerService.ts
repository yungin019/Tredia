// src/services/brokerService.ts

import prisma from "../prisma";

const DEFAULT_PLATFORMS = [
  {
    slug: "avanza",
    name: "Avanza",
    connectionType: "MANUAL",
    websiteUrl: "https://www.avanza.se",
    deepLinkPattern: "https://www.avanza.se/placera/sok-aktier.html?search={symbol}",
    logoUrl: null as string | null,
  },
  {
    slug: "etoro",
    name: "eToro",
    connectionType: "MANUAL",
    websiteUrl: "https://www.etoro.com",
    deepLinkPattern: "https://www.etoro.com/markets/{symbol}",
    logoUrl: null as string | null,
  },
  {
    slug: "degiro",
    name: "DEGIRO",
    connectionType: "MANUAL",
    websiteUrl: "https://www.degiro.com",
    deepLinkPattern: "https://www.degiro.com/data/pricehub/{symbol}",
    logoUrl: null as string | null,
  },
  {
    slug: "binance",
    name: "Binance",
    connectionType: "MANUAL",
    websiteUrl: "https://www.binance.com",
    deepLinkPattern: "https://www.binance.com/en/trade/{symbol}",
    logoUrl: null as string | null,
  },
];

async function ensureDefaultPlatforms() {
  for (const p of DEFAULT_PLATFORMS) {
    await prisma.brokerPlatform.upsert({
      where: { slug: p.slug },
      update: {
        name: p.name,
        connectionType: p.connectionType,
        websiteUrl: p.websiteUrl,
        deepLinkPattern: p.deepLinkPattern,
        logoUrl: p.logoUrl,
        isEnabled: true,
      },
      create: {
        name: p.name,
        slug: p.slug,
        connectionType: p.connectionType,
        websiteUrl: p.websiteUrl,
        deepLinkPattern: p.deepLinkPattern,
        logoUrl: p.logoUrl,
      },
    });
  }
}

// ========== PUBLIC API ========== //

export async function getAvailablePlatforms() {
  await ensureDefaultPlatforms();
  return prisma.brokerPlatform.findMany({
    where: { isEnabled: true },
    orderBy: { name: "asc" },
  });
}

export async function getUserBrokerAccount(userId: number) {
  return prisma.userBrokerAccount.findFirst({
    where: { userId },
    include: { broker: true },
  });
}

export async function connectBroker(userId: number, brokerSlug: string) {
  await ensureDefaultPlatforms();

  const platform = await prisma.brokerPlatform.findUnique({
    where: { slug: brokerSlug },
  });

  if (!platform) {
    throw new Error("BROKER_PLATFORM_NOT_FOUND");
  }

  // We don't rely on a named compound unique key here -> avoids TS error.
  const existing = await prisma.userBrokerAccount.findFirst({
    where: {
      userId,
      brokerPlatformId: platform.id,
    },
  });

  // Optionally mark other accounts as disconnected
  await prisma.userBrokerAccount.updateMany({
    where: { userId },
    data: { connectionStatus: "DISCONNECTED" },
  });

  let account;
  if (existing) {
    account = await prisma.userBrokerAccount.update({
      where: { id: existing.id },
      data: {
        connectionStatus: "CONNECTED",
        updatedAt: new Date(),
      },
      include: { broker: true },
    });
  } else {
    account = await prisma.userBrokerAccount.create({
      data: {
        userId,
        brokerPlatformId: platform.id,
        displayName: platform.name,
        connectionStatus: "CONNECTED",
      },
      include: { broker: true },
    });
  }

  return account;
}

export async function disconnectBroker(userId: number) {
  await prisma.userBrokerAccount.updateMany({
    where: { userId },
    data: { connectionStatus: "DISCONNECTED" },
  });
}

export async function getTradeDeeplink(
  userId: number,
  symbol: string
): Promise<string | null> {
  const account = await prisma.userBrokerAccount.findFirst({
    where: {
      userId,
      connectionStatus: "CONNECTED",
    },
    include: { broker: true },
  });

  if (!account || !account.broker) {
    return null;
  }

  const broker = account.broker;
  const pattern = broker.deepLinkPattern;
  const cleanedSymbol = symbol.trim();

  if (pattern && pattern.includes("{symbol}")) {
    return pattern.replace("{symbol}", encodeURIComponent(cleanedSymbol));
  }

  if (broker.websiteUrl) {
    return broker.websiteUrl;
  }

  return null;
}
