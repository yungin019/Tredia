import axios from 'axios';

export async function fetchRealAiDashboardData() {
  try {
    // Polygon
    const polygon = await axios.get('https://api.polygon.io/v2/aggs/grouped/locale/us/market/stocks/2023-12-27', {
      params: { apiKey: process.env.POLYGON_API_KEY },
    });
    // Finnhub
    const finnhub = await axios.get('https://finnhub.io/api/v1/stock/symbol?exchange=US', {
      params: { token: process.env.FINNHUB_API_KEY },
    });
    // CryptoCompare
    const crypto = await axios.get('https://min-api.cryptocompare.com/data/top/totalvolfull', {
      params: { limit: 10, tsym: 'USD', api_key: process.env.CRYPTOCOMPARE_API_KEY },
    });
    return {
      polygon: polygon.data,
      finnhub: finnhub.data,
      crypto: crypto.data,
    };
  } catch (e) {
    return null;
  }
}
