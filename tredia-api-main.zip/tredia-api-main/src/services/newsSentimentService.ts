// src/services/newsSentimentService.ts
//
// "World-class quant" news sentiment + impacted assets logic.
//
// 1️⃣ First, try REAL Super AI (OpenAI) for structured sentiment per article.
// 2️⃣ If unavailable or failing, fall back to a deterministic quant-style
//    word-based sentiment + impact scoring system.
// 3️⃣ Enrich impacted assets detection using:
//      - Finnhub `related` field
//      - Tredia asset registry aliases
//      - simple ticker pattern in text
//
// This way, your app already behaves like a serious AI quant,
// but remains robust in dev / low-connectivity environments.

import type { FinnhubNewsItem } from "./aiNewsService";
import OpenAI from "openai";
import * as assetsRegistryModule from "../data/assetsRegistry";

const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";

const openai =
  OPENAI_API_KEY.trim().length > 0
    ? new OpenAI({ apiKey: OPENAI_API_KEY })
    : null;

// Try to read your asset registry in a safe way (no TS errors if shape changes)
const ASSET_REGISTRY: any[] =
  (assetsRegistryModule as any).default ||
  (assetsRegistryModule as any).ASSET_REGISTRY ||
  (assetsRegistryModule as any).assetRegistry ||
  (assetsRegistryModule as any).ASSETS ||
  [];

// ---------- Types ----------

export type SentimentLabel = "bullish" | "bearish" | "neutral";

export interface NewsSentiment {
  id: string;
  title: string;
  summary: string | null;
  sentimentLabel: SentimentLabel;
  sentimentScore: number; // -1 (very bearish) to +1 (very bullish)
  impactScore: number; // 0–100
  impactedSymbols: string[];
  horizon: "intraday" | "swing" | "position";
  confidence: number; // 0–1
  source?: string | null;
  url?: string | null;
  publishedAt?: string | null;
  categories?: string[];
  aiComment?: string | null;
}

// Very simple word lists – used only for fallback quant logic.
const POSITIVE_WORDS: string[] = [
  "beat",
  "beats",
  "surge",
  "surges",
  "rally",
  "rallies",
  "jump",
  "jumps",
  "record",
  "strong",
  "growth",
  "upgrade",
  "bull",
  "bullish",
  "optimism",
  "optimistic",
];

const NEGATIVE_WORDS: string[] = [
  "miss",
  "misses",
  "drop",
  "drops",
  "fall",
  "falls",
  "crash",
  "crashes",
  "plunge",
  "plunges",
  "cut",
  "cuts",
  "downgrade",
  "bear",
  "bearish",
  "fear",
  "fears",
  "risk",
  "risks",
  "volatility",
];

/* ------------------------------------------------------------------ */
/* S M A L L   U T I L S                                              */
/* ------------------------------------------------------------------ */

function uniq<T>(arr: T[]): T[] {
  return Array.from(new Set(arr));
}

function parseRelated(related?: string): string[] {
  if (!related) return [];
  return related
    .split(",")
    .map((s) => s.trim().toUpperCase())
    .filter((s) => s.length > 0 && s.length <= 10);
}

/**
 * Use Tredia's asset registry + simple ticker heuristics
 * to detect impacted tickers inside a text (headline + summary).
 */
function detectAssetTickersFromText(rawText: string | undefined | null): string[] {
  if (!rawText) return [];

  const text = rawText.toLowerCase();
  const tokens = rawText.split(/\s+/);

  const found = new Set<string>();

  // 1) Registry-based detection
  if (Array.isArray(ASSET_REGISTRY)) {
    for (const asset of ASSET_REGISTRY) {
      if (!asset) continue;

      const symbol: string | undefined =
        typeof asset.symbol === "string"
          ? asset.symbol
          : typeof asset.ticker === "string"
          ? asset.ticker
          : undefined;

      const aliases: string[] = Array.isArray(asset.aliases)
        ? asset.aliases.filter((a: any) => typeof a === "string")
        : [];

      if (symbol) {
        const symUpper = symbol.toUpperCase();
        const symLower = symbol.toLowerCase();

        // exact word match for symbol
        const symRegex = new RegExp(`\\b${symLower}\\b`, "i");
        if (symRegex.test(text)) {
          found.add(symUpper);
        }
      }

      for (const alias of aliases) {
        const aliasLower = alias.toLowerCase().trim();
        if (!aliasLower) continue;
        const aliasRegex = new RegExp(`\\b${aliasLower}\\b`, "i");
        if (aliasRegex.test(text)) {
          if (symbol) {
            found.add(symbol.toUpperCase());
          }
        }
      }
    }
  }

  // 2) Simple generic ticker detection – 2–5 capital letters
  for (const t of tokens) {
    const clean = t.replace(/[^A-Za-z0-9]/g, "");
    if (clean.length >= 2 && clean.length <= 5 && /^[A-Z]+$/.test(clean)) {
      found.add(clean.toUpperCase());
    }
  }

  return Array.from(found);
}

/* ------------------------------------------------------------------ */
/* F A L L B A C K   Q U A N T   L O G I C                            */
/* ------------------------------------------------------------------ */

function computeSentimentScore(text: string): number {
  const lower = text.toLowerCase();

  let pos = 0;
  let neg = 0;

  for (const w of POSITIVE_WORDS) {
    if (lower.includes(w)) pos += 1;
  }
  for (const w of NEGATIVE_WORDS) {
    if (lower.includes(w)) neg += 1;
  }

  if (pos === 0 && neg === 0) return 0;

  const raw = (pos - neg) / (pos + neg);
  // clamp
  return Math.max(-1, Math.min(1, raw));
}

function labelFromScore(score: number): SentimentLabel {
  if (score > 0.15) return "bullish";
  if (score < -0.15) return "bearish";
  return "neutral";
}

/**
 * Determine time horizon from timestamp.
 */
function inferHorizon(datetime?: number): "intraday" | "swing" | "position" {
  if (!datetime) return "swing";

  const nowSec = Math.floor(Date.now() / 1000);
  const ageSec = nowSec - datetime;

  if (ageSec <= 24 * 3600) return "intraday";
  if (ageSec <= 7 * 24 * 3600) return "swing";
  return "position";
}

/**
 * Build an impact score (0–100) based on sentiment and recency.
 */
function computeImpactScore(score: number, datetime?: number): number {
  const abs = Math.abs(score); // 0–1
  let base = abs * 70; // up to 70pts from sentiment strength

  const horizon = inferHorizon(datetime);
  if (horizon === "intraday") base += 20;
  else if (horizon === "swing") base += 10;

  return Math.round(Math.max(0, Math.min(100, base)));
}

/**
 * High-level AI-style comment (used in fallback).
 */
function buildAiComment(
  label: SentimentLabel,
  symbols: string[],
  impact: number
): string {
  const target = symbols.length > 0 ? symbols.slice(0, 3).join(", ") : "this area";

  const intensity =
    impact >= 80
      ? "a strong"
      : impact >= 50
      ? "a moderate"
      : "a mild";

  if (label === "bullish") {
    return `AI flags ${intensity} bullish tone around ${target}. Market participants may be positioning for upside if follow-through confirms.`;
  }
  if (label === "bearish") {
    return `AI flags ${intensity} bearish pressure on ${target}. Risk management and position size are critical if you are already exposed.`;
  }
  return `Sentiment is mixed around ${target}. This could evolve into a clearer opportunity as new data and price action develop.`;
}

/**
 * Fallback: deterministic quant analysis for a batch of news.
 */
function fallbackAnalyzeBatch(
  items: FinnhubNewsItem[],
  limit: number
): NewsSentiment[] {
  const slice: FinnhubNewsItem[] = items.slice(0, limit);

  return slice.map((item: FinnhubNewsItem, idx: number) => {
    const title = item.headline || "Market update";
    const summary = item.summary || null;
    const baseText = `${title}. ${summary || ""}`;
    const score = computeSentimentScore(baseText);
    const label = labelFromScore(score);

    const finnhubRel = parseRelated(item.related);
    const fromText = detectAssetTickersFromText(
      `${item.headline || ""} ${item.summary || ""}`
    );
    const impactedSymbols = uniq([...finnhubRel, ...fromText]);

    const horizon = inferHorizon(item.datetime);
    const impactScore = computeImpactScore(score, item.datetime);

    // Confidence: combine sentiment strength + recency
    const abs = Math.abs(score);
    let conf = abs * 0.6;
    if (horizon === "intraday") conf += 0.25;
    else if (horizon === "swing") conf += 0.15;
    conf = Math.max(0.1, Math.min(1, conf));

    const aiComment = buildAiComment(label, impactedSymbols, impactScore);

    return {
      id: String(item.id ?? idx),
      title,
      summary,
      sentimentLabel: label,
      sentimentScore: score,
      impactScore,
      impactedSymbols,
      horizon,
      confidence: conf,
      source: item.source || null,
      url: item.url || null,
      publishedAt: item.datetime
        ? new Date(item.datetime * 1000).toISOString()
        : null,
      categories: item.category ? [item.category] : [],
      aiComment,
    };
  });
}

/* ------------------------------------------------------------------ */
/* S U P E R   A I   ( O P E N A I )                                  */
/* ------------------------------------------------------------------ */

async function superAiAnalyzeNewsBatch(
  items: FinnhubNewsItem[],
  limit: number
): Promise<NewsSentiment[] | null> {
  if (!openai) {
    console.warn(
      "[newsSentimentService] OPENAI_API_KEY missing – using fallback quant sentiment."
    );
    return null;
  }

  const slice: FinnhubNewsItem[] = items.slice(0, limit);

  // Reduce payload for the model
  const compact = slice.map((n: FinnhubNewsItem, idx: number) => ({
    id: String(n.id ?? idx),
    headline: n.headline || "",
    summary: n.summary || "",
    source: n.source || "",
    url: n.url || "",
    category: n.category || "",
    datetime: n.datetime || null,
    related: n.related || "",
  }));

  const systemPrompt = `
You are a world-class quantitative analyst and macro trader.
You receive a batch of real-time news articles. For each article, you must:

1. Classify sentiment for the main traded assets or sectors:
   - "bullish", "bearish" or "neutral"

2. Estimate a continuous sentiment score in the range [-1, 1].
   - -1 = extremely bearish
   -  0 = neutral
   - +1 = extremely bullish

3. Infer an "impactScore" in [0, 100] combining:
   - the strength of the sentiment
   - how market-moving the information is likely to be for liquid assets
   - macro relevance (e.g. central banks, inflation, large caps, key sectors)

4. Propose a time horizon:
   - "intraday" (0–24h)
   - "swing" (1–7 days)
   - "position" (weeks/months)

5. Extract impacted tickers or assets:
   - Use the article text, related field and your knowledge of global markets.
   - Return 0–5 symbols per article (e.g. "AAPL", "SPY", "XAUUSD", "BTC").

6. Provide a short AI comment (1–2 sentences) explaining:
   - what the news means for these assets
   - how traders or investors might react.

Return a pure JSON array, each element corresponding to one article,
with this exact shape:

[
  {
    "id": "string",                    // reuse input id
    "sentimentLabel": "bullish" | "bearish" | "neutral",
    "sentimentScore": 0.0,            // -1 to 1
    "impactScore": 0,                 // 0 to 100
    "horizon": "intraday" | "swing" | "position",
    "impactedSymbols": ["AAPL", "SPY"],
    "confidence": 0.0,                // 0 to 1 (overall confidence)
    "aiComment": "string explanation"
  }
]

Do NOT include any extra top-level keys.
`;

  const userPrompt = `
Here is the batch of news articles as JSON:

${JSON.stringify(compact, null, 2)}
`;

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      temperature: 0.1,
    });

    const raw = completion.choices[0]?.message?.content || "{}";
    let parsed: any;
    try {
      parsed = JSON.parse(raw);
    } catch (e) {
      console.warn("[newsSentimentService] Super AI JSON parse error:", e);
      return null;
    }

    const list: any[] = Array.isArray(parsed)
      ? parsed
      : Array.isArray(parsed.data)
      ? parsed.data
      : [];

    if (!list.length) {
      console.warn(
        "[newsSentimentService] Super AI returned empty sentiment list, using fallback."
      );
      return null;
    }

    // Map back into our strongly-typed NewsSentiment objects
    const byId = new Map<string, FinnhubNewsItem>();
    compact.forEach((n, idx) => {
      const id = String(n.id ?? idx);
      const original = slice.find(
        (it, j) => String(it.id ?? j) === id
      ) as FinnhubNewsItem | undefined;
      if (original) {
        byId.set(id, original);
      }
    });

    const result: NewsSentiment[] = list.map((item: any, idx: number) => {
      const id = String(item.id ?? compact[idx]?.id ?? idx);
      const original = byId.get(id) || slice[idx] || ({} as FinnhubNewsItem);

      const label: SentimentLabel =
        item.sentimentLabel === "bullish" || item.sentimentLabel === "bearish"
          ? item.sentimentLabel
          : "neutral";

      const score =
        typeof item.sentimentScore === "number"
          ? Math.max(-1, Math.min(1, item.sentimentScore))
          : 0;

      const impact =
        typeof item.impactScore === "number"
          ? Math.max(0, Math.min(100, item.impactScore))
          : 0;

      const horizon: "intraday" | "swing" | "position" =
        item.horizon === "intraday" || item.horizon === "position"
          ? item.horizon
          : "swing";

      const confidence =
        typeof item.confidence === "number"
          ? Math.max(0, Math.min(1, item.confidence))
          : 0.6;

      const impactedSymbolsFromModel: string[] = Array.isArray(
        item.impactedSymbols
      )
        ? item.impactedSymbols
            .filter((s: any) => typeof s === "string")
            .map((s: string) => s.trim().toUpperCase())
            .filter((s: string) => s.length > 0)
        : [];

      // Also re-run our local detection and merge (AI + heuristics)
      const finnhubRel = parseRelated(original.related);
      const fromText = detectAssetTickersFromText(
        `${original.headline || ""} ${original.summary || ""}`
      );
      const impactedSymbols = uniq([
        ...impactedSymbolsFromModel,
        ...finnhubRel,
        ...fromText,
      ]);

      const aiComment: string | null =
        typeof item.aiComment === "string" && item.aiComment.trim().length > 0
          ? item.aiComment.trim()
          : null;

      const title = original.headline || "Market update";
      const summary = original.summary || null;

      return {
        id,
        title,
        summary,
        sentimentLabel: label,
        sentimentScore: score,
        impactScore: impact,
        impactedSymbols,
        horizon,
        confidence,
        source: original.source || null,
        url: original.url || null,
        publishedAt: original.datetime
          ? new Date(original.datetime * 1000).toISOString()
          : null,
        categories: original.category ? [original.category] : [],
        aiComment,
      };
    });

    return result;
  } catch (err) {
    console.error(
      "[newsSentimentService] Super AI sentiment call failed, using fallback:",
      err
    );
    return null;
  }
}

/* ------------------------------------------------------------------ */
/* P U B L I C   A P I                                                */
/* ------------------------------------------------------------------ */

/**
 * Main entry: analyze a batch of real news items.
 *
 * - Tries Super AI (OpenAI) first for world-class sentiment
 * - Falls back to deterministic quant logic if anything goes wrong
 */
export async function analyzeNewsBatchWithAi(
  items: FinnhubNewsItem[],
  limit: number = 12
): Promise<NewsSentiment[]> {
  if (!items || items.length === 0) return [];

  // 1) Try Super AI
  try {
    const superAi = await superAiAnalyzeNewsBatch(items, limit);
    if (superAi && superAi.length > 0) {
      return superAi;
    }
  } catch (err) {
    console.error(
      "[newsSentimentService] Error in Super AI path, falling back:",
      err
    );
  }

  // 2) Fallback quant logic
  return fallbackAnalyzeBatch(items, limit);
}
