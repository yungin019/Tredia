// tredia-api/src/services/aiRecommendationService.ts
//
// "Recommendations" should be SIGNALS, not a second AI personality.
// This service must NOT call OpenAI.
// It produces a structured, deterministic set of signals from market data.
// The Assistant (assistantService.ts) is the only component that "speaks" in Tredia Voice.

import { getMarketTrends, type MarketAsset } from "./marketService";

export type UserTier = "free" | "pro" | "elite";

export type SignalDirection = "bullish" | "bearish" | "neutral";
export type SignalHorizon = "intraday" | "swing" | "position";
export type RiskLevel = "low" | "medium" | "high";

export interface RecommendationSignal {
  symbol: string;
  assetClass?: string | null;
  direction: SignalDirection;
  confidence: number; // 0..100 (deterministic heuristic)
  horizon: SignalHorizon;
  riskLevel: RiskLevel;

  // "Why it's on radar" - short, non-AI, factual-ish.
  reason: string;

  // Pro/Elite enrichment
  stats?: {
    price?: number | null;
    changePct?: number | null;
    absMove?: number | null;
  };

  // Elite enrichment
  notes?: string[];
  tags?: string[];
}

// -------------------------
// helpers
// -------------------------

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function abs(n: number | null | undefined) {
  return typeof n === "number" ? Math.abs(n) : 0;
}

function directionFromChange(changePct: number): SignalDirection {
  if (changePct > 0.2) return "bullish";
  if (changePct < -0.2) return "bearish";
  return "neutral";
}

function horizonFromAbsMove(absMove: number): SignalHorizon {
  // crude but useful:
  // very large daily move -> intraday focus
  // medium move -> swing
  // small move -> position/radar
  if (absMove >= 5) return "intraday";
  if (absMove >= 1.5) return "swing";
  return "position";
}

function riskFromAbsMove(absMove: number): RiskLevel {
  if (absMove >= 6) return "high";
  if (absMove >= 2.5) return "medium";
  return "low";
}

function confidenceFromAbsMove(absMove: number): number {
  // Confidence here means: "this is a real move worth attention",
  // not "this will go up".
  // We scale attention-confidence with move magnitude.
  // 0.5% move ~ low attention, 8%+ ~ high attention.
  const base = (absMove / 8) * 100;
  return clamp(Math.round(base), 15, 92);
}

function safeName(symbol: string, name?: string | null) {
  return (name && name.trim().length > 0 ? name : symbol).trim();
}

function buildReason(a: MarketAsset): string {
  const sym = a.symbol;
  const nm = safeName(sym, a.name);
  const ch = typeof a.changePct === "number" ? a.changePct : 0;
  const absMove = Math.abs(ch);

  const dir = directionFromChange(ch);
  const sign = ch >= 0 ? "+" : "";
  const pct = `${sign}${ch.toFixed(2)}%`;

  if (dir === "bullish") return `${nm} is showing upside momentum today (${pct}).`;
  if (dir === "bearish") return `${nm} is under downside pressure today (${pct}).`;
  return `${nm} is relatively flat today (${pct}) but remains on radar.`;
}

function dedupeBySymbolKeepBiggestAbsMove(items: MarketAsset[]): MarketAsset[] {
  const map = new Map<string, MarketAsset>();
  for (const it of items) {
    const key = (it.symbol || "").toUpperCase();
    if (!key) continue;

    const existing = map.get(key);
    if (!existing) {
      map.set(key, it);
      continue;
    }

    const absNew = Math.abs(it.changePct ?? 0);
    const absOld = Math.abs(existing.changePct ?? 0);
    if (absNew > absOld) map.set(key, it);
  }
  return Array.from(map.values());
}

// -------------------------
// main
// -------------------------

/**
 * Deterministic recommendation signals:
 * - pulls from getMarketTrends()
 * - ranks by absolute move
 * - returns tier-specific fields
 *
 * IMPORTANT:
 * - This does NOT say "Buy/Sell"
 * - This does NOT call OpenAI
 * - AssistantService should "explain" these signals in Tredia voice
 */
export async function generateRecommendations(
  tier: UserTier
): Promise<RecommendationSignal[]> {
  const limit = tier === "elite" ? 10 : tier === "pro" ? 6 : 3;

  const { movers, trending } = await getMarketTrends();

  // Combine + dedupe + prioritize real movers
  const combined = dedupeBySymbolKeepBiggestAbsMove([
    ...(movers || []),
    ...(trending || []),
  ]);

  const ranked = combined
    .filter((a) => typeof a.symbol === "string" && a.symbol.length > 0)
    .sort((a, b) => abs(b.changePct) - abs(a.changePct))
    .slice(0, 60);

  const top = ranked.slice(0, limit);

  const out: RecommendationSignal[] = top.map((a) => {
    const changePct = typeof a.changePct === "number" ? a.changePct : 0;
    const absMove = Math.abs(changePct);

    const direction = directionFromChange(changePct);
    const horizon = horizonFromAbsMove(absMove);
    const riskLevel = riskFromAbsMove(absMove);
    const confidence = confidenceFromAbsMove(absMove);

    const base: RecommendationSignal = {
      symbol: a.symbol,
      assetClass: a.assetClass ?? null,
      direction,
      confidence,
      horizon,
      riskLevel,
      reason: buildReason(a),
    };

    if (tier === "pro" || tier === "elite") {
      base.stats = {
        price: a.price ?? null,
        changePct,
        absMove: parseFloat(absMove.toFixed(2)),
      };
    }

    if (tier === "elite") {
      const tags: string[] = [];
      if (direction === "bullish") tags.push("momentum-up");
      if (direction === "bearish") tags.push("momentum-down");
      if (riskLevel === "high") tags.push("high-vol");
      if (a.assetClass) tags.push(String(a.assetClass).toLowerCase());

      const notes: string[] = [];
      if (horizon === "intraday") {
        notes.push("Large daily move: watch for continuation vs mean-reversion.");
      } else if (horizon === "swing") {
        notes.push("Mid-size move: often becomes a 1–7 day theme if catalysts persist.");
      } else {
        notes.push("Smaller move: keep on radar for setup confirmation.");
      }

      notes.push("Signal is attention-based (move magnitude), not a profit guarantee.");

      base.tags = tags;
      base.notes = notes;
    }

    return base;
  });

  return out;
}
