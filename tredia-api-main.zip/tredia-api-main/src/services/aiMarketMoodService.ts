// src/services/aiMarketMoodService.ts
import { finnhubClient } from "../config/finnhub";

/**
 * Builds a compact description of global market mood
 * (indices + BTC) used as context for Super AI.
 */
export async function getMarketContext(): Promise<string> {
  try {
    const symbols = ["^GSPC", "^NDX", "^DJI", "BTCUSD"];
    const lines: string[] = [];

    for (const symbol of symbols) {
      try {
        // Finnhub quote endpoint
        const resp = await finnhubClient.get("/quote", {
          params: { symbol },
        });
        const q = resp.data as any;

        const change = typeof q.dp === "number" ? q.dp.toFixed(2) : q.dp;
        lines.push(`${symbol}: ${q.c} (${change}% change)`);
      } catch (err) {
        console.error("getMarketContext symbol error:", symbol, err);
        lines.push(`${symbol}: data unavailable`);
      }
    }

    if (lines.length === 0) {
      return "Market data unavailable.";
    }

    return lines.join("\n");
  } catch (err) {
    console.error("getMarketContext global error:", err);
    return "Market data unavailable.";
  }
}
