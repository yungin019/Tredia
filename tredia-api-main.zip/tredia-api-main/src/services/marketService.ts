import axios from "axios";
import { finnhubClient } from "../config/finnhub";
import { twelvedataClient, hasTwelveData } from "../config/twelvedata";

const POLYGON_API_KEY = process.env.POLYGON_API_KEY;

if (!POLYGON_API_KEY) {
  console.warn(
    "[marketService] POLYGON_API_KEY is not set. /markets/trends will rely on Finnhub fallback baskets."
  );
}

export type AssetClass = "stock" | "crypto" | "forex" | "metal" | "etf" | "other";

export interface MarketAsset {
  symbol: string;
  name?: string | null;
  price?: number | null;
  changePct: number; // % change today (best-effort)
  assetClass?: AssetClass | null;
  sparkline?: number[];
}

// ---------------- Polygon snapshot types ----------------

type PolygonSnapshotTicker = {
  ticker: string;
  todaysChange?: number;
  todaysChangePerc?: number;
  lastTrade?: { p?: number | null } | null;
  day?: { c?: number | null } | null;
};

type PolygonSnapshotResponse = {
  status?: string;
  tickers?: PolygonSnapshotTicker[];
};

const polygon = axios.create({
  baseURL: "https://api.polygon.io",
  timeout: 8000,
});

function toNum(v: any): number | null {
  return typeof v === "number" && Number.isFinite(v) ? v : null;
}

function normalizeAssetClass(cls?: string | null): AssetClass {
  if (!cls) return "other";
  const c = String(cls).toLowerCase();

  if (c === "index") return "etf";
  if (c === "stock" || c === "equity") return "stock";
  if (c === "crypto" || c === "coin") return "crypto";
  if (c === "forex" || c === "fx") return "forex";
  if (c === "metal" || c === "metals") return "metal";
  if (c === "etf" || c === "fund") return "etf";

  return "other";
}

async function fetchPolygonSnapshot(
  market: "stocks" | "crypto" | "forex",
  direction: "gainers" | "losers"
): Promise<PolygonSnapshotTicker[]> {
  if (!POLYGON_API_KEY) return [];

  const path =
    market === "stocks"
      ? `/v2/snapshot/locale/us/markets/stocks/${direction}`
      : `/v2/snapshot/locale/global/markets/${market}/${direction}`;

  try {
    const res = await polygon.get<PolygonSnapshotResponse>(path, {
      params: { apiKey: POLYGON_API_KEY },
    });
    return res.data?.tickers ?? [];
  } catch (err: any) {
    console.error(
      `[marketService] Polygon snapshot error (${market}/${direction}):`,
      err?.response?.data || err?.message || err
    );
    return [];
  }
}

function mapPolygonTickersToAssets(
  tickers: PolygonSnapshotTicker[],
  assetClass: AssetClass
): MarketAsset[] {
  return (tickers || [])
    .map<MarketAsset | null>((t) => {
      const symbol = t.ticker;
      if (!symbol) return null;

      const changePct = toNum(t.todaysChangePerc) ?? 0;
      const price = toNum(t.lastTrade?.p) ?? toNum(t.day?.c) ?? null;

      return {
        symbol,
        name: symbol,
        price,
        changePct,
        assetClass,
        sparkline: [],
      };
    })
    .filter((x): x is MarketAsset => !!x);
}

// ---------------- Finnhub quote baskets ----------------

const FALLBACK_STOCKS = ["AAPL", "MSFT", "NVDA", "TSLA", "AMZN", "META"];
const FALLBACK_ETFS = ["SPY", "QQQ", "IWM"];
const FALLBACK_CRYPTO = ["BINANCE:BTCUSDT", "BINANCE:ETHUSDT", "BINANCE:SOLUSDT"];

async function fetchFinnhubQuotes(
  symbols: string[],
  assetClass: AssetClass
): Promise<MarketAsset[]> {
  const results: MarketAsset[] = [];

  await Promise.all(
    symbols.map(async (symbol) => {
      try {
        const resp = await finnhubClient.get("/quote", { params: { symbol } });
        const q: any = resp.data;

        const price = toNum(q?.c);
        const changePct = toNum(q?.dp) ?? 0;

        // skip dead symbols / rate-limited zeros
        if (price == null && changePct === 0) return;

        results.push({
          symbol,
          name: symbol,
          price,
          changePct,
          assetClass,
          sparkline: [],
        });
      } catch {
        return;
      }
    })
  );

  return results;
}

// ---------------- TwelveData (Forex + Metals) ----------------
//
// We use TwelveData because Finnhub FX/metals were locked (403) on your plan.
// TwelveData /quote supports pairs like EUR/USD, XAU/USD, USD/JPY.
//

type TwelveQuote = {
  symbol?: string;
  name?: string;
  close?: string;
  price?: string;
  percent_change?: string;
  change_percent?: string;
  status?: "ok" | "error";
  message?: string;
};

function parseTwelveNumber(v: any): number | null {
  if (v == null) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

async function fetchTwelveQuote(symbolSlash: string): Promise<TwelveQuote | null> {
  if (!hasTwelveData()) return null;

  try {
    const resp = await twelvedataClient.get("/quote", {
      params: { symbol: symbolSlash },
    });
    return resp.data as TwelveQuote;
  } catch (err: any) {
    console.warn(
      "[marketService] TwelveData quote failed:",
      symbolSlash,
      err?.response?.data || err?.message || err
    );
    return null;
  }
}

async function fetchForexAndMetalsFromTwelveData(): Promise<MarketAsset[]> {
  if (!hasTwelveData()) return [];

  // Feel free to add more pairs
  const targets: Array<{
    requested: string; // what the app expects
    symbolSlash: string; // what TwelveData expects
    name: string;
    assetClass: AssetClass;
  }> = [
    { requested: "EURUSD", symbolSlash: "EUR/USD", name: "EUR / USD", assetClass: "forex" },
    { requested: "GBPUSD", symbolSlash: "GBP/USD", name: "GBP / USD", assetClass: "forex" },
    { requested: "USDJPY", symbolSlash: "USD/JPY", name: "USD / JPY", assetClass: "forex" },
    { requested: "XAUUSD", symbolSlash: "XAU/USD", name: "Gold (XAU / USD)", assetClass: "metal" },
    { requested: "XAGUSD", symbolSlash: "XAG/USD", name: "Silver (XAG / USD)", assetClass: "metal" },
  ];

  const out: MarketAsset[] = [];

  const quotes = await Promise.all(
    targets.map(async (t) => {
      const q = await fetchTwelveQuote(t.symbolSlash);
      return { t, q };
    })
  );

  for (const { t, q } of quotes) {
    if (!q || (q as any).status === "error") continue;

    const price = parseTwelveNumber(q.close ?? q.price);
    if (price == null || price <= 0) continue;

    const changePct = parseTwelveNumber(q.percent_change ?? q.change_percent) ?? 0;

    out.push({
      symbol: t.requested,
      name: t.name,
      price,
      changePct,
      assetClass: t.assetClass,
      sparkline: [],
    });
  }

  return out;
}

// ---------------- helpers ----------------

function dedupeKeepBiggestMove(items: MarketAsset[]): MarketAsset[] {
  const bySymbol = new Map<string, MarketAsset>();

  for (const a of items) {
    const symbol = a.symbol || "UNKNOWN";
    const existing = bySymbol.get(symbol);

    if (!existing) {
      bySymbol.set(symbol, a);
      continue;
    }

    const absNew = Math.abs(a.changePct ?? 0);
    const absOld = Math.abs(existing.changePct ?? 0);

    if (absNew > absOld) bySymbol.set(symbol, a);
  }

  return Array.from(bySymbol.values());
}

// ---------------- main ----------------

export async function getMarketTrends(): Promise<{
  movers: MarketAsset[];
  trending: MarketAsset[];
}> {
  // --- 1) Polygon snapshots (if key exists) ---
  const [
    stockGainers,
    stockLosers,
    cryptoGainers,
    cryptoLosers,
    fxGainers,
    fxLosers,
  ] = await Promise.all([
    fetchPolygonSnapshot("stocks", "gainers"),
    fetchPolygonSnapshot("stocks", "losers"),
    fetchPolygonSnapshot("crypto", "gainers"),
    fetchPolygonSnapshot("crypto", "losers"),
    fetchPolygonSnapshot("forex", "gainers"),
    fetchPolygonSnapshot("forex", "losers"),
  ]);

  const polygonAssets: MarketAsset[] = [
    ...mapPolygonTickersToAssets(stockGainers, "stock"),
    ...mapPolygonTickersToAssets(stockLosers, "stock"),
    ...mapPolygonTickersToAssets(cryptoGainers, "crypto"),
    ...mapPolygonTickersToAssets(cryptoLosers, "crypto"),
    ...mapPolygonTickersToAssets(fxGainers, "forex"),
    ...mapPolygonTickersToAssets(fxLosers, "forex"),
  ];

  // --- 2) Finnhub quotes (stocks/etf/crypto) ---
  const [stocks, etfs, crypto] = await Promise.all([
    fetchFinnhubQuotes(FALLBACK_STOCKS, "stock"),
    fetchFinnhubQuotes(FALLBACK_ETFS, "etf"),
    fetchFinnhubQuotes(FALLBACK_CRYPTO, "crypto"),
  ]);

  // --- 3) TwelveData FX + Metals (EURUSD + XAUUSD etc.) ---
  const fxAndMetals = await fetchForexAndMetalsFromTwelveData();

  // Merge all and normalize classes
  const merged = dedupeKeepBiggestMove([
    ...polygonAssets,
    ...stocks,
    ...etfs,
    ...crypto,
    ...fxAndMetals,
  ]).map((a) => ({
    ...a,
    assetClass: normalizeAssetClass(a.assetClass ?? "other"),
  }));

  // movers: biggest absolute moves
  const movers = [...merged]
    .sort((a, b) => Math.abs(b.changePct ?? 0) - Math.abs(a.changePct ?? 0))
    .slice(0, 60);

  // trending: strongest moves (best-effort)
  const trending = [...merged]
    .filter((a) => a.price != null) // keep useful items
    .sort((a, b) => Math.abs(b.changePct ?? 0) - Math.abs(a.changePct ?? 0))
    .slice(0, 40);

  return { movers, trending };
}
