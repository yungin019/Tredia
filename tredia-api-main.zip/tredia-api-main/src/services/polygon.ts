// src/services/polygon.ts

import axios from "axios";

const POLYGON_API_KEY = process.env.POLYGON_API_KEY || "";

if (!POLYGON_API_KEY) {
  console.warn("[polygon] POLYGON_API_KEY is not set. Market data will return fallbacks.");
}

const polygonClient = axios.create({
  baseURL: "https://api.polygon.io",
  timeout: 7000,
});

// ---- Helpers ----

function formatDate(d: Date): string {
  const year = d.getFullYear();
  const month = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  return `${year}-${month}-${day}`;
}

// Return an array of close prices for the last `days` sessions
export async function fetchDailyAggs(symbol: string, days: number = 30): Promise<number[]> {
  if (!POLYGON_API_KEY) {
    return [];
  }

  try {
    const now = new Date();
    const fromDate = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);

    const from = formatDate(fromDate);
    const to = formatDate(now);

    const resp = await polygonClient.get(`/v2/aggs/ticker/${symbol.toUpperCase()}/range/1/day/${from}/${to}`, {
      params: {
        adjusted: "true",
        sort: "asc",
        limit: 120,
        apiKey: POLYGON_API_KEY,
      },
    });

    const data = resp.data || {};
    const results: any[] = Array.isArray(data.results) ? data.results : [];

    const closes = results
      .map((bar: any) => {
        if (typeof bar.c === "number") return bar.c;
        if (typeof bar.close === "number") return bar.close;
        return null;
      })
      .filter((v: number | null) => typeof v === "number") as number[];

    // last 30 points max
    return closes.slice(-days);
  } catch (err) {
    console.error("[polygon] fetchDailyAggs error for", symbol, err);
    return [];
  }
}

// Snapshot used by dashboard & trends
export async function fetchAssetSnapshot(symbol: string) {
  const upper = symbol.toUpperCase();

  const sparkline = await fetchDailyAggs(upper, 30);

  if (!sparkline.length) {
    return {
      symbol: upper,
      name: upper,
      changePct: 0,
      sparkline: [],
    };
  }

  const first = sparkline[0];
  const last = sparkline[sparkline.length - 1];

  const changePct = first !== 0 ? ((last - first) / first) * 100 : 0;

  return {
    symbol: upper,
    name: upper,
    changePct,
    sparkline,
  };
}
