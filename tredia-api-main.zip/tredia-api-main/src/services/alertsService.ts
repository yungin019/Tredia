// src/services/alertsService.ts

import prisma from "../lib/prisma";

export type AlertSeverity = "info" | "warning" | "critical";

export interface CreateAlertOptions {
  type: string;
  title: string;
  message: string;
  symbol?: string;
  severity?: AlertSeverity;
}

/**
 * Create and store a market alert in the DB.
 */
export async function createMarketAlert(opts: CreateAlertOptions) {
  const { type, title, message, symbol, severity } = opts;

  return prisma.marketAlert.create({
    data: {
      type,
      title,
      message,
      symbol: symbol ?? null,
      severity: severity ?? "info",
    },
  });
}

/**
 * Get the most recent alerts (global feed).
 */
export async function getRecentAlerts(limit = 50) {
  return prisma.marketAlert.findMany({
    orderBy: {
      createdAt: "desc",
    },
    take: limit,
  });
}

/**
 * Generate a daily digest alert.
 *
 * For now we return a static but realistic digest so that:
 *  - there is zero dependency on any AI helper (no runAssistantModel)
 *  - the app always gets something safe to render
 *
 * Later we can plug your Tredia AI assistant here.
 */
export async function generateDailyDigestAlert() {
  const title = "Daily Market Digest";

  const message =
    [
      "• Stocks: Major indices trade mixed after recent rallies, with tech showing slightly stronger momentum.",
      "• Crypto: BTC and ETH remain range-bound with elevated intraday volatility — position sizing stays key.",
      "• Macro: Markets keep an eye on upcoming rate comments and inflation data, which could shift risk sentiment.",
      "",
      "This digest is informational only and not a buy/sell signal.",
    ].join("\n");

  return createMarketAlert({
    type: "daily-digest",
    title,
    message,
    severity: "info",
  });
}

/**
 * Simple system “smoke test” alert to confirm the pipeline works.
 */
export async function generateTestJumpAlert() {
  const title = "System Check: Alerts Online";
  const message =
    "Tredia’s alert system is active. You’ll see market-relevant messages here as conditions are detected.";

  return createMarketAlert({
    type: "system-check",
    title,
    message,
    severity: "info",
  });
}
