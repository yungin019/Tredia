// src/services/communityService.ts
import prisma from "../lib/prisma";

// -----------------------------
// TYPES
// -----------------------------

export interface CommunityPostDTO {
  id: number;
  authorId: number;
  authorName: string;
  authorHandle: string;
  title: string;
  content: string;
  imageUrl: string | null;
  createdAt: Date;
  likesCount: number;
  commentsCount: number;
}

export interface LiveActivityDTO {
  id: string;
  user: string;
  handle: string;
  side: "LONG" | "SHORT";
  symbol: string;
  style: string;
  timeframe: string;
  ago: string;
  pnl: string;
}

// -----------------------------
// HELPERS
// -----------------------------

function buildHandle(email?: string | null, id?: number): string {
  if (email && email.includes("@")) {
    const base = email.split("@")[0];
    return `@${base}`;
  }
  if (id) {
    return `@tredia_user_${id}`;
  }
  return "@tredia_user";
}

function mapPostToDto(post: any): CommunityPostDTO {
  const authorName =
    post.author?.displayName ||
    post.author?.email ||
    "Trader";

  const handle = buildHandle(post.author?.email, post.author?.id);

  return {
    id: post.id,
    authorId: post.authorId,
    authorName,
    authorHandle: handle,
    title: post.title,
    content: post.content,
    imageUrl: post.imageUrl ?? null,
    createdAt: post.createdAt,
    likesCount: post._count?.likes ?? 0,
    commentsCount: post._count?.comments ?? 0,
  };
}

function formatAgo(date: Date): string {
  const now = new Date().getTime();
  const diffMs = now - date.getTime();
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffH = Math.floor(diffMin / 60);
  const diffD = Math.floor(diffH / 24);

  if (diffSec < 60) return "just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffH < 24) return `${diffH}h ago`;
  return `${diffD}d ago`;
}

// -----------------------------
// COMMUNITY FEED
// -----------------------------

export async function listCommunityPosts(options?: {
  limit?: number;
  viewerId?: number | null;
}): Promise<CommunityPostDTO[]> {
  const limit = options?.limit && options.limit > 0 ? options.limit : 50;

  const posts = await prisma.post.findMany({
    take: limit,
    orderBy: { createdAt: "desc" },
    include: {
      author: {
        select: {
          id: true,
          email: true,
          displayName: true,
        },
      },
      _count: {
        select: {
          likes: true,
          comments: true,
        },
      },
    },
  });

  return posts.map(mapPostToDto);
}

export async function getCommunityPostById(
  postId: number
): Promise<CommunityPostDTO | null> {
  const post = await prisma.post.findUnique({
    where: { id: postId },
    include: {
      author: {
        select: {
          id: true,
          email: true,
          displayName: true,
        },
      },
      _count: {
        select: {
          likes: true,
          comments: true,
        },
      },
    },
  });

  if (!post) return null;
  return mapPostToDto(post);
}

export async function createCommunityPost(params: {
  authorId: number;
  title?: string | null;
  content: string;
  imageUrl?: string | null;
}): Promise<CommunityPostDTO> {
  const { authorId, title, content, imageUrl } = params;

  const finalTitle =
    (title && title.trim()) ||
    content.split("\n")[0].slice(0, 80) ||
    "Untitled post";

  const created = await prisma.post.create({
    data: {
      authorId,
      title: finalTitle,
      content,
      imageUrl: imageUrl ?? null,
    },
    include: {
      author: {
        select: {
          id: true,
          email: true,
          displayName: true,
        },
      },
      _count: {
        select: {
          likes: true,
          comments: true,
        },
      },
    },
  });

  return mapPostToDto(created);
}

// -----------------------------
// LIKES & COMMENTS
// -----------------------------

export async function likePost(postId: number, userId: number) {
  // idempotent like using composite unique (postId, userId)
  await prisma.like.upsert({
    where: {
      postId_userId: {
        postId,
        userId,
      },
    },
    update: {},
    create: {
      postId,
      userId,
    },
  });
}

export async function unlikePost(postId: number, userId: number) {
  await prisma.like.deleteMany({
    where: {
      postId,
      userId,
    },
  });
}

export async function addCommentToPost(params: {
  postId: number;
  userId: number;
  content: string;
}) {
  const { postId, userId, content } = params;

  return prisma.comment.create({
    data: {
      postId,
      userId,
      content,
    },
  });
}

// -----------------------------
// LIVE COMMUNITY ACTIVITY
// -----------------------------

export async function listLiveActivity(options?: {
  limit?: number;
}): Promise<LiveActivityDTO[]> {
  const limit = options?.limit && options.limit > 0 ? options.limit : 50;

  const trades = await prisma.realTrade.findMany({
    take: limit,
    orderBy: { executedAt: "desc" },
    include: {
      user: {
        select: {
          id: true,
          email: true,
          displayName: true,
        },
      },
    },
  });

  return trades.map((t) => {
    const userName =
      t.user?.displayName ||
      t.user?.email ||
      "Trader";

    const handle = buildHandle(t.user?.email, t.user?.id);

    return {
      id: String(t.id),
      user: userName,
      handle,
      side: t.side.toUpperCase() === "SHORT" ? "SHORT" : "LONG",
      symbol: t.symbol,
      style: "manual", // real data for symbol/side, style is generic
      timeframe: formatAgo(t.executedAt),
      ago: formatAgo(t.executedAt),
      // We don't have exact P&L yet, so we keep it neutral but valid
      pnl: "0.0%",
    };
  });
}
