// tredia-api/src/services/assistantService.ts

import prisma from "../lib/prisma";
import OpenAI from "openai";
import {
  getPlanNameFromDb,
  PLAN_AI_LIMITS,
  type PlanName,
} from "../config/planLimits";

// --------------------
// OpenAI client setup
// --------------------
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";

// --------------------
// Types
// --------------------

export type AiRole = "user" | "assistant" | "system";

export interface AiMessage {
  role: AiRole;
  content: string;
}

export interface AiChatMeta {
  model?: string;
  latencyMs?: number;
  tokens?: number | null;
}

export interface AiChatResult {
  reply: string;
  meta: AiChatMeta;
  remainingToday: number | null; // null = unlimited
  dailyLimit: number | null; // null = unlimited
  planName: PlanName;
}

export class AiMessageLimitError extends Error {
  statusCode: number;
  planName: PlanName;
  dailyLimit: number | null;
  remainingToday: number | null;

  constructor(params: {
    message: string;
    planName: PlanName;
    dailyLimit: number | null;
    remainingToday: number | null;
    statusCode?: number;
  }) {
    super(params.message);
    this.name = "AiMessageLimitError";
    this.statusCode = params.statusCode ?? 403;
    this.planName = params.planName;
    this.dailyLimit = params.dailyLimit;
    this.remainingToday = params.remainingToday;
  }
}

// --------------------
// Helpers
// --------------------

function startOfUtcDay(d: Date): Date {
  const x = new Date(d);
  x.setUTCHours(0, 0, 0, 0);
  return x;
}

/**
 * Get or create today's AiUsage row for a user.
 * Schema: { id, userId, date, count }
 */
async function getTodayUsage(userId: number) {
  const today = startOfUtcDay(new Date());

  let usage = await prisma.aiUsage.findFirst({
    where: { userId, date: today },
  });

  if (!usage) {
    usage = await prisma.aiUsage.create({
      data: { userId, date: today, count: 0 },
    });
  }

  return usage;
}

function pickLastUserMessage(messages: AiMessage[]): string {
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m?.role === "user" && typeof m.content === "string") return m.content;
  }
  return messages[messages.length - 1]?.content ?? "";
}

function maxTokensForPlan(plan: PlanName): number {
  const p = String(plan).toUpperCase();
  if (p === "ELITE") return 1100;
  if (p === "PRO") return 850;
  return 650;
}

function needsPositionDisclaimer(text: string): boolean {
  const t = (text || "").toLowerCase();

  // If the user is asking for action / entry / allocation / trade sizing, etc.
  // (We keep this broad but not overly sensitive.)
  const triggers = [
    "buy",
    "sell",
    "long",
    "short",
    "entry",
    "enter",
    "exit",
    "take profit",
    "stop loss",
    "stoploss",
    "position",
    "size",
    "allocation",
    "leverage",
    "risk reward",
    "risk/reward",
    "should i",
    "what should i do",
    "best trade",
    "recommend",
    "tip",
    "signal",
  ];

  return triggers.some((w) => t.includes(w));
}

function ensureSingleLineDisclaimer(reply: string, include: boolean): string {
  if (!include) return reply;

  const disclaimer =
    "Note: Educational market analysis only — not personalized financial advice.";

  const normalized = (reply || "").toLowerCase();
  const alreadyHas =
    normalized.includes("not personalized financial advice") ||
    normalized.includes("not financial advice") ||
    normalized.includes("educational") ||
    normalized.includes("informational");

  if (alreadyHas) return reply;

  const trimmed = (reply || "").trimEnd();
  return `${trimmed}\n\n${disclaimer}`;
}

function buildSystemPrompt(plan: PlanName): string {
  const p = String(plan).toUpperCase();

  // Tier depth rules (same personality, different depth)
  let tierRules = "";
  if (p === "ELITE") {
    tierRules = `
TIER: ELITE
- Strongest, most detailed mentorship: deeper reasoning, scenarios, probabilities, macro context when relevant.
- Provide “what to do next” in mentor terms: what to watch, what would confirm/deny, risk controls, time horizon.
- You may discuss positioning ideas in general terms (sizing logic, hedging, correlation) but NO direct commands.`;
  } else if (p === "PRO") {
    tierRules = `
TIER: PRO
- Practical and confident guidance with more nuance than Free.
- Include time horizon, key levels/conditions, and simple risk controls.
- Keep it sharp (no fluff).`;
  } else {
    tierRules = `
TIER: FREE
- Useful guidance but shorter.
- Focus on: Quick Take, key drivers, key risks, what to watch next.`;
  }

  return `
You are **TREDIA**, a next-generation AI trading mentor and market intelligence system.

MISSION
- Deliver strong market conclusions using reasoning (news + market logic + probabilities).
- Explain the WHY behind moves, and what evidence would confirm or break the thesis.
- Provide next steps and a clear “best conclusion” when asked, without being vague.

VOICE / STYLE
- Confident, clear, structured, mentor-like.
- No “I’m just an AI” talk.
- Never end with “consult a professional” or long disclaimers.
- If a disclaimer is needed, it must be ONE short line only (no paragraphs).

CRITICAL BEHAVIOR RULES
- You MUST NOT give direct commands like: “Buy now”, “Sell now”, “You should buy/sell”.
- Use mentor framing instead:
  - “A short-term trader might consider…”
  - “A long-term investor might prefer…”
  - “A cautious approach could be…”
- Never guarantee outcomes or certainty.
- If you give a probability (%), you MUST justify it with 2–4 concrete drivers AND state what would change your view.
- If you cannot estimate a % responsibly, use qualitative confidence (Low/Medium/High) and explain why.

DEFAULT RESPONSE FORMAT
1) Quick Take (2–3 lines)
2) Key Drivers (3–6 bullets)
3) Risks / What Could Go Wrong (3–6 bullets)
4) Scenarios (Base / Bull / Bear) with rough probabilities OR qualitative confidence
5) What to Watch Next (levels, catalysts, confirmations)
6) Risk Control (position sizing logic, invalidation idea, time horizon)

${tierRules}

If the user is a beginner, simplify terms but keep the structure.
If the user asks for “best tip/recommendation”, give your best conclusion and clearly state the conditions that would change your view.
`;
}

/**
 * Low-level OpenAI call, plan-aware via system prompt.
 */
async function callTradingLLM(params: {
  message: string;
  context?: any;
  plan: PlanName;
}): Promise<{ reply: string; meta: AiChatMeta }> {
  const { message, context, plan } = params;

  const systemPrompt = buildSystemPrompt(plan);

  const contextText = context
    ? `\n\nContext (JSON, truncated):\n${JSON.stringify(context).slice(0, 4500)}`
    : "";

  const userContent = `${message}${contextText}`;

  const start = Date.now();

  const completion = await openai.chat.completions.create({
    model: MODEL,
    temperature: 0.35,
    max_tokens: maxTokensForPlan(plan),
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userContent },
    ],
  });

  const latencyMs = Date.now() - start;

  const reply =
    completion.choices?.[0]?.message?.content?.trim() ||
    "I couldn’t generate a response. Try again with a bit more detail.";

  const tokens =
    (completion.usage?.total_tokens as number | undefined) ?? null;

  return {
    reply,
    meta: { model: MODEL, latencyMs, tokens },
  };
}

// --------------------
// Main service
// --------------------

/**
 * Main function used by the /api/assistant/chat route.
 * - Loads user + plan
 * - Applies daily plan limits from PLAN_AI_LIMITS
 * - Tracks usage in AiUsage
 * - Calls OpenAI
 * - Returns reply + meta + remainingToday + dailyLimit + planName
 */
export async function chatWithAssistantForUser(
  userId: number,
  messages: AiMessage[]
): Promise<AiChatResult> {
  if (!messages || messages.length === 0) {
    throw new Error("At least one message is required");
  }

  // 1) Load user + plan
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: { plan: true },
  });

  if (!user) {
    throw new Error("User not found");
  }

  const planName: PlanName = getPlanNameFromDb(user.plan);
  const planLimits = PLAN_AI_LIMITS[planName];
  const dailyLimit: number | null = planLimits.daily ?? null; // null = unlimited

  // 2) Get today's usage
  const usage = await getTodayUsage(user.id);
  const usedMessages = usage.count ?? 0;

  // 3) Enforce daily limit (if any)
  if (dailyLimit !== null && usedMessages >= dailyLimit) {
    throw new AiMessageLimitError({
      message: `Daily AI chat limit reached for plan ${planName}`,
      planName,
      dailyLimit,
      remainingToday: 0,
      statusCode: 403,
    });
  }

  // 4) Build question + context
  const question = pickLastUserMessage(messages);

  const context = {
    lastMessages: messages.slice(-10),
    planName,
  };

  // 5) Call OpenAI
  const { reply: rawReply, meta } = await callTradingLLM({
    message: question,
    context,
    plan: planName,
  });

  // 6) Add ONE-LINE disclaimer only when the user is asking for action/positioning
  const includeDisclaimer = needsPositionDisclaimer(question);
  const reply = ensureSingleLineDisclaimer(rawReply, includeDisclaimer);

  // 7) Update usage
  const nextCount =
    dailyLimit === null
      ? usedMessages + 1
      : Math.min(usedMessages + 1, dailyLimit);

  await prisma.aiUsage.update({
    where: { id: usage.id },
    data: { count: nextCount },
  });

  // 8) Compute remaining (null = unlimited)
  const remainingToday =
    dailyLimit === null ? null : Math.max(dailyLimit - nextCount, 0);

  // 9) Return
  return {
    reply,
    meta,
    remainingToday,
    dailyLimit,
    planName,
  };
}
