// src/services/moderationService.ts

export type ModerationResult = {
  ok: boolean;
  reasons: string[];
};

const BANNED_WORDS = [
  "fuck",
  "shit",
  "scam",
  "pump and dump",
  "nazi",
  "terrorist",
  "racist",
];

export function moderateCommunityContent(text: string): ModerationResult {
  if (!text || !text.trim()) {
    return { ok: false, reasons: ["Empty content is not allowed"] };
  }

  const lower = text.toLowerCase();
  const reasons: string[] = [];

  for (const word of BANNED_WORDS) {
    if (lower.includes(word)) {
      reasons.push(`Contains banned term: "${word}"`);
    }
  }

  return {
    ok: reasons.length === 0,
    reasons,
  };
}
