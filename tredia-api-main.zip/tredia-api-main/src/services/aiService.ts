// src/services/aiService.ts

/**
 * Central AI entrypoint for:
 * - Coach
 * - Recommendations
 * - Dashboard
 * - Asset analysis
 *
 * For now this is a thin wrapper around OpenAIClient (your existing
 * helper in src/ai/openaiClient.ts).
 *
 * Later, this is where you'll plug the full "Super AI" stack:
 *  - multiple LLMs
 *  - quant signals
 *  - news impact
 *  - finBERT sentiment
 *  - trader persona
 *  - user profile
 *  - risk engine
 *  - confidence ranges
 *  - tier-depth logic
 */

import { OpenAIClient } from "../ai/openaiClient";

/**
 * User tier affects:
 * - depth
 * - reasoning
 * - risk explanation
 * - number of recommendations
 */
export type UserTier = "free" | "pro" | "elite";

/**
 * Generic AI text generation helper.
 *
 * Right now:
 *  - Builds a rich prompt with:
 *    • system role
 *    • tier (FREE / PRO / ELITE)
 *  - Sends it to OpenAIClient.chat(prompt: string)
 *  - Returns plain text
 *
 * When you later plug in the real Super AI:
 *  - Keep this function signature the same
 *  - Replace the internal implementation
 */
export async function aiGenerate(
  prompt: string,
  tier: UserTier = "free",
  system: string = "You are Tredia, an expert market analyst and trading mentor."
): Promise<string> {
  const tierLabel = tier.toUpperCase();

  const fullPrompt = `
SYSTEM ROLE
-----------
${system}

USER TIER
---------
${tierLabel}

INSTRUCTIONS
------------
Respond in a way that matches the tier depth:

- FREE: High-level, simple language, short answers.
- PRO: Add more structure, brief technical context, clearer risk notes.
- ELITE: Deep reasoning, scenario analysis, risk management, timing nuance.

USER PROMPT
-----------
${prompt}
`.trim();

  try {
    // ✅ Call the .chat(...) method on the OpenAIClient instance
    const result = await OpenAIClient.chat(fullPrompt);

    // result should look like:
    // { text: string; tokens: number; meta: { model: string; latencyMs: number; tokens: number; } }
    if (!result || typeof result.text !== "string") {
      console.warn("[aiGenerate] Empty or invalid response from OpenAIClient.chat");
      return "AI returned an empty response, please try again.";
    }

    return result.text;
  } catch (err) {
    console.error("[aiGenerate] error:", err);
    return "AI server overloaded, please retry in a moment.";
  }
}

export default {
  aiGenerate,
};
