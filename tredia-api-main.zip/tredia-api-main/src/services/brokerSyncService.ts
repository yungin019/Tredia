// src/services/brokerSyncService.ts
import prisma from "../prisma";
import { decrypt } from "../utils/crypto";
import { SUPPORTED_BROKERS } from "../config/brokers";

type ExternalPosition = {
  symbol: string; // e.g. "BTCUSDT", "AAPL"
  qty: number; // position size
  avgPrice: number; // average entry price
};

type ExternalTrade = {
  symbol: string;
  side: "buy" | "sell";
  qty: number;
  price: number;
  timestamp: Date;
};

// -----------------------------
// MOCK FETCHERS (per broker)
// -----------------------------

async function fetchBinancePortfolio(
  apiKey: string,
  apiSecret?: string | null
): Promise<ExternalPosition[]> {
  // TODO: Call Binance portfolio API here
  console.log("[Binance] Fetching portfolio for key", apiKey.slice(0, 6));
  return [];
}

async function fetchBinanceTrades(
  apiKey: string,
  apiSecret?: string | null
): Promise<ExternalTrade[]> {
  // TODO: Call Binance trades API here
  return [];
}

async function fetchIbkrPortfolio(
  apiKey: string,
  apiSecret?: string | null
): Promise<ExternalPosition[]> {
  // TODO: IBKR integration
  console.log("[IBKR] Fetching portfolio for key", apiKey.slice(0, 6));
  return [];
}

async function fetchIbkrTrades(
  apiKey: string,
  apiSecret?: string | null
): Promise<ExternalTrade[]> {
  // TODO: IBKR integration
  return [];
}

async function fetchEtoroPortfolio(
  apiKey: string,
  apiSecret?: string | null
): Promise<ExternalPosition[]> {
  // eToro is usually deep-link only → no real API
  console.log("[eToro] No official API, portfolio read is not implemented.");
  return [];
}

async function fetchEtoroTrades(
  apiKey: string,
  apiSecret?: string | null
): Promise<ExternalTrade[]> {
  return [];
}

async function fetchTrading212Portfolio(
  apiKey: string,
  apiSecret?: string | null
): Promise<ExternalPosition[]> {
  console.log("[Trading212] Portfolio sync not implemented yet.");
  return [];
}

async function fetchTrading212Trades(
  apiKey: string,
  apiSecret?: string | null
): Promise<ExternalTrade[]> {
  return [];
}

// -----------------------------
// CORE SYNC LOGIC
// -----------------------------

async function syncBrokerForUser(
  userId: number,
  brokerId: string,
  encryptedKey: string,
  encryptedSecret?: string | null
) {
  const apiKey = decrypt(encryptedKey);
  const apiSecret = encryptedSecret ? decrypt(encryptedSecret) : null;

  let positions: ExternalPosition[] = [];
  let trades: ExternalTrade[] = [];

  switch (brokerId) {
    case "binance":
      positions = await fetchBinancePortfolio(apiKey, apiSecret);
      trades = await fetchBinanceTrades(apiKey, apiSecret);
      break;
    case "ibkr":
      positions = await fetchIbkrPortfolio(apiKey, apiSecret);
      trades = await fetchIbkrTrades(apiKey, apiSecret);
      break;
    case "etoro":
      positions = await fetchEtoroPortfolio(apiKey, apiSecret);
      trades = await fetchEtoroTrades(apiKey, apiSecret);
      break;
    case "trading212":
      positions = await fetchTrading212Portfolio(apiKey, apiSecret);
      trades = await fetchTrading212Trades(apiKey, apiSecret);
      break;
    default:
      console.log("[BrokerSync] No integration yet for broker:", brokerId);
      break;
  }

  // Upsert portfolio positions
  for (const pos of positions) {
    await prisma.portfolioPosition.upsert({
      where: {
        userId_symbol: {
          userId,
          symbol: pos.symbol,
        },
      },
      update: {
        qty: pos.qty,
        avgPrice: pos.avgPrice,
      },
      create: {
        userId,
        symbol: pos.symbol,
        qty: pos.qty,
        avgPrice: pos.avgPrice,
      },
    });
  }

  // Insert trade history (skip duplicates when supported)
  if (trades.length > 0) {
    await prisma.tradeHistory.createMany({
      data: trades.map((t) => ({
        userId,
        symbol: t.symbol,
        side: t.side,
        qty: t.qty,
        price: t.price,
        timestamp: t.timestamp,
      })),
      // some Prisma versions mis-type this; cast to avoid TS error
      ...(true && { skipDuplicates: true as any }),
    } as any);
  }
}

export async function syncUserPortfolio(userId: number) {
  const connections = await prisma.brokerConnection.findMany({
    where: { userId },
  });

  if (!connections.length) {
    console.log("[BrokerSync] No broker connections for user", userId);
    return;
  }

  for (const c of connections) {
    const brokerMeta = SUPPORTED_BROKERS.find((b) => b.id === c.broker);
    if (!brokerMeta) {
      console.log("[BrokerSync] Unknown broker id in DB:", c.broker);
      continue;
    }

    console.log(
      `[BrokerSync] Syncing user ${userId} with broker ${c.broker} (${brokerMeta.name})`
    );

    await syncBrokerForUser(userId, c.broker, c.apiKey, c.apiSecret);
  }
}

export async function syncAllUsersWithBrokers() {
  const users = await prisma.user.findMany({
    select: { id: true },
  });

  for (const u of users) {
    await syncUserPortfolio(u.id);
  }
}
