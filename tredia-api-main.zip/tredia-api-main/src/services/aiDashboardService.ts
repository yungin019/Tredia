// src/services/aiDashboardService.ts

import { getMarketTrends } from "./marketService";
import { getNewsRadar } from "./newsService";

export type SentimentLabel = "bullish" | "bearish" | "neutral";

export interface MarketAsset {
  symbol: string;
  name?: string | null;
  price?: number | null;
  changePct: number;
  assetClass?: string | null;
  sparkline?: number[];
}

export interface NewsRadarItem {
  id: string;
  title: string;
  summary: string | null;
  source?: string | null;
  url?: string | null;
  publishedAt?: string | null;
  impactedSymbols: string[];
  sentimentLabel: SentimentLabel;
  sentimentScore: number; // -1..1
  impactScore: number; // 0..100
  horizon: "intraday" | "swing" | "position";
  confidence: number; // 0..1
  categories?: string[];
  aiComment?: string | null;
}

export interface DailyBriefSnapshot {
  dailyBrief: string | null;
  generatedAt: string;
  _serviceVersion?: string;
}

export interface AiDashboardSnapshot {
  movers: MarketAsset[];
  trending: MarketAsset[];
  newsRadar: NewsRadarItem[];
  dailyBrief: string | null;
  generatedAt: string;
  _serviceVersion?: string;
}

function safeNumber(n: any): number | null {
  return typeof n === "number" && Number.isFinite(n) ? n : null;
}

function normalizeClassOut(cls: any): string | null {
  const c = String(cls || "").toLowerCase();
  if (!c) return null;
  // Important: backend may send index; UI expects etf
  if (c === "index") return "etf";
  return c;
}

function formatPct(v: number): string {
  const sign = v >= 0 ? "+" : "";
  return `${sign}${v.toFixed(2)}%`;
}

function computeRegime(movers: MarketAsset[]): "bullish" | "bearish" | "mixed" {
  if (!movers || movers.length === 0) return "mixed";
  const slice = movers.slice(0, 12);
  const ups = slice.filter((a) => (a.changePct ?? 0) > 0).length;
  const downs = slice.filter((a) => (a.changePct ?? 0) < 0).length;

  if (ups >= downs + 3) return "bullish";
  if (downs >= ups + 3) return "bearish";
  return "mixed";
}

function synthesizeDailyBrief(
  movers: MarketAsset[],
  trending: MarketAsset[]
): string {
  const now = new Date().toISOString();

  const topMove = (movers || [])[0];
  const topUp =
    [...(movers || [])].filter((a) => (a.changePct ?? 0) > 0).sort((a, b) => (b.changePct ?? 0) - (a.changePct ?? 0))[0] ||
    (trending || [])[0];

  const topDown =
    [...(movers || [])].filter((a) => (a.changePct ?? 0) < 0).sort((a, b) => (a.changePct ?? 0) - (b.changePct ?? 0))[0];

  const regime = computeRegime(movers);

  const leader = topMove?.symbol ? `${topMove.symbol} (${formatPct(topMove.changePct ?? 0)})` : "no clear leader yet";

  const upLine = topUp?.symbol ? `${topUp.symbol} ${formatPct(topUp.changePct ?? 0)}` : "—";
  const downLine = topDown?.symbol ? `${topDown.symbol} ${formatPct(topDown.changePct ?? 0)}` : "—";

  const vibe =
    regime === "bullish"
      ? "Risk-on tone: upside breadth is stronger."
      : regime === "bearish"
      ? "Risk-off tone: downside pressure is more concentrated."
      : "Sideways / mixed tone: moves are scattered and conviction is lower.";

  const watch =
    regime === "bullish"
      ? "Watch for exhaustion if leaders stall near highs."
      : regime === "bearish"
      ? "Watch for sharp bounces — volatility can spike quickly."
      : "Watch for a catalyst (news / macro / breakout) to set direction.";

  return [
    `Today's AI market pulse — ${vibe}`,
    `Leader: ${leader}.`,
    `Upside: ${upLine}. Downside: ${downLine}.`,
    `Story to watch: ${watch}`,
    `(${now})`,
  ].join(" ");
}

/**
 * ✅ Export expected by controllers.
 * Always returns a non-null string if we have any market data.
 */
export async function getDailyBriefSnapshot(): Promise<DailyBriefSnapshot> {
  const generatedAt = new Date().toISOString();

  try {
    const { movers, trending } = await getMarketTrends();

    const moversNorm = (movers || []).map((m: any) => ({
      ...m,
      price: safeNumber(m.price),
      changePct: typeof m.changePct === "number" ? m.changePct : 0,
      assetClass: normalizeClassOut(m.assetClass),
      sparkline: Array.isArray(m.sparkline) ? m.sparkline : [],
    })) as MarketAsset[];

    const trendingNorm = (trending || []).map((t: any) => ({
      ...t,
      price: safeNumber(t.price),
      changePct: typeof t.changePct === "number" ? t.changePct : 0,
      assetClass: normalizeClassOut(t.assetClass),
      sparkline: Array.isArray(t.sparkline) ? t.sparkline : [],
    })) as MarketAsset[];

    const dailyBrief =
      moversNorm.length > 0 || trendingNorm.length > 0
        ? synthesizeDailyBrief(moversNorm, trendingNorm)
        : null;

    return {
      dailyBrief,
      generatedAt,
      _serviceVersion: "aiDashboardService.v4 (synth dailyBrief fallback)",
    };
  } catch (err) {
    console.error("[aiDashboardService] getDailyBriefSnapshot error:", err);
    return {
      dailyBrief: null,
      generatedAt,
      _serviceVersion: "aiDashboardService.v4 (error fallback)",
    };
  }
}

/**
 * ✅ Export expected by controllers.
 */
export async function getNewsRadarSnapshot(): Promise<{
  newsRadar: NewsRadarItem[];
  generatedAt: string;
  _serviceVersion?: string;
}> {
  const generatedAt = new Date().toISOString();

  try {
    const items = await getNewsRadar();

    const normalized: NewsRadarItem[] = (Array.isArray(items) ? items : []).map((n: any) => ({
      id: String(n.id || n._id || `${n.title || "news"}-${generatedAt}`),
      title: String(n.title || "Untitled"),
      summary: typeof n.summary === "string" ? n.summary : null,
      source: typeof n.source === "string" ? n.source : null,
      url: typeof n.url === "string" ? n.url : null,
      publishedAt: typeof n.publishedAt === "string" ? n.publishedAt : null,
      impactedSymbols: Array.isArray(n.impactedSymbols) ? n.impactedSymbols : [],
      sentimentLabel: (n.sentimentLabel as SentimentLabel) || "neutral",
      sentimentScore: typeof n.sentimentScore === "number" ? n.sentimentScore : 0,
      impactScore: typeof n.impactScore === "number" ? n.impactScore : 50,
      horizon: n.horizon === "intraday" || n.horizon === "swing" || n.horizon === "position" ? n.horizon : "swing",
      confidence: typeof n.confidence === "number" ? n.confidence : 0.6,
      categories: Array.isArray(n.categories) ? n.categories : [],
      aiComment: typeof n.aiComment === "string" ? n.aiComment : null,
    }));

    return {
      newsRadar: normalized,
      generatedAt,
      _serviceVersion: "aiDashboardService.v4 (newsRadar)",
    };
  } catch (err) {
    console.error("[aiDashboardService] getNewsRadarSnapshot error:", err);
    return {
      newsRadar: [],
      generatedAt,
      _serviceVersion: "aiDashboardService.v4 (newsRadar error fallback)",
    };
  }
}

/**
 * ✅ Used by routes/markets.ts and other endpoints.
 */
export async function getMarketsSnapshot(): Promise<{
  movers: MarketAsset[];
  trending: MarketAsset[];
  generatedAt: string;
  _serviceVersion?: string;
}> {
  const generatedAt = new Date().toISOString();

  try {
    const { movers, trending } = await getMarketTrends();

    const moversNorm = (movers || []).map((m: any) => ({
      ...m,
      price: safeNumber(m.price),
      changePct: typeof m.changePct === "number" ? m.changePct : 0,
      assetClass: normalizeClassOut(m.assetClass),
      sparkline: Array.isArray(m.sparkline) ? m.sparkline : [],
    })) as MarketAsset[];

    const trendingNorm = (trending || []).map((t: any) => ({
      ...t,
      price: safeNumber(t.price),
      changePct: typeof t.changePct === "number" ? t.changePct : 0,
      assetClass: normalizeClassOut(t.assetClass),
      sparkline: Array.isArray(t.sparkline) ? t.sparkline : [],
    })) as MarketAsset[];

    return {
      movers: moversNorm,
      trending: trendingNorm,
      generatedAt,
      _serviceVersion: "aiDashboardService.v4 (markets snapshot normalized)",
    };
  } catch (err) {
    console.error("[aiDashboardService] getMarketsSnapshot error:", err);
    return {
      movers: [],
      trending: [],
      generatedAt,
      _serviceVersion: "aiDashboardService.v4 (markets error fallback)",
    };
  }
}

/**
 * ✅ Export expected by controllers.
 * Single “dashboard” snapshot for /api/ai/dashboard
 */
export async function getAiDashboardSnapshot(): Promise<AiDashboardSnapshot> {
  const generatedAt = new Date().toISOString();

  const [markets, brief, news] = await Promise.all([
    getMarketsSnapshot(),
    getDailyBriefSnapshot(),
    getNewsRadarSnapshot(),
  ]);

  // If brief is null but we have market data, synthesize again (belt + suspenders)
  const dailyBrief =
    brief.dailyBrief ||
    ((markets.movers.length > 0 || markets.trending.length > 0)
      ? synthesizeDailyBrief(markets.movers, markets.trending)
      : null);

  return {
    movers: markets.movers,
    trending: markets.trending,
    newsRadar: news.newsRadar,
    dailyBrief,
    generatedAt,
    _serviceVersion: "aiDashboardService.v4 (dashboard snapshot)",
  };
}
