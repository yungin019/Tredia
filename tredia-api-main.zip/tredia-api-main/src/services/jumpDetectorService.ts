// src/services/jumpDetectorService.ts
import prisma from "../prisma";

export type NextJumpRequest = {
  userId?: number;
  symbol?: string;
  timeframe?: "intraday" | "swing" | "position";
  budget?: number;
  riskLevel?: "low" | "medium" | "high";
};

export type NextJumpResponse = {
  symbol: string;
  assetClass: "stock" | "crypto" | "forex" | "commodity" | "index";
  probability: number; // 0–1
  confidenceLabel: "low" | "medium" | "high";
  expectedDirection: "up" | "down";
  expectedMoveWindow: string; // e.g. "next 2–5 days"
  thesis: string;
  keyDrivers: string[];
  riskFactors: string[];
  suggestedRiskLevel: "low" | "medium" | "high";
  suggestedPositionNote: string;
  aiTier: "elite";
};

export async function analyzeNextJump(
  params: NextJumpRequest
): Promise<NextJumpResponse> {
  const { userId, symbol = "BTCUSDT", timeframe = "swing", budget, riskLevel } =
    params;

  let userPlanName: string | null = null;

  if (userId) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { plan: true },
    });
    userPlanName = user?.plan?.name ?? null;
  }

  // 🔮 TEMP MOCK LOGIC (later: replace with real ML)
  const upper = symbol.toUpperCase();
  const prob =
    upper === "BTCUSDT" ? 0.84 : upper === "ETHUSDT" ? 0.79 : 0.73;

  const expectedDirection: "up" | "down" =
    upper === "BTCUSDT" ? "up" : "up";

  const expectedMoveWindow =
    timeframe === "intraday"
      ? "next 4–12 hours"
      : timeframe === "swing"
      ? "next 2–5 trading days"
      : "next 2–6 weeks";

  const confidenceLabel: "low" | "medium" | "high" =
    prob >= 0.82 ? "high" : prob >= 0.74 ? "medium" : "low";

  const effectiveRiskLevel = riskLevel ?? "medium";

  const thesis =
    upper === "BTCUSDT"
      ? "AI detects strengthening risk-on flows, positive funding, and improving macro sentiment toward crypto, with no immediate downside catalyst in the short window."
      : `AI detects unusual momentum and volume build-up on ${upper}, with supportive news flow and healthy orderbook structure.`;

  const keyDrivers = [
    "Pattern similarity to previous breakout phases",
    "News sentiment skewed positively over the last 24–72h",
    "Liquidity and volatility within a favorable regime",
  ];

  if (upper === "BTCUSDT") {
    keyDrivers.push(
      "Net outflows from exchanges suggest reduced sell pressure",
      "Derivatives data shows controlled leverage, not euphoric blow-off"
    );
  }

  const riskFactors = [
    "Market can invalidate the setup if macro sentiment flips sharply.",
    "Unexpected regulatory or macro headlines can override the pattern.",
  ];

  if (effectiveRiskLevel === "high") {
    riskFactors.push("Higher size increases drawdown sensitivity.");
  }

  const suggestedPositionNote =
    effectiveRiskLevel === "low"
      ? "AI suggests a small test size with wide invalidation and no leverage for this setup."
      : effectiveRiskLevel === "medium"
      ? "AI suggests a moderate size with clear invalidation level and reduced leverage."
      : "AI suggests only experienced traders consider higher size or leverage, with strict risk management.";

  return {
    symbol: upper,
    assetClass:
      upper.endsWith("USDT") || upper === "BTC" ? "crypto" : "stock",
    probability: prob,
    confidenceLabel,
    expectedDirection,
    expectedMoveWindow,
    thesis:
      userPlanName === "Elite"
        ? thesis
        : thesis +
          " This explanation is simplified; Elite users receive a deeper breakdown and multi-scenario playbook.",
    keyDrivers,
    riskFactors,
    suggestedRiskLevel: effectiveRiskLevel,
    suggestedPositionNote,
    aiTier: "elite",
  };
}
