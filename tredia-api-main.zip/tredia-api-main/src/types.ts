export type AssetKind =
  | "STOCK"
  | "CRYPTO"
  | "FOREX"
  | "INDEX"
  | "COMMODITY"
  | "FUND";

export type Side = "BUY" | "SELL";
