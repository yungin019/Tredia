// scripts/makeElite.ts
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("⚙️ makeElite starting...");

  // node, scriptPath, email
  const emailArg = process.argv[2];
  const EMAIL = (emailArg || "").trim().toLowerCase();

  if (!EMAIL) {
    console.error('❌ Missing email. Usage: npx ts-node scripts/makeElite.ts "user@email.com"');
    process.exit(1);
  }

  // 1) Find Elite plan
  const elitePlan =
    (await prisma.plan.findFirst({ where: { name: "Elite" } })) ||
    (await prisma.plan.findFirst({ where: { name: "ELITE" } }));

  if (!elitePlan) {
    throw new Error('Elite plan not found. Run: npx ts-node scripts/seedPlans.ts');
  }

  console.log(`✅ Found Elite plan: id=${elitePlan.id}, name=${elitePlan.name}`);

  // 2) Find the user BY THE EMAIL ARG
  const user = await prisma.user.findUnique({
    where: { email: EMAIL },
  });

  if (!user) {
    console.error(`❌ User not found: ${EMAIL}`);
    process.exit(1);
  }

  console.log(`👤 Found user: id=${user.id}, email=${user.email}, current planId=${user.planId}`);

  // 3) Update planId
  const updated = await prisma.user.update({
    where: { email: EMAIL },
    data: { planId: elitePlan.id },
    include: { plan: true },
  });

  console.log(`✅ Updated user: id=${updated.id}, email=${updated.email}, new plan=${updated.plan?.name}`);
}

main()
  .catch((e) => console.error("❌ makeElite script failed:", e))
  .finally(async () => prisma.$disconnect());
