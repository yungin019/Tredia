// scripts/setPassword.ts
import prisma from "../src/lib/prisma";
import bcrypt from "bcryptjs";

async function main() {
  const email = process.argv[2];
  const password = process.argv[3];

  if (!email || !password) {
    console.error('Usage: npx ts-node scripts/setPassword.ts <email> "<password>"');
    process.exit(1);
  }

  console.log(`🔐 Setting new password for: ${email}`);

  const user = await prisma.user.findUnique({ where: { email } });

  if (!user) {
    console.error(`❌ User not found: ${email}`);
    process.exit(1);
  }

  const hash = await bcrypt.hash(password, 10);

  // Adjust field name if your schema uses something else:
  // common: passwordHash
  // sometimes: password
  // sometimes: hashedPassword
  const updated = await prisma.user.update({
    where: { email },
    data: {
      passwordHash: hash,
    },
  });

  console.log(`✅ Password updated for user id=${updated.id} | email=${updated.email}`);
}

main()
  .catch((e) => {
    console.error("❌ Failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
