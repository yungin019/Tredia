// scripts/listUsers.ts
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("📋 Current users in DB:\n");

  const users = await prisma.user.findMany({
    select: {
      id: true,
      email: true,
      displayName: true,
      plan: {
        select: { id: true, name: true },
      },
    },
  });

  if (users.length === 0) {
    console.log("⚠️ No users found yet.");
    return;
  }

  for (const u of users) {
    console.log(
      `- id=${u.id} | email=${u.email} | name=${u.displayName ?? "—"} | plan=${u.plan?.name ?? "None"}`
    );
  }
}

main()
  .catch((e) => {
    console.error("❌ listUsers failed:", e);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
