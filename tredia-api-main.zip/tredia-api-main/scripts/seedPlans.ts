// scripts/seedPlans.ts
import prisma from "../src/prisma";

async function main() {
  const plans = [
    {
      name: "Free",
      description: "Basic access with limited AI messages per day.",
      priceMonthly: 0,
      currency: "EUR",
    },
    {
      name: "Pro",
      description: "More AI, more features and deeper insights.",
      priceMonthly: 19,
      currency: "EUR",
    },
    {
      name: "Elite",
      description: "Full Super AI access with the deepest market brain.",
      priceMonthly: 49,
      currency: "EUR",
    },
  ];

  for (const plan of plans) {
    const saved = await prisma.plan.upsert({
      where: { name: plan.name },
      update: {
        description: plan.description,
        priceMonthly: plan.priceMonthly,
        currency: plan.currency,
      },
      create: plan,
    });

    console.log(`✅ Plan upserted: ${saved.name} (id=${saved.id})`);
  }
}

main()
  .then(() => {
    console.log("✅ Done seeding plans.");
  })
  .catch((err) => {
    console.error("❌ seedPlans failed:", err);
  });
