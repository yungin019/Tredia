// scripts/seedCommunity.ts
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding Tredia database (users + creator profiles + posts)...");

  // -------- USERS --------
  const user1 = await prisma.user.upsert({
    where: { email: "demo1@tredia.ai" },
    update: {},
    create: {
      email: "demo1@tredia.ai",
      passwordHash: "HASHED_PASSWORD_1",
      displayName: "Tredia Analyst",
      referralCode: "DEMO1001",
    },
  });

  const user2 = await prisma.user.upsert({
    where: { email: "demo2@tredia.ai" },
    update: {},
    create: {
      email: "demo2@tredia.ai",
      passwordHash: "HASHED_PASSWORD_2",
      displayName: "AI Market Wizard",
      referralCode: "DEMO1002",
    },
  });

  const user3 = await prisma.user.upsert({
    where: { email: "demo3@tredia.ai" },
    update: {},
    create: {
      email: "demo3@tredia.ai",
      passwordHash: "HASHED_PASSWORD_3",
      displayName: "Crypto Sentinel",
      referralCode: "DEMO1003",
    },
  });

  console.log("✅ Users created/updated:", user1.email, user2.email, user3.email);

  // -------- CREATOR PROFILES --------
  await prisma.creatorProfile.upsert({
    where: { userId: user1.id },
    update: {},
    create: {
      userId: user1.id,
      followers: 420,
      rank: 90,
      bio: "Professional market analyst. Sharing insights & breakdowns.",
    },
  });

  await prisma.creatorProfile.upsert({
    where: { userId: user2.id },
    update: {},
    create: {
      userId: user2.id,
      followers: 310,
      rank: 83,
      bio: "AI-assisted trader exploring next big moves.",
    },
  });

  await prisma.creatorProfile.upsert({
    where: { userId: user3.id },
    update: {},
    create: {
      userId: user3.id,
      followers: 510,
      rank: 88,
      bio: "Crypto-focused creator & market momentum tracker.",
    },
  });

  console.log("✅ Creator profiles upserted");

  // -------- SAMPLE POSTS (NOW WITH TITLES) --------
  await prisma.post.createMany({
    data: [
      {
        authorId: user1.id,
        title: "AI Brief – Semiconductors",
        content:
          "📊 AI detected rising momentum on semiconductor stocks this morning.",
      },
      {
        authorId: user2.id,
        title: "AI Brief – Energy & Oil",
        content:
          "🔥 Oil volatility incoming. Keep your eyes on the energy sector.",
      },
      {
        authorId: user3.id,
        title: "AI Brief – Bitcoin",
        content:
          "🚀 BTC approaching breakout zone — AI confidence rising.",
      },
    ],
  });

  console.log("✅ Sample posts created");
  console.log("✨ Seed complete!");
}

main()
  .catch((e) => {
    console.error("❌ Seed error:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
