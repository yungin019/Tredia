import { PrismaClient, Prisma } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const adminEmail = "admin@tredia.ai";
  const adminPlainPassword = "Admin123!";

  const passwordHash = await bcrypt.hash(adminPlainPassword, 12);

  await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
    await tx.user.upsert({
      where: { email: adminEmail },
      update: { passwordHash },
      create: {
        email: adminEmail,
        passwordHash,
        displayName: "Admin"
      }
    });
  });

  console.log("✅ Seed complete");
  console.log(`Admin email: ${adminEmail}`);
  console.log(`Admin password: ${adminPlainPassword}`);
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (error) => {
    console.error("Seed failed:", error);
    await prisma.$disconnect();
    process.exit(1);
  });
